# People Analytics — Semantic Model Data Lineage (Detailed)

> **Model**: People Analytics  
> **Workspace**: TEST - Fabric HR Data  
> **Generated**: 2026-04-28  
> **Source**: TMDL export via Fabric MCP  

---

## 1. Lineage Coverage Summary

| Item | Count |
|------|-------|
| **Tables** | 16 |
| **Relationships** | 34 |
| **Measures** | 13 |
| **Security Roles** | 3 |
| **Source Artifacts** | TMDL files from `People Analytics.SemanticModel/` |

### Source Artifacts Used

| File | Purpose |
|------|---------|
| `relationships.tmdl` | All 34 relationship definitions |
| `tables/Trending Metrics.tmdl` | All 13 measure definitions |
| `tables/Hires.tmdl` | Hires fact table schema (40 columns) |
| `tables/Headcount.tmdl` | Headcount fact table schema (40 columns) |
| `tables/Terminations.tmdl` | Terminations fact table schema (47 columns) |
| `tables/People Information.tmdl` | People dimension (46 columns) |
| `tables/Department Hierarchy.tmdl` | Department dimension (18 columns) |
| `tables/Locations.tmdl` | Locations dimension (18 columns) |
| `tables/Jobs.tmdl` | Jobs dimension (27 columns) |
| `tables/Officer RC Mapping.tmdl` | Officer mapping bridge (9 columns) |
| `tables/Employee Types.tmdl` | Employee types dimension (4 columns) |
| `tables/GL Companies.tmdl` | GL companies dimension (6 columns) |
| `tables/GL Locations.tmdl` | GL locations dimension (6 columns) |
| `tables/Age Group.tmdl` | Age group dimension (5 columns) |
| `tables/Years of Service Group.tmdl` | Years of service dimension (5 columns) |
| `tables/Supervisors.tmdl` | Supervisors dimension (12 columns) |
| `tables/UKG Fabric Latest Sync.tmdl` | Utility table — sync timestamps (2 columns) |
| `model.tmdl` | Model-level settings |
| `database.tmdl` | Database compatibility level |
| `roles/Role_Officers.tmdl` | RLS role: Officers |
| `roles/Role_FullAccess.tmdl` | RLS role: Full Access |
| `roles/Adi.tmdl` | RLS role: Adi (testing) |

---

## 2. Complete Relationship Catalog

All 34 relationships in the model are listed below. **None are inactive** in this model — all relationships are active.

| # | From Table | From Column | → | To Table | To Column | Active | Cross-Filter | Cardinality | Notes |
|---|-----------|-------------|---|----------|-----------|--------|-------------|-------------|-------|
| 1 | Hires | Hire Date | → | Trending Metrics | Date | ✅ Yes | OneDirection | Many-to-One | Date dimension link for hire date trending |
| 2 | Hires | People Info PK | → | People Information | People Info PK | ✅ Yes | OneDirection | Many-to-One | Employee detail lookup |
| 3 | Hires | Department Code | → | Department Hierarchy | Department Code | ✅ Yes | OneDirection | Many-to-One | Department hierarchy for hires |
| 4 | Hires | Location Code | → | Locations | Location Code | ✅ Yes | OneDirection | Many-to-One | Work location lookup |
| 5 | Hires | Age Group | → | Age Group | Age Group | ✅ Yes | OneDirection | Many-to-One | Age band grouping for hires |
| 6 | Hires | Total Years of Service at Hire Group | → | Years of Service Group | Years of Service Group | ✅ Yes | OneDirection | Many-to-One | YoS grouping at hire |
| 7 | Hires | GL Company Code | → | GL Companies | GL Company Code | ✅ Yes | OneDirection | Many-to-One | GL company entity for hires |
| 8 | Hires | GL Location Code | → | GL Locations | GL Location Code | ✅ Yes | OneDirection | Many-to-One | GL location entity for hires |
| 9 | Hires | Employee Type Code | → | Employee Types | Employee Type Code | ✅ Yes | OneDirection | Many-to-One | Employment type for hires |
| 10 | Hires | Job Code | → | Jobs | Job Code | ✅ Yes | OneDirection | Many-to-One | Job detail lookup for hires |
| 11 | Hires | Supervisor EEID | → | Supervisors | EEID | ✅ Yes | OneDirection | Many-to-One | Supervisor lookup for hires |
| 12 | Terminations | Termination Date | → | Trending Metrics | Date | ✅ Yes | OneDirection | Many-to-One | Date dimension link for termination trending |
| 13 | Terminations | People Info PK | → | People Information | People Info PK | ✅ Yes | OneDirection | Many-to-One | Employee detail lookup |
| 14 | Terminations | Location Code | → | Locations | Location Code | ✅ Yes | OneDirection | Many-to-One | Work location at termination |
| 15 | Terminations | Department Code | → | Department Hierarchy | Department Code | ✅ Yes | OneDirection | Many-to-One | Department at termination |
| 16 | Terminations | Age Group | → | Age Group | Age Group | ✅ Yes | OneDirection | Many-to-One | Age band at termination |
| 17 | Terminations | Total Years of Service at Termination Group | → | Years of Service Group | Years of Service Group | ✅ Yes | OneDirection | Many-to-One | YoS at termination |
| 18 | Terminations | GL Company Code | → | GL Companies | GL Company Code | ✅ Yes | OneDirection | Many-to-One | GL company at termination |
| 19 | Terminations | GL Location Code | → | GL Locations | GL Location Code | ✅ Yes | OneDirection | Many-to-One | GL location at termination |
| 20 | Terminations | Employee Type Code | → | Employee Types | Employee Type Code | ✅ Yes | OneDirection | Many-to-One | Employment type at termination |
| 21 | Terminations | Job Code | → | Jobs | Job Code | ✅ Yes | OneDirection | Many-to-One | Job detail at termination |
| 22 | Terminations | Supervisor EEID | → | Supervisors | EEID | ✅ Yes | OneDirection | Many-to-One | Supervisor at termination |
| 23 | Headcount | People Info PK | → | People Information | People Info PK | ✅ Yes | OneDirection | Many-to-One | Employee detail for headcount snapshot |
| 24 | Headcount | Status as of Date | → | Trending Metrics | Date | ✅ Yes | OneDirection | Many-to-One | Date dimension for headcount snapshots |
| 25 | Headcount | Location Code | → | Locations | Location Code | ✅ Yes | OneDirection | Many-to-One | Work location for headcount |
| 26 | Headcount | Department Code | → | Department Hierarchy | Department Code | ✅ Yes | OneDirection | Many-to-One | Department for headcount |
| 27 | Headcount | Employee Type Code | → | Employee Types | Employee Type Code | ✅ Yes | OneDirection | Many-to-One | Employment type for headcount |
| 28 | Headcount | Job Code | → | Jobs | Job Code | ✅ Yes | OneDirection | Many-to-One | Job detail for headcount |
| 29 | Headcount | Age Group | → | Age Group | Age Group | ✅ Yes | OneDirection | Many-to-One | Age band for headcount |
| 30 | Headcount | Total Years of Service as of Date Group | → | Years of Service Group | Years of Service Group | ✅ Yes | OneDirection | Many-to-One | YoS for headcount snapshot |
| 31 | Headcount | GL Company Code | → | GL Companies | GL Company Code | ✅ Yes | OneDirection | Many-to-One | GL company for headcount |
| 32 | Headcount | GL Location Code | → | GL Locations | GL Location Code | ✅ Yes | OneDirection | Many-to-One | GL location for headcount |
| 33 | Headcount | Supervisor EEID | → | Supervisors | EEID | ✅ Yes | OneDirection | Many-to-One | Supervisor for headcount |
| 34 | Department Hierarchy | Responsibility Center Code | → | Officer RC Mapping | Responsibility Center Code | ✅ Yes | OneDirection | **Many-to-Many** | ⚠️ M:M bridge — see notes below |

### ⚠️ Notable Relationship: #34 — Many-to-Many (Department Hierarchy ↔ Officer RC Mapping)

- **Type**: Many-to-Many
- **Cross-Filter**: OneDirection (Department Hierarchy → Officer RC Mapping)
- **Risk**: Many-to-many relationships can produce unexpected row duplication or inflated aggregates if not carefully managed in DAX.
- **Purpose**: Maps responsibility center codes to officers, allowing officer-based RLS and filtering.
- **Guidance**: Avoid placing measures that aggregate Headcount, Hires, or Terminations in a visual with Officer RC Mapping fields unless the DAX measure explicitly accounts for the M:M bridge.

---

## 3. Inactive Relationships

**There are no inactive relationships in this model.**

All 34 relationships are active. This eliminates ambiguity from inactive relationship paths and removes the need for `USERELATIONSHIP()` workarounds in standard reporting scenarios.

> **Risk Note**: While no inactive relationships exist today, future model changes that add parallel date relationships (e.g., a "Rehire Date" column linking to Trending Metrics) would require making one relationship inactive, introducing USERELATIONSHIP() patterns.

---

## 4. Measure Dependency Coverage by Referenced Table

This section summarizes how many measures reference each table, either directly in DAX or indirectly via other measures.

| Table | # Measures Referencing (Direct) | # Measures Referencing (Direct + Indirect) | Notes |
|-------|-------------------------------|------------------------------------------|-------|
| **Trending Metrics** | 9 | 13 | All measures live here; most reference its Date or Period columns. **Heaviest dependency**. |
| **Headcount** | 5 | 9 | Core fact for headcount KPIs. Referenced via COUNT(Headcount[People Info PK]). |
| **Hires** | 2 | 2 | Referenced by # of Hires and # of Hires YTD. |
| **Terminations** | 2 | 6 | Referenced by # of Terminations, # of Terminations YTD, and indirectly by all turnover measures. |
| People Information | 0 | 0 | No measures reference directly — used for filter context via relationships. |
| Department Hierarchy | 0 | 0 | Filter context only. |
| Locations | 0 | 0 | Filter context only. |
| Jobs | 0 | 0 | Filter context only. |
| All other dimensions | 0 | 0 | Filter context only. |

**High-Risk / High-Importance Tables**:
- **Trending Metrics**: Central to every measure calculation — any schema change here affects all 13 measures.
- **Headcount**: Primary source for headcount and turnover denominators — data quality issues here cascade into all HR KPIs.
- **Terminations**: Turnover numerator source — drives all turnover rate calculations.

---

## 5. Complete Measure-to-Table Dependency Catalog

### 5.1 — # of Headcount

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(COUNT(Headcount[People Info PK]), Headcount[Status as of Date] = MAX('Trending Metrics'[Date]))` |
| **Direct Table References** | Headcount, Trending Metrics |
| **Indirect Table References** | None |
| **Measure References** | None |
| **Notes** | Counts employees in the Headcount snapshot where Status as of Date equals the maximum date in the current filter context. Sensitive to date slicer selections. |

---

### 5.2 — # of Headcount Period End

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(COUNT(Headcount[People Info PK]), ALLSELECTED(Headcount[Status as of Date]), ENDOFMONTH('Trending Metrics'[Date]))` |
| **Direct Table References** | Headcount, Trending Metrics |
| **Indirect Table References** | None |
| **Measure References** | None |
| **Notes** | Uses ALLSELECTED to override the date filter on Headcount, then pins to end-of-month via Trending Metrics. Returns headcount snapshot at period end. |

---

### 5.3 — # of Headcount Period Start

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(COUNT(Headcount[People Info PK]), ALLSELECTED(Headcount[Status as of Date]), STARTOFMONTH('Trending Metrics'[Date]))` |
| **Direct Table References** | Headcount, Trending Metrics |
| **Indirect Table References** | None |
| **Measure References** | None |
| **Notes** | Mirrors Period End but pins to start-of-month. Together with Period End, forms the basis for period average headcount. |

---

### 5.4 — # of Headcount Period Average

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `([# of Headcount Period Start]+[# of Headcount Period End])/2` |
| **Direct Table References** | None |
| **Indirect Table References** | Headcount, Trending Metrics (via referenced measures) |
| **Measure References** | # of Headcount Period Start, # of Headcount Period End |
| **Notes** | Simple average of period start and end headcount. Used as the denominator for monthly turnover. Any issue with Period Start or Period End propagates here. |

---

### 5.5 — # of Headcount YTD Average

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(SUMX(VALUES('Trending Metrics'[Period (Month YYYY)]), [# of Headcount Period Average]), DATESYTD('Trending Metrics'[Date])) / CALCULATE(COUNTX(VALUES('Trending Metrics'[Period (Month YYYY)]), [# of Headcount Period Average]), DATESYTD('Trending Metrics'[Date]))` |
| **Direct Table References** | Trending Metrics |
| **Indirect Table References** | Headcount (via # of Headcount Period Average → Period Start/End) |
| **Measure References** | # of Headcount Period Average |
| **Notes** | Year-to-date running average headcount. Iterates over each month YTD, sums period averages, divides by month count. Month is the lowest granularity — daily values within a month are identical. Used as the denominator for YTD turnover. |

---

### 5.6 — # of Hires

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(COUNT(Hires[People Info PK]))` |
| **Direct Table References** | Hires |
| **Indirect Table References** | None |
| **Measure References** | None |
| **Notes** | Simple count of hire records in current filter context. Relies on the Hires → Trending Metrics relationship for date filtering. |

---

### 5.7 — # of Hires YTD

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(COUNT(Hires[People Info PK]), DATESYTD('Trending Metrics'[Date]))` |
| **Direct Table References** | Hires, Trending Metrics |
| **Indirect Table References** | None |
| **Measure References** | None |
| **Notes** | Year-to-date cumulative hire count using the DATESYTD time intelligence function on Trending Metrics[Date]. |

---

### 5.8 — # of Terminations

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(COUNT(Terminations[People Info PK]))` |
| **Direct Table References** | Terminations |
| **Indirect Table References** | None |
| **Measure References** | None |
| **Notes** | Simple count of termination records in current filter context. Relies on Terminations → Trending Metrics relationship for date filtering. |

---

### 5.9 — # of Terminations YTD

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(COUNT(Terminations[People Info PK]), DATESYTD('Trending Metrics'[Date]))` |
| **Direct Table References** | Terminations, Trending Metrics |
| **Indirect Table References** | None |
| **Measure References** | None |
| **Notes** | Year-to-date cumulative termination count. |

---

### 5.10 — % Turnover Monthly

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `[# of Terminations]/[# of Headcount Period Average]` |
| **Direct Table References** | None |
| **Indirect Table References** | Terminations, Headcount, Trending Metrics (via referenced measures) |
| **Measure References** | # of Terminations, # of Headcount Period Average |
| **Notes** | **Hidden measure** — not shown to end users. Monthly turnover rate = terminations ÷ average headcount. Used as a building block for YTD turnover. Division by zero risk if headcount period average is 0 (e.g., future months with no data). |

---

### 5.11 — % Turnover YTD

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `CALCULATE(SUMX(VALUES('Trending Metrics'[Period (Month YYYY)]), CALCULATE([# of Terminations YTD], ALLSELECTED('Trending Metrics'))), ENDOFMONTH('Trending Metrics'[Date])) / [# of Headcount YTD Average]` |
| **Direct Table References** | Trending Metrics |
| **Indirect Table References** | Terminations, Headcount (via referenced measures) |
| **Measure References** | # of Terminations YTD, # of Headcount YTD Average |
| **Notes** | Complex YTD turnover calculation. Uses ALLSELECTED to remove Trending Metrics filters within the inner CALCULATE, then pins to end-of-month. Divides by YTD average headcount. Month is the lowest granularity. The ALLSELECTED pattern here is critical — changing filter context on Trending Metrics could produce unexpected results. |

---

### 5.12 — % Turnover Monthly Average

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `[% Turnover YTD]/MAX('Trending Metrics'[Month])` |
| **Direct Table References** | Trending Metrics |
| **Indirect Table References** | Terminations, Headcount (via % Turnover YTD chain) |
| **Measure References** | % Turnover YTD |
| **Notes** | Divides YTD turnover by the number of months elapsed (MAX of Month number). Used as the base for annualized turnover. If the Month column contains non-sequential or non-1-indexed values, this could produce incorrect results. |

---

### 5.13 — % Turnover Annualized

| Property | Value |
|----------|-------|
| **Home Table** | Trending Metrics |
| **DAX Expression** | `[% Turnover Monthly Average]*12` |
| **Direct Table References** | None |
| **Indirect Table References** | Trending Metrics, Terminations, Headcount (full chain) |
| **Measure References** | % Turnover Monthly Average |
| **Notes** | Projects monthly average turnover to annual rate. Assumes 12-month extrapolation is appropriate regardless of how many months of data exist. Early-year values may be volatile (e.g., January projects a single month to full year). |

---

## 6. Measure Dependency Chain Summary

The following diagram shows how measures chain together:

```
# of Headcount
  └── (standalone)

# of Headcount Period Start
  └── (standalone)

# of Headcount Period End
  └── (standalone)

# of Headcount Period Average
  ├── # of Headcount Period Start
  └── # of Headcount Period End

# of Headcount YTD Average
  └── # of Headcount Period Average
        ├── # of Headcount Period Start
        └── # of Headcount Period End

# of Hires
  └── (standalone)

# of Hires YTD
  └── (standalone)

# of Terminations
  └── (standalone)

# of Terminations YTD
  └── (standalone)

% Turnover Monthly  [HIDDEN]
  ├── # of Terminations
  └── # of Headcount Period Average

% Turnover YTD
  ├── # of Terminations YTD
  └── # of Headcount YTD Average

% Turnover Monthly Average
  └── % Turnover YTD

% Turnover Annualized
  └── % Turnover Monthly Average
        └── % Turnover YTD
              ├── # of Terminations YTD
              └── # of Headcount YTD Average
```

---

## 7. Security Roles

| Role | Permission | Tables with RLS Filters |
|------|-----------|------------------------|
| Role_Officers | Read | Officer RC Mapping |
| Role_FullAccess | Read | (none — full access) |
| Adi | Read | Officer RC Mapping, Department Hierarchy |

> **Note**: The `Adi` role appears to be a testing/development role. Consider removing or renaming before production deployment.

---

## 8. Parsing Caveats & Assumptions

### Known Parsing Limitations
1. **Indirect measure references**: Measure-to-measure dependency chains are traced manually from DAX expressions. Deeply nested chains (3+ levels) are fully enumerated above but could contain missed indirect table references if a measure references a helper measure not captured in this model.
2. **ALLSELECTED context manipulation**: The `% Turnover YTD` measure uses `ALLSELECTED('Trending Metrics')` which modifies filter context at runtime. The actual tables evaluated may vary depending on which slicers are active in the report.
3. **Dynamic security (RLS)**: The RLS filter expressions on `Officer RC Mapping` were not fully parsed in this lineage. Effective permissions depend on the DAX filter expression in each role.

### Assumptions
1. **All measures are in the Trending Metrics table** — confirmed by the TMDL export. No measures exist in other tables.
2. **No calculated columns exist** — not verified exhaustively. If calculated columns contain cross-table DAX references, those dependencies are not captured here.
3. **No calculation groups exist** — the model does not use calculation groups.
4. **The Headcount table contains monthly snapshots** — inferred from the `Status as of Date` column and how measures reference it with STARTOFMONTH/ENDOFMONTH patterns.
5. **Month is the lowest reporting granularity** — stated in measure descriptions and confirmed by the DAX patterns.

### Warnings
- **% Turnover Annualized** projects a single month's average across 12 months. In Q1, this can produce volatile/misleading rates. Consider adding a tooltip or footnote in reports.
- **% Turnover Monthly** is hidden — report builders cannot accidentally use it, but should be aware it exists for DAX troubleshooting.
- **Many-to-Many relationship** (#34: Department Hierarchy ↔ Officer RC Mapping) may cause row duplication if Officer RC Mapping fields are placed alongside aggregate measures in a visual. Test thoroughly.

---

*End of Lineage Appendix — Generated from People Analytics TMDL export*
