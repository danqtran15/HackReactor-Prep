# People Analytics — Agent Quick Reference
# For use as a Copilot Studio Knowledge Source
# Generated: 2026-05-05 | Validated against live model

This document provides a concise, retrieval-optimized reference for the People Analytics
semantic model. It is designed to help the Copilot Studio agent quickly find the right
measure, table, or concept when answering user questions.

---

## Model Overview

**Model:** People Analytics
**Workspace:** TEST - Fabric HR Data
**Domain:** HR / Workforce Analytics
**Refresh:** Daily (via UKG sync)
**Fact Tables:** Headcount, Hires, Terminations
**Primary Key:** People Info PK (used across all person-related tables)

---

## Complete Measure Catalog (13 Model Measures)

### Headcount Measures (5 measures)

**# of Headcount** (PA-HC-001)
- What it does: Total active employees at the latest date in the current filter context
- Pattern: Snapshot (point-in-time)
- Summable: NO — never sum across months; each evaluation resolves to MAX date
- DAX: `CALCULATE(COUNT(Headcount[People Info PK]), Headcount[Status as of Date] = MAX('Trending Metrics'[Date]))`
- Use when: "How many employees do we have?" "What is our current headcount?"
- Caveat: If no date filter, returns count at the most recent loaded date

**# of Headcount Period Start** (PA-HC-002)
- What it does: Headcount on the 1st day of the selected month
- Pattern: Snapshot
- Summable: NO
- DAX: `CALCULATE(COUNT(Headcount[People Info PK]), ALLSELECTED(Headcount[Status as of Date]), STARTOFMONTH('Trending Metrics'[Date]))`
- Use when: "How many employees at the start of the month/year?"
- Caveat: Uses ALLSELECTED to override date slicer, then repositions to start of month

**# of Headcount Period End** (PA-HC-003)
- What it does: Headcount on the last day of the selected month
- Pattern: Snapshot
- Summable: NO
- DAX: `CALCULATE(COUNT(Headcount[People Info PK]), ALLSELECTED(Headcount[Status as of Date]), ENDOFMONTH('Trending Metrics'[Date]))`
- Use when: "Month-end headcount?" "Headcount at end of each month?"
- Caveat: Current incomplete month returns today's count, not true month-end

**# of Headcount Period Average** (PA-HC-004)
- What it does: Average workforce size = (Period Start + Period End) / 2
- Pattern: Average (derived)
- Summable: NO
- DAX: `([# of Headcount Period Start] + [# of Headcount Period End]) / 2`
- Use when: "Average headcount this month?" Also used as turnover denominator.
- Depends on: PA-HC-002, PA-HC-003

**# of Headcount YTD Average** (PA-HC-005)
- What it does: Running average of monthly Period Averages from January through selected month
- Pattern: Average (cumulative)
- Summable: NO
- Use when: "Average headcount so far this year?" Also used as YTD turnover denominator.
- Caveat: Month is the lowest granularity — all days in a month show the same value
- Depends on: PA-HC-004

### Hiring Measures (2 measures)

**# of Hires** (PA-HR-001)
- What it does: Count of hiring events in the selected period
- Pattern: EventCount
- Summable: YES — safe to sum across months, departments, etc.
- DAX: `COUNT(Hires[People Info PK])`
- Use when: "How many people did we hire?" "New hires this month?"

**# of Hires YTD** (PA-HR-002)
- What it does: Cumulative hires from January 1 through selected date
- Pattern: CumulativeCount
- Summable: NO — already cumulative, do not sum across months
- DAX: `CALCULATE([# of Hires], DATESYTD('Trending Metrics'[Date]))`
- Use when: "Total hires this year?" "YTD hires?"
- Depends on: PA-HR-001

### Termination Measures (2 measures)

**# of Terminations** (PA-TM-001)
- What it does: Count of exit events in the selected period
- Pattern: EventCount
- Summable: YES
- DAX: `COUNT(Terminations[People Info PK])`
- Use when: "How many terminations?" "How many people left?"
- Note: Includes both voluntary and involuntary. Filter Terminations[Termination Type] for breakdown.

**# of Terminations YTD** (PA-TM-002)
- What it does: Cumulative terminations from January 1 through selected date
- Pattern: CumulativeCount
- Summable: NO
- DAX: `CALCULATE([# of Terminations], DATESYTD('Trending Metrics'[Date]))`
- Depends on: PA-TM-001

### Turnover Measures (4 measures)

**% Turnover Monthly** (PA-TO-001)
- What it does: Monthly turnover rate = Terminations in month / Period Average headcount
- Pattern: Rate
- Summable: NO — it's a ratio
- Format: Percentage
- Use when: "What was turnover this month?"
- Depends on: PA-TM-001, PA-HC-004

**% Turnover YTD** (PA-TO-002)
- What it does: YTD turnover rate = Terminations YTD / Headcount YTD Average
- Pattern: Rate
- Summable: NO
- Use when: "What is our turnover rate so far this year?"
- Depends on: PA-TM-002, PA-HC-005

**% Turnover Monthly Average** (PA-TO-003)
- What it does: Average monthly turnover rate = % Turnover YTD / months elapsed
- Pattern: DerivedRate
- Summable: NO
- Use when: "What is the average monthly turnover?" "Typical monthly turnover?"
- Depends on: PA-TO-002

**% Turnover Annualized** (PA-TO-004)
- What it does: Annualized turnover = Monthly Average × 12
- Pattern: DerivedRate
- Summable: NO
- Use when: "What is our annualized turnover rate?" "Annual attrition rate?"
- KEY MEASURE — this is the primary turnover KPI used in leadership reporting.
- Depends on: PA-TO-003
- Full dependency chain: % Turnover Annualized → % Turnover Monthly Average → % Turnover YTD → (# of Terminations YTD + # of Headcount YTD Average)

---

## Report-Level Measures (39 measures)

These measures are defined in the Power BI report, NOT in the semantic model.
The Fabric Data Agent may not be able to query them directly.
Use the underlying model measures with appropriate time intelligence instead.

### Time Intelligence Variants (This Month / Last Month / SPLY)

| Category | This Month MTD | Last Month | Same Period Last Year |
|---|---|---|---|
| Headcount | PA-HC-006 | PA-HC-007 | PA-HC-008 |
| Hires | PA-HR-003 | PA-HR-004 | — |
| Terminations | PA-TM-005 | PA-TM-006 | — |
| Turnover Annualized | PA-TO-005 | PA-TO-006 | PA-TO-008 |

### Variance & KPI Arrow Measures

| Category | MoM Variance | MoM KPI Arrow | YoY % Change |
|---|---|---|---|
| Headcount | PA-HC-010 | PA-HC-011 | PA-HC-012 |
| Hires | PA-HR-007 | PA-HR-008 | — |
| Terminations | PA-TM-008 | PA-TM-009 | — |
| Turnover | PA-TO-009 | PA-TO-011 | PA-TO-012 |

### Special Measures
- **# of Headcount - This Month (Latest in Selection)** (PA-HC-009): Latest available headcount within the selected date range
- **# of Hires - This Month (Selection)** (PA-HR-006): Hires in the specifically selected month
- **# of Terminations Last 12 Months (Excluding Current Month)** (PA-TM-007): Rolling 12-month termination count
- **% Turnover Annualized - Previous Month** (PA-TO-007): Two months back (not last month)
- **Turnover Rate - % YoY Change (Involuntary)** (PA-TO-014): YoY change for involuntary only
- **Turnover Rate - % YoY Change (Voluntary)** (PA-TO-015): YoY change for voluntary only
- **12 Months Terms Moving Average (Involuntary)** (PA-TO-018): Rolling 12-month avg involuntary terms
- **12 Months Terms Moving Average (Voluntary)** (PA-TO-019): Rolling 12-month avg voluntary terms

### Utility Measures
- **SelectedYear** (PA-UT-001): Returns the year from the slicer
- **PreviousYear** (PA-UT-002): SelectedYear − 1
- **Info Icon** (PA-UT-003): Returns ⓘ Unicode character for report visuals

---

## Table Reference (16 tables in model)

### Fact Tables (contain measurable events)

| Table | Key Column | Date Column | Purpose |
|---|---|---|---|
| **Headcount** | People Info PK | Status as of Date | Daily employee snapshots; used for headcount measures |
| **Hires** | People Info PK | Hire Date | Hiring events; one row per hire |
| **Terminations** | People Info PK | Termination Date | Exit events; one row per termination |

### Date Table

| Table | Key Column | Purpose |
|---|---|---|
| **Trending Metrics** | Date | Central date table; all time intelligence flows through this |

Key date columns: Date, Year, Quarter, Month, Month Name, Period (Month YYYY), End of Month Date

### Dimension Tables

| Table | Key Column | Connected To | Purpose |
|---|---|---|---|
| **People Information** | People Info PK | Headcount, Hires, Terminations | Employee attributes (name, status, demographics) |
| **Department Hierarchy** | Department Code | Headcount, Hires, Terminations | Org structure; RC Level 01-05, Business Segment, Region, Area |
| **Locations** | Location Code | Headcount, Hires, Terminations | Work locations (city, state, country, timezone) |
| **Jobs** | Job Code | Headcount, Hires, Terminations | Job details (title, family, management level, EEO, FLSA) |
| **Employee Types** | Employee Type Code | Headcount, Hires, Terminations | Full-Time, Part-Time, Contractor, etc. |
| **Supervisors** | EEID | Headcount, Hires, Terminations | Supervisor information |
| **Age Group** | Age Group | Headcount, Hires, Terminations | Age band bucketing |
| **Years of Service Group** | Years of Service Group | Headcount, Hires, Terminations | Tenure bucketing |
| **GL Companies** | GL Company Code | Headcount, Hires, Terminations | Legal entity / company dimension |
| **GL Locations** | GL Location Code | Headcount, Hires, Terminations | GL cost center locations |
| **Officer RC Mapping** | Responsibility Center Code | Department Hierarchy | Maps RC codes to officer-level ownership |
| **UKG Fabric Latest Sync** | — | — | Data freshness metadata (last sync timestamp) |

---

## Relationship Architecture

The model follows a **star schema** with 3 fact tables:

```
                          Trending Metrics (Date)
                         /        |        \
                        /         |         \
               Headcount ---- Hires ---- Terminations
              /  |  |  \    /  |  |  \    /  |  |  \
             /   |  |   \  /   |  |   \  /   |  |   \
  People Info  Dept  Loc  Jobs  EmpTypes  AgeGrp  YoSGrp  GLCo  GLLoc  Supervisors
```

All relationships are **Many-to-One**, **Single-direction** filter.
Each fact table connects independently to the same set of dimensions.

---

## Critical Aggregation Rules

### SAFE to sum across periods:
- # of Hires (event count)
- # of Terminations (event count)

### NEVER sum across periods:
- # of Headcount (snapshot — would double-count people)
- All headcount variants (Period Start, Period End, Average, YTD Average)
- All turnover rates (ratios)
- All YTD measures (already cumulative)
- All variance measures (context-dependent)

### When user asks for "total" across months:
- For hires/terminations: sum is correct
- For headcount: show monthly trend or use YTD Average
- For turnover: show monthly trend or use Annualized rate

---

## Voluntary vs. Involuntary Terminations

The **Terminations** table has these key columns for type filtering:
- `Termination Type`: "Voluntary" or "Involuntary"
- `Termination Reason`: Specific reason text
- `Termination Reason Code`: Code for the reason
- `TRGP Termination Reason`: Targa-specific reason mapping
- `TRGP Termination Category`: Targa-specific category

To filter: `CALCULATE([# of Terminations], Terminations[Termination Type] = "Voluntary")`

---

## Department Hierarchy Navigation

The Department Hierarchy table provides multiple levels of organizational detail:

| Column | Level | Example Use |
|---|---|---|
| Responsibility Center Level 01 | Highest (segment) | "Gathering & Processing" |
| Responsibility Center Level 02 | Division | — |
| Responsibility Center Level 03 | Department | — |
| Responsibility Center Level 04 | Group | — |
| Responsibility Center Level 05 | Team (lowest) | — |
| Business Segment | Alternative grouping | Business line view |
| Region | Geographic grouping | Regional analysis |
| Area | Sub-regional | Area-level detail |

**Rule:** When a user mentions a department, search across all RC Levels + Business Segment
to find the match. If ambiguous, ask for clarification.

---

## Demographic & Workforce Composition Dimensions

| Dimension | Source Table | Key Columns |
|---|---|---|
| Job details | Jobs | Job Family, Job Sub Family, Job Management Level |
| EEO reporting | Jobs | EEO Category, EEO Category Code |
| Compensation type | Jobs | FLSA Type (Exempt/Non-Exempt), Salary or Hourly |
| Employee type | Employee Types | Employee Type (Full-Time, Part-Time, Contractor) |
| Age bands | Age Group | Age Group (e.g., 25-34, 35-44) |
| Tenure bands | Years of Service Group | Years of Service Group |
| Gender | People Information | Gender |
| Ethnicity | People Information | Ethnicity |
| Location | Locations | City, State, Country, Timezone, Is Remote |

**Privacy note:** Gender and Ethnicity are sensitive fields. Apply k ≥ 5 minimum group size.
Do not report individual-level demographic data.
