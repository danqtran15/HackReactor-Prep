# People Analytics — Metric Q&A Reference
# For use as a Copilot Studio Knowledge Source
# Contains verified question-answer pairs and metric definitions

---

## Headcount Metrics

### # of Headcount [PA-HC-001]
- **Scope:** Model | **Pattern:** Snapshot | **Summable:** No
- **Definition:** The total number of employees in the organization as of the latest date in the current filter context. Returns a point-in-time snapshot of workforce size.
- **DAX:** `CALCULATE( COUNT(Headcount[People Info PK]), Headcount[Status as of Date] = MAX('Trending Metrics'[Date]) )`
- **Aggregation:** Headcount is a point-in-time snapshot. Summing across months would double-count employees. Each evaluation resolves to the MAX date in the current filter context.
- **Caveats:** Returns the MAX date snapshot — if the report has no date filter, this may be today's count or the latest loaded date.
  Never count Headcount table rows directly — this measure handles the date logic.

**Verified Q&A:**
- Q: "How many employees do we have today?"
  A: Returns count at MAX date in current context
- Q: "How many employees in Gathering & Processing segment?"
  A: Filters Headcount via Department Hierarchy, returns snapshot count

---

### # of Headcount Period Start [PA-HC-002]
- **Scope:** Model | **Pattern:** Snapshot | **Summable:** No
- **Definition:** The number of employees at the beginning of the selected time period. For a month view, returns headcount on the 1st of the month. For a year view, returns headcount on January 1.
- **DAX:** `CALCULATE( COUNT(Headcount[People Info PK]), ALLSELECTED(Headcount[Status as of Date]), STARTOFMONTH('Trending Metrics'[Date]) )`
- **Aggregation:** Snapshot measure — summing across periods is meaningless. Each period resolves independently to the first day of that month.
- **Caveats:** Uses ALLSELECTED to clear any date slicer within the Headcount table, then repositions to start of month via Trending Metrics.

**Verified Q&A:**
- Q: "How many employees did we start March 2025 with?"
  A: Returns headcount on March 1, 2025
- Q: "How many employees did we start the year with?"
  A: Returns headcount on January 1 of the selected year

---

### # of Headcount Period End [PA-HC-003]
- **Scope:** Model | **Pattern:** Snapshot | **Summable:** No
- **Definition:** The number of employees at the end of the selected time period. For a completed month, returns headcount on the last day. For the current (incomplete) month, returns today's count.
- **DAX:** `CALCULATE( COUNT(Headcount[People Info PK]), ALLSELECTED(Headcount[Status as of Date]), ENDOFMONTH('Trending Metrics'[Date]) )`
- **Aggregation:** Snapshot measure. Use this for month-over-month trending — each month resolves independently to its last day.
- **Caveats:** Current month returns today's count, not a true month-end figure. Value finalizes when the month ends.
  Best measure for consistent month-over-month comparisons.

**Verified Q&A:**
- Q: "What was our headcount at the end of each month this year?"
  A: Returns last-day-of-month count for each completed month, today's count for current month

---

### # of Headcount Period Average [PA-HC-004]
- **Scope:** Model | **Pattern:** Average | **Summable:** No
- **Definition:** The average workforce size during a given period, calculated as the midpoint between the start and end headcount. Used as the denominator for monthly turnover calculations.
- **DAX:** `([# of Headcount Period Start] + [# of Headcount Period End]) / 2`
- **Aggregation:** Derived from two snapshot measures. Cannot be summed across periods. Each period must compute its own start/end and derive the average.
- **Caveats:** Simple (Start + End) / 2 average — does not reflect mid-month spikes or dips.
  Primary purpose is as a turnover denominator.

**Verified Q&A:**
- Q: "What was the average headcount in Operations during Q2?"
  A: Returns (Period Start + Period End) / 2 for each month in Q2

---

### # of Headcount YTD Average [PA-HC-005]
- **Scope:** Model | **Pattern:** Average | **Summable:** No
- **Definition:** The running average headcount from January through the selected month. Calculated by averaging the monthly Period Averages across all months elapsed in the year. Used as the denominator for YTD turnover.
- **DAX:** `CALCULATE( SUMX(VALUES('Trending Metrics'[Period (Month YYYY)]), [# of Headcount Period Average]), DATESYTD('Trending Metrics'[Date]) ) / CALCULATE( COUNTX(VALUES('Trending Metrics'[Period (Month YYYY)]), [# of Headcount Period Average]), DATESYTD('Trending Metrics'[Date]) )`
- **Aggregation:** Running average — must be recomputed at each point in time. Cannot be summed or averaged again across periods.
- **Caveats:** Month is the lowest granularity — drilling to days shows the same value.
  Smooths out seasonal fluctuations by averaging across all months YTD.

**Verified Q&A:**
- Q: "What has our average headcount been so far this year?"
  A: Averages monthly Period Averages from Jan through selected month

---

### # of Headcount - This Month MTD [PA-HC-006]
- **Scope:** Report | **Pattern:** Snapshot | **Summable:** No
- **Definition:** Current headcount accumulated month-to-date. Applies DATESMTD to the base headcount measure to show the snapshot within the current month context.
- **DAX:** `CALCULATE([# of Headcount], DATESMTD('Trending Metrics'[Date]))`
- **Aggregation:** Snapshot within MTD context. Cannot be summed across periods.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns headcount snapshot within the current month date range.

**Verified Q&A:**
- Q: "What is the current month headcount?"
  A: Returns headcount snapshot filtered to month-to-date

---

### # of Headcount - Last Month [PA-HC-007]
- **Scope:** Report | **Pattern:** Snapshot | **Summable:** No
- **Definition:** Headcount as of the prior month. Uses DATESINPERIOD ending at last month-end to return the previous month's workforce snapshot.
- **DAX:** `CALCULATE( [# of Headcount], DATESINPERIOD('Trending Metrics'[Date], EOMONTH(TODAY(), -1), -1, MONTH) )`
- **Aggregation:** Snapshot measure — not summable across periods.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Always anchored to the prior calendar month relative to TODAY().

**Verified Q&A:**
- Q: "How many employees did we have last month?"
  A: Returns headcount snapshot for the previous complete month

---

### # of Headcount - Same Period Last Year [PA-HC-008]
- **Scope:** Report | **Pattern:** Snapshot | **Summable:** No
- **Definition:** Headcount at the same point one year ago. Uses SAMEPERIODLASTYEAR for year-over-year comparison of workforce size.
- **DAX:** `CALCULATE([# of Headcount], SAMEPERIODLASTYEAR('Trending Metrics'[Date]))`
- **Aggregation:** Snapshot YoY comparison — not summable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Requires at least one full prior year of data for meaningful results.

**Verified Q&A:**
- Q: "How does our headcount compare to the same time last year?"
  A: Returns headcount at the equivalent date range 12 months prior

---

### # of Headcount - This Month (Latest in Selection) [PA-HC-009]
- **Scope:** Report | **Pattern:** Snapshot | **Summable:** No
- **Definition:** Headcount for the current month based on the latest date in the user's slicer selection. Uses ALLSELECTED to anchor to the latest selected date rather than TODAY().
- **DAX:** `VAR AnchorDate = CALCULATE(MAX('Trending Metrics'[Date]), ALLSELECTED('Trending Metrics'[Date])) VAR MonthStart = DATE(YEAR(AnchorDate), MONTH(AnchorDate), 1) VAR MonthEnd = EOMONTH(AnchorDate, 0) RETURN CALCULATE( [# of Headcount], KEEPFILTERS(DATESBETWEEN('Trending Metrics'[Date], MonthStart, MonthEnd)) )`
- **Aggregation:** Snapshot measure — context-dependent, not summable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Uses ALLSELECTED — behavior depends on slicer/filter context.

**Verified Q&A:**
- Q: "What is the headcount for the selected month?"
  A: Returns headcount for the month containing the latest date in the user's selection

---

### # of Headcount - MoM Variance [PA-HC-010]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Month-over-month change in headcount. Calculated as current MTD headcount minus prior month headcount. Positive values indicate growth.
- **DAX:** `[# of Headcount - This Month MTD] - [# of Headcount - Last Month]`
- **Aggregation:** Variance derived from two snapshots — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Positive = headcount growth; negative = headcount decline.

**Verified Q&A:**
- Q: "Did headcount go up or down compared to last month?"
  A: Returns the numeric difference (current MTD minus last month)

---

### # of Headcount - MoM KPI Arrow [PA-HC-011]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator showing headcount trend direction. Displays an up-arrow (▲) when headcount increased month-over-month, or a down-arrow (▼) when it decreased. Returns a Unicode character, not a number.
- **DAX:** `VAR PositiveIcon = UNICHAR(9650) VAR NegativeIcon = UNICHAR(9660) VAR Result = IF([# of Headcount - MoM Variance] > 0, PositiveIcon, NegativeIcon) RETURN Result`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲ or ▼), not a numeric value.
  Always shows an arrow — even when variance is exactly zero (shows ▼).

**Verified Q&A:**
- Q: "What does the arrow next to headcount mean?"
  A: ▲ = headcount increased MoM; ▼ = headcount decreased MoM

---

### % YoY Change in Headcount [PA-HC-012]
- **Scope:** Report | **Pattern:** Rate | **Summable:** No
- **Definition:** Year-over-year percentage change in headcount. Compares current MTD headcount to the same period last year, expressed as a percentage.
- **DAX:** `DIVIDE( [# of Headcount - This Month MTD] - [# of Headcount - Same Period Last Year], [# of Headcount - Same Period Last Year], 0 )`
- **Aggregation:** YoY ratio — must be recomputed per context, never summed.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns 0 (not BLANK) when prior year data is unavailable due to DIVIDE safe division.

**Verified Q&A:**
- Q: "What is our YoY headcount growth rate?"
  A: Returns percentage change comparing current MTD to same period last year

---

### Arrow - Headcount YoY % Change [PA-HC-013]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator for year-over-year headcount change. Displays ▲ for growth, ▼ for decline, or blank for no change. Returns a Unicode character.
- **DAX:** `CALCULATE( IF([% YoY Change in Headcount] > 0, UNICHAR(9650), IF([% YoY Change in Headcount] < 0, UNICHAR(9660), "")) )`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲, ▼, or blank).

**Verified Q&A:**
- Q: "What does the YoY arrow mean?"
  A: ▲ = headcount grew YoY; ▼ = headcount declined YoY; blank = no change

---

## Hires Metrics

### # of Hires [PA-HR-001]
- **Scope:** Model | **Pattern:** EventCount | **Summable:** Yes
- **Definition:** The total number of new employees hired during the selected time period. Each new employee joining the company counts as one hire event.
- **DAX:** `CALCULATE(COUNT(Hires[People Info PK]))`
- **Aggregation:** Simple event count — safely summable across departments, locations, and time periods. Each hire event is counted exactly once.
- **Caveats:** Includes both new hires and rehires. Filter by Job Change Reason to separate.
  Connected to Trending Metrics via Hire Date for time-based analysis.

**Verified Q&A:**
- Q: "How many people did we hire in March 2025?"
  A: Counts all hire events with Hire Date in March 2025
- Q: "How many hires in Operations vs. Finance?"
  A: Counts filtered by Department Hierarchy — values are additive

---

### # of Hires YTD [PA-HR-002]
- **Scope:** Model | **Pattern:** CumulativeCount | **Summable:** No
- **Definition:** The running total of all hires from January 1 through the selected date in the current year. Accumulates hire counts across months.
- **DAX:** `CALCULATE( COUNT(Hires[People Info PK]), DATESYTD('Trending Metrics'[Date]) )`
- **Aggregation:** Cumulative YTD measure. Summing YTD values across months would massively overcount. Each period already includes all prior months.
- **Caveats:** YTD resets each January 1.
  At the year level, equals the annual total.

**Verified Q&A:**
- Q: "How many people have we hired so far this year?"
  A: Cumulative count from Jan 1 through latest date in context

---

### # of Hires - This Month MTD [PA-HR-003]
- **Scope:** Report | **Pattern:** CumulativeCount | **Summable:** No
- **Definition:** Hire count accumulated month-to-date. Applies DATESMTD to the base hire count to show hiring activity within the current month.
- **DAX:** `CALCULATE([# of Hires], DATESMTD('Trending Metrics'[Date]))`
- **Aggregation:** MTD cumulative count — not summable across months.
- **Caveats:** Report-level measure; not stored in the semantic model.

**Verified Q&A:**
- Q: "How many hires so far this month?"
  A: Returns hire count for the current month through today

---

### # of Hires - Last Month [PA-HR-004]
- **Scope:** Report | **Pattern:** EventCount | **Summable:** No
- **Definition:** Total hires in the previous calendar month. Uses DATESINPERIOD ending at last month-end to isolate prior month hiring activity.
- **DAX:** `CALCULATE( [# of Hires], DATESINPERIOD('Trending Metrics'[Date], EOMONTH(TODAY(), -1), -1, MONTH) )`
- **Aggregation:** Prior-period event count — not summable across months.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Always anchored to the prior calendar month relative to TODAY().

**Verified Q&A:**
- Q: "How many hires did we have last month?"
  A: Returns total hire count for the previous complete month

---

### # of Hires - This Month (Latest in Selection) [PA-HR-005]
- **Scope:** Report | **Pattern:** EventCount | **Summable:** No
- **Definition:** Hire count for the month containing the latest date in the user's slicer selection. Uses ALLSELECTED to anchor to the user's chosen context.
- **DAX:** `VAR AnchorDate = CALCULATE(MAX('Trending Metrics'[Date]), ALLSELECTED('Trending Metrics'[Date])) VAR MonthStart = DATE(YEAR(AnchorDate), MONTH(AnchorDate), 1) VAR MonthEnd = EOMONTH(AnchorDate, 0) RETURN CALCULATE( [# of Hires], KEEPFILTERS(DATESBETWEEN('Trending Metrics'[Date], MonthStart, MonthEnd)) )`
- **Aggregation:** Context-dependent event count — not summable across periods.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Uses ALLSELECTED — behavior depends on slicer/filter context.

**Verified Q&A:**
- Q: "How many hires in the selected month?"
  A: Returns hire count for the month of the latest date in user's selection

---

### # of Hires - This Month (Selection) [PA-HR-006]
- **Scope:** Report | **Pattern:** EventCount | **Summable:** No
- **Definition:** Hire count for the month of the current row context date. Uses MAX date (not ALLSELECTED) so it responds to each row in a matrix or chart.
- **DAX:** `VAR AnchorDate = MAX('Trending Metrics'[Date]) VAR MonthStart = DATE(YEAR(AnchorDate), MONTH(AnchorDate), 1) VAR MonthEnd = EOMONTH(AnchorDate, 0) RETURN CALCULATE( [# of Hires], KEEPFILTERS(DATESBETWEEN('Trending Metrics'[Date], MonthStart, MonthEnd)) )`
- **Aggregation:** Context-dependent event count — responds to row-level date context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Uses MAX (row context) not ALLSELECTED — behaves differently in matrices.

**Verified Q&A:**
- Q: "How many hires in this specific month?"
  A: Returns hire count for the month derived from the row's MAX date

---

### # of Hires - MoM Variance [PA-HR-007]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Month-over-month change in hiring. Current MTD hires minus prior month hires. Positive values indicate increased hiring activity.
- **DAX:** `[# of Hires - This Month MTD] - [# of Hires - Last Month]`
- **Aggregation:** Variance derived from two period counts — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Positive = more hires this month; negative = fewer hires.

**Verified Q&A:**
- Q: "Are we hiring more or less than last month?"
  A: Returns numeric difference (current MTD minus last month hires)

---

### # of Hires - MoM KPI Arrow [PA-HR-008]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator for month-over-month hiring trend. Displays ▲ when hiring increased or ▼ when hiring decreased. Returns a Unicode character.
- **DAX:** `VAR PositiveIcon = UNICHAR(9650) VAR NegativeIcon = UNICHAR(9660) VAR Result = IF([# of Hires - MoM Variance] > 0, PositiveIcon, NegativeIcon) RETURN Result`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲ or ▼), not a numeric value.

**Verified Q&A:**
- Q: "What does the hiring arrow mean?"
  A: ▲ = hiring increased MoM; ▼ = hiring decreased MoM

---

## Terminations Metrics

### # of Terminations [PA-TM-001]
- **Scope:** Model | **Pattern:** EventCount | **Summable:** Yes
- **Definition:** The total number of employees who left the company during the selected time period. Includes voluntary resignations, involuntary terminations, and retirements.
- **DAX:** `CALCULATE(COUNT(Terminations[People Info PK]))`
- **Aggregation:** Simple event count — safely summable across all dimensions and time periods.
- **Caveats:** Includes ALL departure types. Filter by Termination Type for voluntary-only analysis.

**Verified Q&A:**
- Q: "How many people left Operations last month?"
  A: Counts termination events filtered by department and month

---

### # of Terminations YTD [PA-TM-002]
- **Scope:** Model | **Pattern:** CumulativeCount | **Summable:** No
- **Definition:** The running total of all terminations from January 1 through the selected date in the current year.
- **DAX:** `CALCULATE( COUNT(Terminations[People Info PK]), DATESYTD('Trending Metrics'[Date]) )`
- **Aggregation:** Cumulative YTD measure. Each period already includes all prior months — summing would massively overcount.
- **Caveats:** YTD resets each January 1.

**Verified Q&A:**
- Q: "How many total terminations have we had this year?"
  A: Cumulative count from Jan 1 through latest date

---

### # of Terminations (Voluntary) [PA-TM-003]
- **Scope:** Report | **Pattern:** EventCount | **Summable:** Yes
- **Definition:** Count of voluntary terminations only. Filters the base termination count to Termination Type = Voluntary (resignations, retirements by choice).
- **DAX:** `CALCULATE([# of Terminations], Terminations[Termination Type] = "Voluntary")`
- **Aggregation:** Filtered event count — summable across time periods and departments within the Voluntary filter.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Hard-filters to Voluntary — cannot be further filtered by Termination Type slicer.

**Verified Q&A:**
- Q: "How many people voluntarily left last quarter?"
  A: Counts terminations where Termination Type = Voluntary

---

### # of Terminations (Involuntary) [PA-TM-004]
- **Scope:** Report | **Pattern:** EventCount | **Summable:** Yes
- **Definition:** Count of involuntary terminations only. Filters the base termination count to Termination Type = Involuntary (layoffs, dismissals).
- **DAX:** `CALCULATE([# of Terminations], Terminations[Termination Type] = "Involuntary")`
- **Aggregation:** Filtered event count — summable across time periods and departments within the Involuntary filter.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Hard-filters to Involuntary — cannot be further filtered by Termination Type slicer.

**Verified Q&A:**
- Q: "How many involuntary terminations occurred this year?"
  A: Counts terminations where Termination Type = Involuntary

---

### # of Terminations - This Month MTD [PA-TM-005]
- **Scope:** Report | **Pattern:** CumulativeCount | **Summable:** No
- **Definition:** Termination count accumulated month-to-date. Applies DATESMTD to the base termination count.
- **DAX:** `CALCULATE([# of Terminations], DATESMTD('Trending Metrics'[Date]))`
- **Aggregation:** MTD cumulative count — not summable across months.
- **Caveats:** Report-level measure; not stored in the semantic model.

**Verified Q&A:**
- Q: "How many terminations so far this month?"
  A: Returns termination count for current month through today

---

### # of Terminations - Last Month [PA-TM-006]
- **Scope:** Report | **Pattern:** EventCount | **Summable:** No
- **Definition:** Total terminations in the previous calendar month. Uses DATESINPERIOD ending at last month-end.
- **DAX:** `CALCULATE( [# of Terminations], DATESINPERIOD('Trending Metrics'[Date], EOMONTH(TODAY(), -1), -1, MONTH) )`
- **Aggregation:** Prior-period event count — not summable across months.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Always anchored to the prior calendar month relative to TODAY().

**Verified Q&A:**
- Q: "How many terminations did we have last month?"
  A: Returns total termination count for the previous complete month

---

### # of Terminations Last 12 Months (Excluding Current Month) [PA-TM-007]
- **Scope:** Report | **Pattern:** CumulativeCount | **Summable:** No
- **Definition:** Rolling 12-month termination count, excluding the current incomplete month. Uses DATESINPERIOD starting one month before the latest date and looking back 12 months.
- **DAX:** `CALCULATE( [# of Terminations], DATESINPERIOD('Trending Metrics'[Date], EDATE(MAX('Trending Metrics'[Date]), -1), -12, MONTH) )`
- **Aggregation:** Rolling window count — not summable across periods.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Excludes the current (incomplete) month to avoid partial-period bias.
  Used as input for rolling 12-month moving averages.

**Verified Q&A:**
- Q: "How many terminations in the last 12 complete months?"
  A: Returns count for the 12-month window ending one month before the latest date

---

### # of Terminations - MoM Variance [PA-TM-008]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Month-over-month change in terminations. Current MTD minus prior month. Positive values indicate more terminations.
- **DAX:** `[# of Terminations - This Month MTD] - [# of Terminations - Last Month]`
- **Aggregation:** Variance derived from two period counts — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Positive = more terminations this month; negative = fewer.

**Verified Q&A:**
- Q: "Are terminations trending up or down?"
  A: Returns numeric difference (current MTD minus last month terminations)

---

### # of Terminations - MoM KPI Arrow [PA-TM-009]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator for month-over-month termination trend. Displays ▲ when terminations increased or ▼ when decreased. Returns a Unicode character.
- **DAX:** `VAR PositiveIcon = UNICHAR(9650) VAR NegativeIcon = UNICHAR(9660) VAR Result = IF([# of Terminations - MoM Variance] > 0, PositiveIcon, NegativeIcon) RETURN Result`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲ or ▼), not a numeric value.
  For terminations, ▲ (increase) is typically negative for the business.

**Verified Q&A:**
- Q: "What does the termination arrow mean?"
  A: ▲ = terminations increased MoM; ▼ = terminations decreased MoM

---

## Turnover Metrics

### % Turnover Monthly [PA-TO-001]
- **Scope:** Model | **Pattern:** Rate | **Summable:** No
- **Definition:** The turnover rate for a single month, calculated as terminations divided by the period average headcount. This is an intermediate calculation used by other turnover measures.
- **DAX:** `[# of Terminations] / [# of Headcount Period Average]`
- **Aggregation:** Turnover is a ratio — it must never be summed across months or dimensions. Each context must recompute from its own terminations and headcount.
- **Caveats:** HIDDEN from report builders — intermediate calculation only.
  Use % Turnover YTD, Monthly Average, or Annualized for reporting.

**Verified Q&A:**
- Q: "Why can't I find % Turnover Monthly in the field list?"
  A: It is hidden — use % Turnover Annualized or % Turnover YTD instead

---

### % Turnover YTD [PA-TO-002]
- **Scope:** Model | **Pattern:** Rate | **Summable:** No
- **Definition:** The total turnover rate from January 1 through the selected month, expressed as a percentage. Calculated as year-to-date terminations divided by the YTD average headcount.
- **DAX:** `CALCULATE( SUMX(VALUES('Trending Metrics'[Period (Month YYYY)]), CALCULATE([# of Terminations YTD], ALLSELECTED('Trending Metrics'))), ENDOFMONTH('Trending Metrics'[Date]) ) / [# of Headcount YTD Average]`
- **Aggregation:** YTD ratio — must be recomputed from YTD terminations and YTD average headcount at each point. Never sum or average turnover percentages across periods.
- **Caveats:** Calculated at monthly level — all days in a month show the same value.
  Uses ENDOFMONTH to resolve the numerator at month boundaries.
  Complex DAX with ALLSELECTED context manipulation.

**Verified Q&A:**
- Q: "What is our turnover rate so far this year?"
  A: YTD terminations / YTD average headcount, recomputed at each month
- Q: "What is YTD turnover for Q1?"
  A: Through March: cumulative terminations Jan-Mar / YTD avg headcount

---

### % Turnover Monthly Average [PA-TO-003]
- **Scope:** Model | **Pattern:** DerivedRate | **Summable:** No
- **Definition:** The average monthly turnover rate for the year so far. Calculated by dividing the YTD turnover rate by the number of months elapsed. Used as the basis for annualized turnover projections.
- **DAX:** `[% Turnover YTD] / MAX('Trending Metrics'[Month])`
- **Aggregation:** Derived ratio — divides a cumulative percentage by months elapsed. Must be recomputed at each time point.
- **Caveats:** Uses MAX(Month) as the divisor — assumes the selected month number represents months elapsed.
  In January, equals the full monthly rate; by December, smooths across 12 months.

**Verified Q&A:**
- Q: "On average, what percentage of our workforce leaves each month?"
  A: YTD turnover / months elapsed (e.g., 6% YTD through June = 1.0% monthly avg)

---

### % Turnover Annualized [PA-TO-004]
- **Scope:** Model | **Pattern:** DerivedRate | **Summable:** No
- **Definition:** The projected full-year turnover rate based on the trend observed so far this year. Calculated by multiplying the monthly average turnover rate by 12.
- **DAX:** `[% Turnover Monthly Average] * 12`
- **Aggregation:** Projected annual rate. Must never be summed or averaged across periods — it is already an annualized projection at each point.
- **Caveats:** Early in the year (Q1), projections are based on limited data and may be unreliable.
  Assumes the monthly average pace continues for the remainder of the year.
  Use with caution for executive reporting in January/February.

**Verified Q&A:**
- Q: "At the current pace, what will our full-year turnover rate be?"
  A: Monthly average turnover * 12 (e.g., 1.0% monthly avg = 12.0% annualized)
- Q: "How does our projected turnover compare to the industry benchmark of 15%?"
  A: Returns annualized rate for comparison — but flag if Q1 data only

---

### % Turnover Annualized - This Month MTD [PA-TO-005]
- **Scope:** Report | **Pattern:** DerivedRate | **Summable:** No
- **Definition:** Annualized turnover rate for the current month-to-date. Applies DATESMTD context to the base annualized turnover measure.
- **DAX:** `CALCULATE([% Turnover Annualized], DATESMTD('Trending Metrics'[Date]))`
- **Aggregation:** MTD rate — must be recomputed per context, never summed.
- **Caveats:** Report-level measure; not stored in the semantic model.

**Verified Q&A:**
- Q: "What is the annualized turnover rate this month?"
  A: Returns annualized turnover filtered to month-to-date context

---

### % Turnover Annualized - Last Month [PA-TO-006]
- **Scope:** Report | **Pattern:** DerivedRate | **Summable:** No
- **Definition:** Annualized turnover rate for the previous calendar month. Uses DATESINPERIOD ending at last month-end.
- **DAX:** `CALCULATE( [% Turnover Annualized], DATESINPERIOD('Trending Metrics'[Date], EOMONTH(TODAY(), -1), -1, MONTH) )`
- **Aggregation:** Prior-period rate — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Always anchored to prior calendar month relative to TODAY().

**Verified Q&A:**
- Q: "What was the annualized turnover rate last month?"
  A: Returns annualized turnover for the previous complete month

---

### % Turnover Annualized - Previous Month [PA-TO-007]
- **Scope:** Report | **Pattern:** DerivedRate | **Summable:** No
- **Definition:** Annualized turnover rate for the previous month using PREVIOUSMONTH time intelligence. Differs from Last Month in that it follows the filter context rather than being anchored to TODAY().
- **DAX:** `CALCULATE([% Turnover Annualized], PREVIOUSMONTH('Trending Metrics'[Date]))`
- **Aggregation:** Prior-period rate using PREVIOUSMONTH — context-relative, not summable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Uses PREVIOUSMONTH — moves relative to the date filter, not relative to TODAY().

**Verified Q&A:**
- Q: "What was last month's annualized turnover?"
  A: Returns annualized turnover for the month prior to the current filter context

---

### % Turnover Annualized - Same Period Last Year [PA-TO-008]
- **Scope:** Report | **Pattern:** DerivedRate | **Summable:** No
- **Definition:** Annualized turnover rate at the same point one year ago. Uses SAMEPERIODLASTYEAR for year-over-year comparison.
- **DAX:** `CALCULATE([% Turnover Annualized], SAMEPERIODLASTYEAR('Trending Metrics'[Date]))`
- **Aggregation:** YoY comparison rate — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Requires at least one full prior year of data.

**Verified Q&A:**
- Q: "What was the turnover rate at this time last year?"
  A: Returns annualized turnover for the equivalent period 12 months prior

---

### % Turnover Annualized - MoM Variance [PA-TO-009]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Month-over-month change in annualized turnover rate, expressed in basis points (multiplied by 100). Positive values indicate turnover is increasing.
- **DAX:** `([% Turnover Annualized - This Month MTD] - [% Turnover Annualized - Last Month]) * 100`
- **Aggregation:** Variance of rates — must be recomputed per context, never summed.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Multiplied by 100 for display — a value of 1.0 means a 1 percentage point increase.
  For turnover, positive variance (increasing rate) is typically negative for business.

**Verified Q&A:**
- Q: "Is turnover getting better or worse?"
  A: Returns the change in annualized rate (x100) between current MTD and last month

---

### % Turnover Annualized - MoM Variance % [PA-TO-010]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Month-over-month percentage change in the annualized turnover rate. Shows how much the rate itself changed as a percentage of the prior month's rate.
- **DAX:** `VAR PrevMonth = [% Turnover Annualized - Previous Month] RETURN IF( NOT ISBLANK(PrevMonth), DIVIDE([% Turnover Annualized] - PrevMonth, PrevMonth), BLANK() )`
- **Aggregation:** Percentage change of a rate — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns BLANK when prior month data is unavailable.
  This is the % change OF the rate, not the rate itself.

**Verified Q&A:**
- Q: "By what percentage did the turnover rate change?"
  A: Returns percentage change relative to prior month's rate (e.g., 10% means rate grew by 10%)

---

### % Turnover Annualized - MoM KPI Arrow [PA-TO-011]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator for month-over-month turnover rate trend. Displays ▲ when turnover rate increased or ▼ when decreased. Returns a Unicode character.
- **DAX:** `VAR PositiveIcon = UNICHAR(9650) VAR NegativeIcon = UNICHAR(9660) VAR Result = IF([% Turnover Annualized - MoM Variance] > 0, PositiveIcon, NegativeIcon) RETURN Result`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲ or ▼).
  For turnover, ▲ (increasing rate) is typically a negative business signal.

**Verified Q&A:**
- Q: "What does the turnover KPI arrow mean?"
  A: ▲ = turnover rate increased MoM; ▼ = turnover rate decreased MoM

---

### % YoY Change Turnover Rate [PA-TO-012]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Year-over-year change in the annualized turnover rate. Subtracts the same-period-last-year rate from the current rate. Expressed as a percentage-point difference.
- **DAX:** `[% Turnover Annualized] - [% Turnover Annualized - Same Period Last Year]`
- **Aggregation:** YoY variance of rates — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Positive = turnover rate is higher than last year (typically negative for business).
  Result is a percentage-point difference, not a ratio.

**Verified Q&A:**
- Q: "Is turnover higher or lower than last year?"
  A: Returns the difference in annualized rate vs same period last year

---

### Arrow - Turnover YoY % Change [PA-TO-013]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator for year-over-year turnover rate change. Displays ▲ for increase, ▼ for decrease, or blank for no change.
- **DAX:** `CALCULATE( IF([% YoY Change Turnover Rate] > 0, UNICHAR(9650), IF([% YoY Change Turnover Rate] < 0, UNICHAR(9660), "")) )`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲, ▼, or blank).

**Verified Q&A:**
- Q: "What does the YoY turnover arrow mean?"
  A: ▲ = turnover rate increased YoY; ▼ = decreased; blank = no change

---

### Turnover Rate - % YoY Change (Involuntary) [PA-TO-014]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Year-over-year change in turnover rate filtered to involuntary terminations only. Shows whether involuntary turnover is trending up or down compared to last year.
- **DAX:** `CALCULATE( [% YoY Change Turnover Rate], Terminations[Termination Type] = "Involuntary" )`
- **Aggregation:** Filtered YoY variance — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Hard-filtered to Involuntary — Termination Type slicer has no additional effect.

**Verified Q&A:**
- Q: "Is involuntary turnover higher or lower than last year?"
  A: Returns YoY change in annualized rate filtered to involuntary terminations

---

### Turnover Rate - % YoY Change (Voluntary) [PA-TO-015]
- **Scope:** Report | **Pattern:** Variance | **Summable:** No
- **Definition:** Year-over-year change in turnover rate filtered to voluntary terminations only. Shows whether voluntary turnover is trending up or down compared to last year.
- **DAX:** `CALCULATE( [% YoY Change Turnover Rate], Terminations[Termination Type] = "Voluntary" )`
- **Aggregation:** Filtered YoY variance — must be recomputed per context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Hard-filtered to Voluntary — Termination Type slicer has no additional effect.

**Verified Q&A:**
- Q: "Is voluntary turnover higher or lower than last year?"
  A: Returns YoY change in annualized rate filtered to voluntary terminations

---

### Arrow - Involuntary Turnover YoY % Change [PA-TO-016]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator for year-over-year involuntary turnover rate change. Displays ▲ for increase, ▼ for decrease, or blank for no change.
- **DAX:** `CALCULATE( IF([% YoY Change Turnover Rate] > 0, UNICHAR(9650), IF([% YoY Change Turnover Rate] < 0, UNICHAR(9660), "")), Terminations[Termination Type] = "Involuntary" )`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲, ▼, or blank).
  Hard-filtered to Involuntary termination type.

**Verified Q&A:**
- Q: "What does the involuntary turnover arrow mean?"
  A: ▲ = involuntary turnover rate increased YoY; ▼ = decreased; blank = no change

---

### Arrow - Voluntary Turnover YoY % Change [PA-TO-017]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Visual indicator for year-over-year voluntary turnover rate change. Displays ▲ for increase, ▼ for decrease, or blank for no change.
- **DAX:** `CALCULATE( IF([% YoY Change Turnover Rate] > 0, UNICHAR(9650), IF([% YoY Change Turnover Rate] < 0, UNICHAR(9660), "")), Terminations[Termination Type] = "Voluntary" )`
- **Aggregation:** Visual indicator — not summable or aggregatable.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character (▲, ▼, or blank).
  Hard-filtered to Voluntary termination type.

**Verified Q&A:**
- Q: "What does the voluntary turnover arrow mean?"
  A: ▲ = voluntary turnover rate increased YoY; ▼ = decreased; blank = no change

---

### 12 Months Terms Moving Average (Involuntary) [PA-TO-018]
- **Scope:** Report | **Pattern:** Average | **Summable:** No
- **Definition:** Rolling 12-month average of monthly involuntary terminations, excluding the current month. Divides the 12-month involuntary term count by 12 to smooth seasonal variation.
- **DAX:** `DIVIDE( CALCULATE( [# of Terminations Last 12 Months (Excluding Current Month)], Terminations[Termination Type] = "Involuntary" ), 12, 0 )`
- **Aggregation:** Rolling average — overlapping windows make summation invalid.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Excludes current incomplete month for accuracy.
  Returns 0 (not BLANK) when no terminations exist in the window.

**Verified Q&A:**
- Q: "What is the average monthly involuntary termination count?"
  A: Returns rolling 12-month involuntary terminations divided by 12

---

### 12 Months Terms Moving Average (Voluntary) [PA-TO-019]
- **Scope:** Report | **Pattern:** Average | **Summable:** No
- **Definition:** Rolling 12-month average of monthly voluntary terminations, excluding the current month. Divides the 12-month voluntary term count by 12 to smooth seasonal variation.
- **DAX:** `DIVIDE( CALCULATE( [# of Terminations Last 12 Months (Excluding Current Month)], Terminations[Termination Type] = "Voluntary" ), 12, 0 )`
- **Aggregation:** Rolling average — overlapping windows make summation invalid.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Excludes current incomplete month for accuracy.
  Returns 0 (not BLANK) when no terminations exist in the window.

**Verified Q&A:**
- Q: "What is the average monthly voluntary termination count?"
  A: Returns rolling 12-month voluntary terminations divided by 12

---

## Utility Metrics

### SelectedYear [PA-UT-001]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Returns the year value currently selected by the user in the Trending Metrics date slicer. Used as a helper for other report-level calculations.
- **DAX:** `SELECTEDVALUE('Trending Metrics'[Year])`
- **Aggregation:** Helper measure — returns a single scalar value from slicer context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns BLANK if multiple years are selected or no year is selected.

**Verified Q&A:**
- Q: "What year is selected?"
  A: Returns the single year value from the Trending Metrics Year slicer

---

### PreviousYear [PA-UT-002]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Returns the year before the currently selected year. Simple helper that subtracts 1 from SelectedYear. Used for YoY comparison labels and dynamic titles.
- **DAX:** `[SelectedYear] - 1`
- **Aggregation:** Helper measure — returns a derived scalar value.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns BLANK if SelectedYear is BLANK (no year or multiple years selected).

**Verified Q&A:**
- Q: "What was the previous year?"
  A: Returns SelectedYear minus 1

---

### Info Icon [PA-UT-003]
- **Scope:** Report | **Pattern:** Other | **Summable:** No
- **Definition:** Returns the Unicode information icon (ⓘ) for use as a visual element in report tooltips and info buttons. Static value, no calculation logic.
- **DAX:** `UNICHAR(9432)`
- **Aggregation:** Static value — always returns the same Unicode character regardless of context.
- **Caveats:** Report-level measure; not stored in the semantic model.
  Returns Unicode character ⓘ (U+24D8).
  Used purely for visual decoration in reports.

**Verified Q&A:**
- Q: "What is the Info Icon measure?"
  A: Returns the ⓘ Unicode character for use in report visuals

---

