# People Analytics — Business Glossary & Synonym Map
# For use as a Copilot Studio Knowledge Source
# Generated: 2026-05-05

This document maps common business terminology to the correct measures and concepts
in the People Analytics semantic model. Use this to resolve user questions that use
informal language, abbreviations, or synonyms.

---

## Term → Measure Mapping

### Headcount / Employee Count

| User might say | Correct measure | Metric ID |
|---|---|---|
| headcount, employee count, workforce size, how many employees, total employees, staff count, FTE count, number of people | # of Headcount | PA-HC-001 |
| starting headcount, beginning headcount, how many at the start | # of Headcount Period Start | PA-HC-002 |
| ending headcount, month-end headcount, how many at end of month | # of Headcount Period End | PA-HC-003 |
| average headcount, average employees, avg headcount | # of Headcount Period Average | PA-HC-004 |
| YTD average headcount, year-to-date average | # of Headcount YTD Average | PA-HC-005 |
| current headcount, headcount this month, MTD headcount | # of Headcount - This Month MTD | PA-HC-006 |
| last month headcount, prior month headcount | # of Headcount - Last Month | PA-HC-007 |
| headcount last year, same time last year headcount, SPLY headcount | # of Headcount - Same Period Last Year | PA-HC-008 |
| latest headcount in range, most recent headcount | # of Headcount - This Month (Latest in Selection) | PA-HC-009 |
| headcount change, month-over-month change, MoM headcount | # of Headcount - MoM Variance | PA-HC-010 |
| headcount trend arrow, headcount direction | # of Headcount - MoM KPI Arrow | PA-HC-011 |
| year-over-year headcount change, YoY headcount growth | % YoY Change in Headcount | PA-HC-012 |
| headcount YoY arrow, growth direction | Arrow - Headcount YoY % Change | PA-HC-013 |

### Hiring / New Employees

| User might say | Correct measure | Metric ID |
|---|---|---|
| hires, new hires, new employees, people hired, hiring count, additions | # of Hires | PA-HR-001 |
| hires this year, YTD hires, year-to-date hires | # of Hires YTD | PA-HR-002 |
| hires this month, MTD hires | # of Hires - This Month MTD | PA-HR-003 |
| hires last month, prior month hires | # of Hires - Last Month | PA-HR-004 |
| latest hires, most recent month hires | # of Hires - This Month (Latest in Selection) | PA-HR-005 |
| hires in selected month | # of Hires - This Month (Selection) | PA-HR-006 |
| hiring change, MoM hires change | # of Hires - MoM Variance | PA-HR-007 |
| hiring trend arrow, hiring direction | # of Hires - MoM KPI Arrow | PA-HR-008 |

### Terminations / Attrition / Separations

| User might say | Correct measure | Metric ID |
|---|---|---|
| terminations, terms, separations, exits, people who left, departures, attrition count, losses | # of Terminations | PA-TM-001 |
| terminations this year, YTD terminations, year-to-date terms | # of Terminations YTD | PA-TM-002 |
| voluntary terminations, voluntary attrition, resignations, quits, people who chose to leave | # of Terminations (Voluntary) | PA-TM-003 |
| involuntary terminations, involuntary attrition, layoffs, dismissals, fired, RIF | # of Terminations (Involuntary) | PA-TM-004 |
| terminations this month, MTD terminations | # of Terminations - This Month MTD | PA-TM-005 |
| terminations last month, prior month terms | # of Terminations - Last Month | PA-TM-006 |
| trailing 12 month terminations, last 12 months terms, rolling year terms | # of Terminations Last 12 Months (Excluding Current Month) | PA-TM-007 |
| termination change, MoM terms change | # of Terminations - MoM Variance | PA-TM-008 |
| termination trend arrow | # of Terminations - MoM KPI Arrow | PA-TM-009 |

### Turnover Rate

| User might say | Correct measure | Metric ID |
|---|---|---|
| turnover rate, monthly turnover, attrition rate (monthly) | % Turnover Monthly | PA-TO-001 |
| YTD turnover, turnover so far this year | % Turnover YTD | PA-TO-002 |
| average monthly turnover, average turnover rate | % Turnover Monthly Average | PA-TO-003 |
| annualized turnover, turnover rate, attrition rate, annual turnover | % Turnover Annualized | PA-TO-004 |
| current turnover rate, MTD turnover | % Turnover Annualized - This Month MTD | PA-TO-005 |
| last month turnover, prior month turnover | % Turnover Annualized - Last Month | PA-TO-006 |
| previous month turnover | % Turnover Annualized - Previous Month | PA-TO-007 |
| turnover last year, same period last year turnover, SPLY turnover | % Turnover Annualized - Same Period Last Year | PA-TO-008 |
| turnover change, MoM turnover change | % Turnover Annualized - MoM Variance | PA-TO-009 |
| turnover change percent, MoM turnover % change | % Turnover Annualized - MoM Variance % | PA-TO-010 |
| turnover trend arrow, turnover direction | % Turnover Annualized - MoM KPI Arrow | PA-TO-011 |
| year-over-year turnover change, YoY turnover, turnover compared to last year | % YoY Change Turnover Rate | PA-TO-012 |
| turnover YoY arrow | Arrow - Turnover YoY % Change | PA-TO-013 |
| involuntary turnover YoY change | Turnover Rate - % YoY Change (Involuntary) | PA-TO-014 |
| voluntary turnover YoY change | Turnover Rate - % YoY Change (Voluntary) | PA-TO-015 |
| involuntary turnover YoY arrow | Arrow - Involuntary Turnover YoY % Change | PA-TO-016 |
| voluntary turnover YoY arrow | Arrow - Voluntary Turnover YoY % Change | PA-TO-017 |
| rolling average involuntary terms, 12-month moving average involuntary | 12 Months Terms Moving Average (Involuntary) | PA-TO-018 |
| rolling average voluntary terms, 12-month moving average voluntary | 12 Months Terms Moving Average (Voluntary) | PA-TO-019 |

### Net Movement / Workforce Change

| User might say | Correct measure | Derivation |
|---|---|---|
| net movement, net change, net workforce change, growth vs losses | Hires minus Terminations | Derived: [# of Hires] − [# of Terminations] |

> **Note:** Net Movement is not a standalone measure in the semantic model. It is calculated as Hires minus Terminations. The Fabric Data Agent may derive this.

### Utility Measures (Report Helpers)

| User might say | Correct measure | Metric ID |
|---|---|---|
| what year is selected, current year | SelectedYear | PA-UT-001 |
| previous year, last year, prior year | PreviousYear | PA-UT-002 |
| info icon | Info Icon | PA-UT-003 |

---

## Concept Synonyms (General)

| Informal Term | Standard Term in This Model |
|---|---|
| attrition | turnover (use Turnover measures, not "attrition" column) |
| retention | inverse of turnover — model tracks turnover, not retention directly |
| churn | turnover |
| FTE | headcount (model does not distinguish FTE vs headcount) |
| staff | employees / headcount |
| workforce | headcount |
| talent | employees (in context of hires/losses) |
| org, organization | Department Hierarchy / Responsibility Center levels |
| business unit, segment, division | Responsibility Center Level 01 or 02 |
| department, group | Responsibility Center Level 03, 04, or 05 |
| region, location, geography | Locations table (via People Information) |
| quit, resigned | voluntary termination |
| fired, let go, laid off, RIF | involuntary termination |
| MoM | month-over-month |
| YoY | year-over-year |
| YTD | year-to-date |
| MTD | month-to-date |
| SPLY | same period last year |
| trending, trend | use Trending Metrics date table for time-series |

---

## Time Grain Mapping

| User says | Use this time field | Table |
|---|---|---|
| daily, by day | Date | Trending Metrics |
| monthly, by month, each month | Period (Month YYYY) or End of Month | Trending Metrics |
| quarterly, by quarter | Derived from Period | Trending Metrics |
| annually, by year, yearly | Year | Trending Metrics |
| month-to-date, MTD | Use MTD variant measures (e.g., PA-HC-006) | — |
| year-to-date, YTD | Use YTD variant measures (e.g., PA-HR-002) | — |

---

## Department / Org Hierarchy Mapping

| User says | Map to |
|---|---|
| company, enterprise, Targa | No filter (all data) |
| segment, business unit | Responsibility Center Level 01 |
| division | Responsibility Center Level 02 |
| department | Responsibility Center Level 03 |
| group, team | Responsibility Center Level 04 or 05 |
| Gathering & Processing, G&P | Look up in Responsibility Center Level 01-02 |
| Logistics & Transportation | Look up in Responsibility Center Level 01-02 |
| Corporate, G&A | Look up in Responsibility Center Level 01-02 |

> **Rule:** When a user says a department name, search Responsibility Center Levels 01-05
> for a match. If multiple matches exist, ask which level they mean.

---

## Measure Scope Clarification

| Scope | Meaning | User impact |
|---|---|---|
| Model | Defined in the semantic model. Available for Fabric Data Agent queries. | Can be used in DAX queries directly. |
| Report | Defined in the Power BI report, not the semantic model. | May not be available through the Fabric Data Agent. Use the underlying model measures instead. |

### Report-Scope Measure Equivalents

When a user asks for a report-level measure and the Fabric Data Agent cannot find it,
use the underlying model measure with appropriate filters:

| Report measure | Equivalent using model measures |
|---|---|
| # of Headcount - This Month MTD | CALCULATE([# of Headcount], DATESMTD(...)) |
| # of Headcount - Last Month | CALCULATE([# of Headcount], PREVIOUSMONTH(...)) |
| # of Hires - Last Month | CALCULATE([# of Hires], PREVIOUSMONTH(...)) |
| # of Terminations - Last Month | CALCULATE([# of Terminations], PREVIOUSMONTH(...)) |
| # of Terminations (Voluntary) | CALCULATE([# of Terminations], Terminations[Termination Type] = "Voluntary") |
| # of Terminations (Involuntary) | CALCULATE([# of Terminations], Terminations[Termination Type] = "Involuntary") |
