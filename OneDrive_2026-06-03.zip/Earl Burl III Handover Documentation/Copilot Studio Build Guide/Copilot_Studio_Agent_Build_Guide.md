# Copilot Studio Agent Build Guide

**Building Production AI Analytics Agents with Microsoft Copilot Studio + Fabric Data Agent**

> **Version:** 1.0 — May 2026  
> **Platform:** Microsoft Copilot Studio, Microsoft Fabric, Power BI Semantic Models  
> **Primary Example:** People Analytics HR Agent (Targa Resources)  
> **Author:** Data & Analytics Center of Excellence

---

## Table of Contents

1. [Executive Overview](#1-executive-overview)
2. [Architecture & Design Decisions](#2-architecture--design-decisions)
3. [Step-by-Step Build Process](#3-step-by-step-build-process)
   - Phase 1: Semantic Model Readiness
   - Phase 2: Metric Registry
   - Phase 3: Copilot Studio Agent Instructions
   - Phase 4: Fabric Data Agent Instructions
   - Phase 5: Knowledge Sources
   - Phase 6: Testing & Iteration
4. [Lessons Learned & Gotchas](#4-lessons-learned--gotchas)
5. [Applying to Other Domains](#5-applying-to-other-domains)
6. [Appendix](#appendix)

---

## 1. Executive Overview

### What This Guide Produces

A conversational AI agent that answers business questions by querying a governed semantic model in real time. Users ask natural-language questions ("How's turnover in Operations?") and receive accurate, formatted answers with proper methodology citations — in under 90 seconds.

The agent doesn't hallucinate metrics or invent calculations. It uses only the measures defined in your semantic model, applies the aggregation rules you specify, and respects row-level security. It's a controlled, governed analytics interface — not a free-form chatbot.

### Architecture at a Glance

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER                                     │
│              (Teams, Web, SharePoint, Mobile)                     │
└──────────────────────────┬──────────────────────────────────────┘
                           │ Natural language question
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│              COPILOT STUDIO AGENT ("The Brain")                   │
│                                                                   │
│  • Resolves terminology (BU → RC Level 01)                       │
│  • Routes to correct measure (turnover → % Turnover Annualized)  │
│  • Applies privacy rules (k≥5 suppression)                       │
│  • Formats the response conversationally                         │
│  • Consults knowledge sources for definitions                    │
└──────────────────────────┬──────────────────────────────────────┘
                           │ Precise query specification
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│            FABRIC DATA AGENT ("The Hands")                        │
│                                                                   │
│  • Receives structured query spec                                │
│  • Generates DAX against the semantic model                      │
│  • Executes query and returns results                            │
│  • Applies aggregation rules from its instructions               │
└──────────────────────────┬──────────────────────────────────────┘
                           │ DAX query
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│              POWER BI SEMANTIC MODEL                              │
│                                                                   │
│  • Star schema with governed measures                            │
│  • Pre-built DAX (proper denominators, time intelligence)        │
│  • Row-level security                                            │
│  • Direct Lake mode on Fabric                                    │
└─────────────────────────────────────────────────────────────────┘
```

### What the HR Agent Can Answer

The People Analytics agent handles questions across these categories:

| Category | Example Questions |
|----------|-------------------|
| Headcount | "How many employees do we have?" "Headcount by division" |
| Turnover | "What's our annualized turnover rate?" "Voluntary vs involuntary split" |
| Hiring | "How many hires YTD?" "Where are we hiring most?" |
| Comparisons | "Compare Houston vs Midland" "Operations vs Admin turnover" |
| Trends | "How has headcount changed over the last 6 months?" |
| Drilldowns | "Break that down by department" "What are the top exit reasons?" |
| Definitions | "How do you calculate turnover?" "What's the difference between YTD and annualized?" |

### Results

| Metric | Before Agent | After Agent |
|--------|-------------|-------------|
| Time to answer a workforce question | 15-45 min (manual report building) | 30-90 seconds |
| Consistency of KPI definitions | Variable across analysts | 100% governed |
| Self-service adoption | Limited to Power BI-literate users | Any Teams user |
| Accuracy | Dependent on analyst skill | Validated against model measures |

### How This Fits the CoE Roadmap

This agent build represents **Phases 7-8** of the AI Analytics Engineering Playbook:
- Phase 7: AI Agent Prompt Engineering & Knowledge Integration
- Phase 8: Governance, Evaluation & Production Deployment

The prerequisite work (Phases 1-6) is documented in the companion playbooks:
- **Raw Data to Production Semantic Layer Playbook** — source system through Gold layer
- **Gold to Semantic Layer to Analytics Playbook** — Gold through semantic model and consumption

The agent is a *consumer* of the semantic layer, not a replacement for it. The semantic model must be production-ready before agent development begins.

> 📚 **Companion Documents:**  
> - CoE Charter — governance authority and operating model  
> - CoE Roadmap — phased execution plan (this work is Phase 1, Activity: AI Agent Pilot)  
> - AI Ready Enterprise Doc — conceptual framing for semantic + contextual layers  
> - From Data Chaos to AI Clarity — Microsoft whitepaper on data quality prerequisites

---

## 2. Architecture & Design Decisions

### Why Two Agents?

The most critical design decision is the **two-agent pattern** (Copilot Studio + Fabric Data Agent) rather than a single agent that does everything.

| Approach | Pros | Cons |
|----------|------|------|
| **Single agent (CS only)** | Simpler to set up | Can't query live data; limited to knowledge file retrieval |
| **Single agent + custom connector** | Full control | Heavy development; no pre-built DAX generation |
| **CS + Fabric Data Agent** ✅ | CS handles reasoning/formatting; FDA handles DAX natively; no code required | Two instruction sets to maintain; latency from round-trips |
| **Custom app (Python/C#)** | Maximum flexibility | Months of development; no conversational UI for free |

The two-agent pattern was chosen because:
1. **Fabric Data Agent generates DAX natively** — it already understands semantic model structure, relationships, and measure definitions. You don't need to teach it DAX from scratch.
2. **Copilot Studio provides the conversational layer** — prompt orchestration, knowledge retrieval, Teams/web deployment, authentication, conversation history.
3. **Separation of concerns** — the "brain" (CS) handles ambiguity resolution, privacy rules, and formatting. The "hands" (FDA) handles data access. Neither does the other's job.

### Instruction Design Philosophy

After extensive iteration, three principles emerged:

**1. Principles over templates.** Tell the agent *what to prioritize*, not *exactly how to format every response*. Overly rigid templates make responses feel robotic and brittle.

> ✅ "Prefer summary first, detail on demand. Answer at one level of depth."  
> ❌ "ALWAYS respond with: 2-3 sentences, then exactly ONE table with max 8 rows, then exactly ONE follow-up question."

**2. Guard the edges, not the middle.** Be strict about what the agent must NEVER do (sum snapshots, expose PII, compute turnover manually) and what it must ALWAYS do (use exact measure names, resolve dates to ranges). Let it be conversational in between.

**3. The instruction IS the interface contract.** Everything the agent knows about your domain comes from:
- Instructions (rules, routing, guardrails)
- Knowledge sources (definitions, schemas, synonyms)
- The semantic model itself (data, measures, relationships)

If the agent does something wrong, the fix is *always* in one of these three places — never in the underlying platform.

### Knowledge Source Strategy

Not everything belongs in instructions. The key decision: **what goes where?**

| Content Type | Where It Belongs | Why |
|---|---|---|
| Measure routing rules | Instructions | Must be applied every turn; space-critical |
| Aggregation guardrails | Instructions | Safety rails; must always be active |
| Privacy rules | Instructions | Non-negotiable; always enforced |
| Terminology/synonyms | Knowledge source | Looked up when needed; too large for instructions |
| Full measure definitions + DAX | Knowledge source | Reference material; not needed every turn |
| Verified Q&A pairs | Knowledge source | Helps ground responses in validated answers |
| Table schemas + columns | FDA Instructions | The FDA needs schema to generate DAX |
| Actual data values | Semantic model | Never hardcoded; always queried live |

### Character Limits

Copilot Studio imposes hard limits on instruction length:
- **Copilot Studio custom instructions**: 8,000 characters (CRLF line endings)
- **Fabric Data Agent instructions**: 15,000 characters (CRLF line endings)

⚠️ **Critical**: These limits count CRLF (2 bytes per line break), not LF (1 byte). A file that looks like 7,200 characters in VS Code (LF) may actually be 7,800 when pasted into CS (which adds CR). Always verify with:

```powershell
$content = Get-Content "YourInstructions.txt" -Raw
$lines = ($content -split "`n").Count
$crlf_length = $content.Length + $lines
Write-Host "CRLF chars: $crlf_length / 8000 (buffer: $(8000 - $crlf_length))"
```

> 📚 **Companion Documents:**  
> - AI Analytics Engineering Playbook v2 — full 8-phase process; this guide covers Phases 7-8  
> - Gold to Semantic Layer to Analytics Playbook — semantic model prerequisites

---

## 3. Step-by-Step Build Process

### Phase 1: Semantic Model Readiness

**Goal:** A production-quality semantic model that the Fabric Data Agent can query reliably.

The agent is only as good as the semantic model underneath it. If measures have incorrect logic, inconsistent naming, or ambiguous relationships, the agent will produce wrong answers confidently. Fix the model first.

#### Checklist

| Requirement | Why It Matters for the Agent |
|---|---|
| Star schema (facts + dimensions) | FDA generates cleaner DAX with proper star schemas |
| Business-friendly column names | Agent surfaces column names to users; "RC Level 01" > "dim_rc_lvl_1" |
| All KPIs as model measures (not report measures) | FDA can only query model-level measures |
| Proper DAX (CALCULATE, time intelligence) | Ensures correct aggregation without the agent needing to compensate |
| Tested against known values | You need verified baselines to evaluate agent accuracy |
| Row-level security configured | Agent respects RLS automatically via FDA |
| Direct Lake or Import mode | DirectQuery adds significant latency per agent query |

#### People Analytics Example

The People Analytics semantic model has:
- **3 fact tables**: Headcount, Hires, Terminations
- **13 model measures**: 5 headcount variants, 2 hire measures, 2 termination measures, 4 turnover rates
- **13 dimension tables**: People Information, Department Hierarchy, Locations, Jobs, Employee Types, etc.
- **1 date table**: Trending Metrics
- **Mode**: Direct Lake (reads from OneLake parquet files)
- **Refresh**: Daily via UKG sync
- **RLS**: Configured by organizational hierarchy

> 📚 **Companion Documents:**  
> - Raw Data to Production Semantic Layer Playbook — Phases 1-4 (source through Gold)  
> - Gold to Semantic Layer to Analytics Playbook — Phases 5-6 (Gold through semantic model)

---

### Phase 2: Metric Registry

**Goal:** A structured catalog of every measure in the model with business context, calculation logic, and verified Q&A pairs.

The metric registry is the single source of truth for what the agent should say about each metric. It's used to build knowledge sources, validate agent responses, and onboard new team members.

#### Required Fields

| Field | Description | Example |
|---|---|---|
| `metric_id` | Unique identifier | PA-TO-004 |
| `name` | Exact measure name in the model | % Turnover Annualized |
| `category` | Grouping | Turnover |
| `business_definition` | Plain-English explanation | The annualized rate at which employees leave the organization |
| `dax_expression` | Actual DAX formula | `DIVIDE([# of Terminations], [# of Headcount Period Average]) * 12` |
| `aggregation_pattern` | Snapshot, Event, Ratio | Ratio |
| `is_summable` | Can you sum across periods? | No |
| `time_grain` | Minimum meaningful grain | Monthly |
| `common_filters` | Typical slice dimensions | Termination Type, RC Level 01-05, Location |
| `verified_qa` | Question-answer pairs tested against live data | Q: "What's our turnover rate?" → A: "Use % Turnover Annualized" |
| `caveats` | Gotchas and misuse warnings | Never compute manually; model uses proper denominators |

#### Output Formats

Create the registry in a structured format that can serve multiple purposes:

| Format | Purpose |
|---|---|
| **YAML** | Machine-readable, preserves hierarchy, uploadable as knowledge source |
| **CSV** | Spreadsheet-friendly, SharePoint uploadable, easy to review with stakeholders |
| **Markdown** | Retrieval-optimized for Copilot Studio knowledge source chunking |

#### People Analytics Example

The People Analytics registry contains **52 metrics** (13 model measures + 39 derived/variant measures) in:
- `People_Analytics_Metric_Registry.yaml` (~113K characters)
- `People_Analytics_Metric_Registry.csv` (tabular, for SharePoint)
- `People_Analytics_Metric_QA_Reference.md` (retrieval-optimized, for CS knowledge source)

**Sample entry (YAML):**

```yaml
- metric_id: PA-TO-004
  name: "% Turnover Annualized"
  category: Turnover
  business_definition: >
    The annualized turnover rate based on the rolling 12-month 
    termination count divided by average headcount.
  dax_expression: "DIVIDE([# of Terminations TTM], [# of Headcount Period Average])"
  aggregation_pattern: Ratio
  is_summable: false
  time_grain: Monthly
  common_filters:
    - "Terminations[Termination Type]"
    - "Department Hierarchy[Responsibility Center Level 01]"
  verified_qa:
    - question: "What's our turnover rate?"
      expected: "Use % Turnover Annualized; currently ~9-11%"
    - question: "What's attrition running at?"
      expected: "Same as turnover — route to % Turnover Annualized"
  caveats:
    - "Never compute manually (terms ÷ headcount)"
    - "Model uses proper rolling denominator"
```

---

### Phase 3: Copilot Studio Agent Instructions

**Goal:** A system prompt that turns Copilot Studio into a domain-aware query planner and response formatter.

The CS instructions are the agent's "brain." They tell it how to interpret user questions, which measures to use, how to handle ambiguity, and how to format responses. They do NOT contain data — they contain rules.

#### Instruction Sections

Every analytics agent needs these sections (in this order):

| Section | Purpose | Example Content |
|---|---|---|
| **ROLE & PURPOSE** | Identity and constraints | "You are a [Domain] Copilot. Answer using ONLY the approved semantic model." |
| **MEASURE SELECTION** | List all model measures with patterns | "Headcount: snapshot. Hires: event count, summable." |
| **MEASURE ROUTING** | Map user language to exact measures | "'turnover' → % Turnover Annualized" |
| **AGGREGATION GUARDRAILS** | What's safe to sum, what's not | "NEVER sum snapshots or ratios across periods" |
| **TERMINOLOGY RESOLUTION** | Synonym map for common terms | "attrition/churn = turnover" |
| **TIME USAGE** | How to handle date ranges and grains | "Headcount → monthly grain. Hires → any grain." |
| **ORGANIZATION & GEOGRAPHY** | Hierarchy levels, location handling | "BU → RC Level 01. City and State are separate columns." |
| **TABLES** | Quick reference to model structure | "Facts: Headcount, Hires, Terminations. Dims: 13 tables." |
| **PRIVACY & SECURITY** | PII rules, minimum group sizes | "k≥5 for all slices. Gender/Ethnicity: enforce suppression." |
| **QUERY TRANSLATION** | How to formulate the FDA call | "Resolve all ambiguity, then pass precise spec. ONE FDA call per question." |
| **RESPONSE DEPTH** | How much detail in first response | "Summary first, detail on demand. One level of depth." |
| **RESPONSE FORMAT** | Tone and structure | "Be direct and conversational. Lead with the answer." |
| **RESTRICTED** | Hard boundaries | "No predictions. No new measures. No PII." |

#### Writing Tips

1. **Front-load critical rules.** LLMs pay more attention to content early in the prompt. Put safety rails and routing before formatting preferences.

2. **Use imperative language for rules.** "NEVER sum snapshots" is stronger than "You should avoid summing snapshots."

3. **Include negative examples for common failures.** If the agent keeps doing something wrong, add an explicit "Do NOT..." rule.

4. **Keep a character buffer.** Target 500-800 chars below the limit. You'll always need to add rules during iteration.

5. **Use a paste-friendly format.** Copilot Studio's instruction pane treats single line breaks as spaces. Use blank lines between sections to ensure separation. No markdown headers (they don't render in the pane).

#### People Analytics Example

File: `People_Analytics_Agent_Instructions.txt` (7,425 CRLF characters / 8,000 limit)

Key design choices:
- Retention is explicitly flagged as "not in the model" (prevents false confidence)
- Geography resolution rules prevent the most common query failures
- "MINIMIZE ROUND-TRIPS" rule caps FDA calls at 1 per user turn
- Response depth is a principle ("prefer summary first") not a template

---

### Phase 4: Fabric Data Agent Instructions

**Goal:** A comprehensive reference that enables the FDA to generate correct DAX queries for any question the CS agent sends it.

The FDA instructions are longer (up to 15,000 CRLF characters) because they contain the full schema reference. The FDA doesn't need routing or formatting rules — it needs to know what tables exist, what columns they have, how they relate, and what aggregation patterns to follow.

#### Instruction Sections

| Section | Purpose |
|---|---|
| **ROLE** | "You are a DAX query engine for [Model Name]" |
| **MODEL OVERVIEW** | Schema, grain, mode, refresh |
| **MEASURES** | All measures with exact names, DAX, patterns, summability |
| **TABLES & COLUMNS** | Every table with every queryable column |
| **RELATIONSHIPS** | How tables join (cardinality, cross-filter direction) |
| **TIME INTELLIGENCE** | Date table structure, how to filter periods |
| **VOLUNTARY/INVOLUNTARY** | Domain-specific filter columns and valid values |
| **ORGANIZATION HIERARCHY** | RC Level structure, how to navigate |
| **AGGREGATION RULES** | Detailed rules the DAX must respect |
| **PRIVACY** | k≥5 suppression, RLS reminders |
| **RESPONSE STYLE** | Return only what was requested; be concise |

#### People Analytics Example

File: `People_Analytics_Fabric_Data_Agent_Instructions.txt` (13,279 CRLF characters / 15,000 limit)

The FDA instructions contain:
- All 13 model measures with exact DAX
- All 16 tables with key columns listed
- Relationship map (which tables connect via which keys)
- Voluntary/involuntary column values (exactly as stored in the model)
- Time handling rules (Date vs Period vs Quarter vs Year)
- Geography handling (Locations table column names and patterns)

---

### Phase 5: Knowledge Sources

**Goal:** Upload reference documents that the agent can retrieve when answering definition questions or resolving terminology.

Knowledge sources supplement the instructions. They're retrieved via semantic search when relevant — not processed on every turn. This makes them ideal for large reference material that would exceed instruction character limits.

#### What to Create

| File | Content | Size | Upload Target |
|---|---|---|---|
| Agent Knowledge / Quick Reference | Measure catalog, table overview, model metadata | ~13K chars | CS Knowledge Source (direct) |
| Business Glossary | Term → measure mapping, synonym table, org navigation | ~10K chars | CS Knowledge Source (direct) |
| Metric QA Reference | Verified Q&A pairs for every measure + definitions | ~15K chars | CS Knowledge Source (direct) |
| Metric Registry (full) | Complete registry with DAX, caveats, verified_qa | ~113K chars | SharePoint → CS connector |

#### Upload Methods

**Direct upload to Copilot Studio:**
- Best for files under ~50K characters
- Managed via Copilot Studio → Knowledge → Add data source → Upload files
- Supports: .md, .txt, .pdf, .docx, .yaml (treated as unstructured text)
- Max: 512 MB per file, 500 files per source

**SharePoint connector:**
- Best for larger files or files that need shared governance
- Upload to SharePoint document library → connect as CS knowledge source
- Advantage: business stakeholders can review/update without CS access
- Disadvantage: slight sync lag (not instant)

#### People Analytics Example

Files uploaded:
- ✅ `People_Analytics_Agent_Knowledge.md` → Direct to CS
- ✅ `People_Analytics_Business_Glossary.md` → Direct to CS
- ✅ `People_Analytics_Metric_QA_Reference.md` → Direct to CS
- ✅ `People_Analytics_Metric_Registry.csv` → SharePoint → CS connector

---

### Phase 6: Testing & Iteration

**Goal:** Systematically evaluate agent accuracy and iterate on instructions until quality targets are met.

This is the most important phase. Your first version will have bugs. The iteration loop is: **test → diagnose → fix instructions → re-test**.

#### Building an Evaluation Set

Create a CSV with 25-35 test questions across difficulty levels:

| Difficulty | Count | Description | Example |
|---|---|---|---|
| Easy | 4-5 | Single measure, no filters | "What's our headcount?" |
| Medium | 8-10 | Single measure + filter or comparison | "Turnover in Operations?" |
| Hard | 6-8 | Multi-measure, time ranges, terminology | "Compare Houston vs Midland YTD" |
| Expert | 10-12 | Ambiguous, multi-dimensional, edge cases | "What does our age profile for terminations look like?" |

#### What to Evaluate

| Dimension | What to Check |
|---|---|
| **Accuracy** | Did it use the right measure? Are the numbers correct? |
| **Speed** | How long did the response take? (Target: <90s) |
| **Terminology** | Did it resolve synonyms correctly? |
| **Aggregation** | Did it avoid summing snapshots/ratios? |
| **Privacy** | Did it flag small groups? Suppress sensitive attributes? |
| **Depth** | Did it answer at the right level without over-dumping? |
| **Limitations** | Did it honestly say "not in the model" when appropriate? |

#### The Iteration Loop

```
         ┌──────────────┐
         │ Run eval set │
         └──────┬───────┘
                │
                ▼
    ┌──────────────────────┐     ┌─────────────────┐
    │ Analyze failures     │────▶│ Categorize root  │
    │ (wrong measure,      │     │ cause:           │
    │  wrong filter,       │     │ • Routing error  │
    │  wrong aggregation,  │     │ • Missing rule   │
    │  too verbose, etc.)  │     │ • Terminology gap│
    └──────────────────────┘     │ • Schema issue   │
                                 └────────┬────────┘
                                          │
                                          ▼
                              ┌─────────────────────┐
                              │ Fix: update          │
                              │ instructions,        │
                              │ knowledge sources,   │
                              │ or model             │
                              └──────────┬──────────┘
                                         │
                                         ▼
                              ┌─────────────────────┐
                              │ Re-paste & re-test   │
                              │ the failed questions │
                              └─────────────────────┘
```

#### Common Failure Patterns

| Failure | Root Cause | Fix Location |
|---|---|---|
| Wrong measure selected | Missing or ambiguous routing rule | CS Instructions (MEASURE ROUTING) |
| State filter fails | "Texas" instead of "TX" | CS Instructions (GEOGRAPHY RESOLUTION) |
| Snapshots summed across months | Missing aggregation guard | CS Instructions (AGGREGATION GUARDRAILS) |
| Response too long / too slow | Too many FDA calls or too much output | CS Instructions (RESPONSE DEPTH, QUERY TRANSLATION) |
| "Data not found" for valid query | Column name mismatch in FDA instructions | FDA Instructions (TABLES & COLUMNS) |
| Confident wrong answer | Terminology not mapped | Knowledge Source (Business Glossary) |

#### People Analytics Example

File: `Evaluate Targa HR Agent v4.csv` — 30 questions across 4 difficulty tiers.

Key iteration discoveries:
- Geography resolution required explicit state abbreviation mapping
- "Retention" was incorrectly auto-derived (fixed via terminology rule)
- Response verbosity required a depth principle, not a rigid template
- FDA round-trips were the #1 speed issue (fixed via 1-call-per-turn cap)

---

## 4. Lessons Learned & Gotchas

These are real issues encountered during the People Analytics agent build. Most will apply to any domain.

### 1. CRLF Character Counting

**The bug:** Files saved with Unix line endings (LF, 1 byte) appear shorter than when pasted into Copilot Studio (which counts CRLF, 2 bytes per line break). A file at "7,900 characters" in VS Code might actually be 8,050 in CS — silently truncating your instructions.

**The fix:** Always count with:
```powershell
$content = Get-Content "file.txt" -Raw
$crlf = $content.Length + ($content -split "`n").Count
```

**Maintain a buffer:** Target 500+ chars below the limit.

### 2. The Retention Terminology Trap

**The bug:** The agent was confidently reporting "retention rates" by computing `1 - turnover rate`. This sounds correct but is misleading — true retention in HR means cohort survival (did employees make it to 90 days? 1 year?). The model has no cohort retention measure.

**The fix:** Explicitly tell the agent: "True cohort retention is not in the model. If asked, say so and offer alternatives (turnover rate, tenure breakdown, new hire terminations)."

**The principle:** If a common business term maps to something your model *doesn't have*, explicitly address that gap. Silent auto-derivation creates false confidence.

### 3. Response Verbosity vs. Conversational Tone

**The bug:** Initial conciseness rules were too rigid ("max 8 rows, ONE table, 2-3 sentences only"). The agent became robotic and lost its conversational intelligence.

**The fix:** Frame depth rules as principles, not templates:
> "Prefer summary first, detail on demand. Answer at one level of depth. Offer to go deeper."

**The principle:** Guard the edges (what it must never do), free the middle (let it think and respond naturally). Users want a smart assistant, not a form-filling machine.

### 4. FDA Round-Trips as the #1 Speed Killer

**The bug:** A question like "How's Operations doing?" triggered 5+ separate FDA calls (headcount, hires, terms, turnover, then departments, then trends). Each call adds 15-30 seconds of latency.

**The fix:** Two changes:
1. "Make ONE FDA call per user question. Combine all measures into a single request."
2. "Maximum FDA calls per turn: 1. Follow-up drill-down: 1 additional."

**The impact:** Complex questions dropped from 5-6 minutes to ~90 seconds.

### 5. Geography Resolution

**The bug:** Users say "Midland Texas" but the model stores City = "Midland" and State = "TX" as separate columns. The agent was trying `State = "Texas"` or concatenating `City = "Midland TX"` — both fail silently.

**The fix:** Explicit geography resolution rules in CS instructions:
- State column stores 2-letter abbreviations
- City and State are always separate filters
- Include a mapping table: Texas=TX, Oklahoma=OK, etc.

### 6. Partial Month Data Exclusion

**The bug:** On May 11, the agent reported data only through April 30 — missing 11 days of May that were already in the model. It was defaulting to "most recent complete month."

**The fix:** Added a CURRENT DATA SCOPE rule: "For current-state questions, include ALL data through MAX date in the model (including partial months). Only cap at last complete month for explicit monthly trend requests."

### 7. Knowledge Source Chunking

**The insight:** YAML files uploaded as knowledge sources get chunked into ~500-token segments for retrieval. If your YAML entries are large, a single metric's definition might get split across chunks — losing context.

**The workaround:** Create a Markdown version optimized for retrieval (`Metric_QA_Reference.md`) where each metric is a self-contained section with clear headers. This chunks cleanly.

---

## 5. Applying to Other Domains

### What Changes vs. What Stays the Same

| Component | Domain-Specific (Changes) | Domain-Agnostic (Stays the Same) |
|---|---|---|
| Measures | Different KPIs, different DAX | Measure routing pattern, aggregation guardrails structure |
| Tables & Schema | Different fact/dim tables | Star schema requirement, relationship documentation |
| Terminology | Different synonyms | Synonym map format, glossary structure |
| Geography | Different locations, maybe N/A | Resolution rules (if applicable) |
| Privacy | Different sensitivity (financial vs HR) | k≥5 pattern, RLS respect, PII rules |
| Time handling | Different grains (daily for ops, monthly for HR) | Time usage section structure |
| Org hierarchy | Different levels, different names | Hierarchy mapping pattern |
| Response tone | Maybe more formal (finance) or urgent (safety) | Depth principle, conversational guardrail |

### Domain Substitution Checklist

When building a new agent for a different domain:

- [ ] **Semantic model is production-ready** (star schema, measures tested, RLS configured)
- [ ] **Metric registry created** (all measures documented with business definitions + verified QA)
- [ ] **CS instructions drafted** using template below (fill in domain-specific sections)
- [ ] **FDA instructions drafted** with full table/column/measure/relationship reference
- [ ] **Knowledge sources created** (glossary, metric reference, Q&A pairs)
- [ ] **Evaluation set built** (25-35 questions across 4 difficulty tiers)
- [ ] **First round of testing complete** (at least 3 iteration cycles)
- [ ] **Instructions pasted and verified** (CRLF counts checked, agent responses validated)

### Example: Safety/ES&H Domain

If building a Safety Incident agent:

| Section | People Analytics | Safety/ES&H |
|---|---|---|
| Measures | Headcount, Hires, Terms, Turnover | Incident Count, TRIR, DART, Severity Rate |
| Routing | "turnover" → % Turnover Annualized | "recordable" → TRIR, "lost time" → DART |
| Aggregation | Never sum headcount (snapshot) | TRIR is a rate — never sum across periods |
| Terminology | attrition = turnover | RIF = Recordable Incident Frequency = TRIR |
| Hierarchy | RC Level 01-05 | Area → Region → Facility → Unit |
| Time | Monthly grain for most | Daily/weekly for incidents; monthly for rates |
| Privacy | k≥5 for Gender/Ethnicity | Incident details may have legal sensitivity |

### CS Instruction Template (Blank)

```
ROLE & PURPOSE
You are a [DOMAIN] Analytics Copilot for [COMPANY]. Answer questions using ONLY the approved semantic model. Consult knowledge sources before answering.

MEASURE SELECTION ([N] model measures)
[List all measures with patterns: snapshot/event/ratio, summable Y/N]

MEASURE ROUTING
[Map common user phrases to exact measure names]

AGGREGATION GUARDRAILS
SAFE to sum: [list event measures]
NEVER sum: [list snapshots and ratios]
[Any domain-specific anti-patterns]

TERMINOLOGY RESOLUTION
[Synonym mappings for your domain]

TIME USAGE
[Date columns, grains, range handling]

ORGANIZATION & GEOGRAPHY
[Hierarchy levels, location handling if applicable]

TABLES
[Quick reference: fact tables, date table, dimension tables]

PRIVACY & SECURITY
[PII rules, minimum group sizes, sensitive attributes]

QUERY TRANSLATION
You are the query planner. Resolve all ambiguity yourself, then pass a precise spec to the Fabric Data Agent.
MINIMIZE ROUND-TRIPS: Make ONE FDA call per user question.
[Include 2-3 common query patterns]

RESPONSE DEPTH
Prefer summary first, detail on demand. Answer at one level of depth. Offer to go deeper.

RESPONSE FORMAT
Be direct and conversational. Lead with the answer, include a supporting table, note how it was calculated, and offer a natural next step.

RESTRICTED
[Hard boundaries: what's not in the model, what the agent must never do]
```

> 📚 **Companion Documents:**  
> - Enterprise Metric Registry.xlsx — domain-agnostic template for metric definitions  
> - AI Analytics Engineering Playbook v2 — full lifecycle process for any domain

---

## Appendix

### A: Artifact Inventory (People Analytics Agent)

| File | Purpose | Size | Location |
|---|---|---|---|
| `People_Analytics_Agent_Instructions.txt` | CS system prompt (paste-ready) | 7,425 CRLF / 8,000 | Copilot Studio Instructions pane |
| `People_Analytics_Agent_Instructions.md` | CS instructions source (editable) | 6,807 CRLF / 8,000 | Repository |
| `People_Analytics_Fabric_Data_Agent_Instructions.txt` | FDA instructions (paste-ready) | 13,279 CRLF / 15,000 | Fabric Data Agent Instructions pane |
| `People_Analytics_Fabric_Data_Agent_Instructions.md` | FDA instructions source (editable) | 14,374 CRLF / 15,000 | Repository |
| `People_Analytics_Metric_Registry.yaml` | Full 52-metric registry | ~113K chars | SharePoint → CS knowledge source |
| `People_Analytics_Metric_Registry.csv` | Registry in tabular format | ~30K chars | SharePoint |
| `People_Analytics_Agent_Knowledge.md` | Quick reference for CS | ~13K chars | CS Knowledge Source (direct upload) |
| `People_Analytics_Business_Glossary.md` | Synonym map + org navigation | ~10K chars | CS Knowledge Source (direct upload) |
| `People_Analytics_Metric_QA_Reference.md` | Verified Q&A pairs | ~15K chars | CS Knowledge Source (direct upload) |
| `Evaluate Targa HR Agent v4.csv` | 30-question evaluation set | ~5K chars | Local testing |

### B: Architecture Diagram

```
USER (Teams / Web / SharePoint)
        │
        │  Natural language question
        ▼
COPILOT STUDIO AGENT ─────────────────────────────────────────┐
│  Custom Instructions (8,000 char max)                        │
│  Knowledge Sources (glossary, metrics, Q&A pairs)            │
│  GPT-4o orchestration                                        │
│                                                              │
│  1. Resolve terminology → exact measure names                │
│  2. Resolve dates → explicit YYYY-MM-DD ranges               │
│  3. Resolve org terms → exact column names                   │
│  4. Apply privacy rules                                      │
│  5. Formulate precise query spec                             │
└──────────────────────────────┬──────────────────────────────┘
                               │  Structured query spec (1 call)
                               ▼
FABRIC DATA AGENT ─────────────────────────────────────────────┐
│  Custom Instructions (15,000 char max)                        │
│  Connected to: Power BI Semantic Model                        │
│                                                              │
│  1. Parse query spec                                         │
│  2. Generate DAX query                                       │
│  3. Execute against semantic model                           │
│  4. Return structured results                                │
└──────────────────────────────┬──────────────────────────────┘
                               │  Query results
                               ▼
COPILOT STUDIO AGENT (continued)
│  5. Format response conversationally                         │
│  6. Add methodology citation                                 │
│  7. Offer follow-up                                          │
│  8. Return to user                                           │
└──────────────────────────────────────────────────────────────┘
```

### C: Companion Document Index

| Document | Location | Description |
|---|---|---|
| AI Analytics Engineering Playbook v2.docx | AI Agent Documentation/ | Master 8-phase process from source system to production AI agent |
| Raw Data to Production Semantic Layer Playbook.docx | AI Agent Documentation/ | Phases 1-6: source system → Bronze → Silver → Gold → semantic layer |
| Gold to Semantic Layer to Analytics Playbook.docx | AI Agent Documentation/ | Last-mile: Gold → semantic model → consumption (reports, agents, apps) |
| CoE Charter.pdf | AI Agent Documentation/ | Formal authority, operating model, governance scope |
| CoE Roadmap.pdf | AI Agent Documentation/ | 3-phase execution plan; agent builds are Phase 1 AI pilot |
| AI Ready Enterprise Doc 2.pdf | AI Agent Documentation/ | Semantic + contextual + ontology layers for enterprise AI |
| From Data Chaos to AI Clarity.pdf | AI Agent Documentation/ | Microsoft whitepaper: data quality as AI prerequisite |
| Enterprise Metric Registry.xlsx | AI Agent Documentation/ | Domain-agnostic template for metric definitions |
| PBIX HTML Documentation.txt | AI Agent Documentation/ | Prompt template for generating semantic model documentation |

### D: Evaluation Rubric Template

| Dimension | Score 1 (Fail) | Score 3 (Partial) | Score 5 (Pass) |
|---|---|---|---|
| **Accuracy** | Wrong measure or wrong number | Right measure, minor number discrepancy | Correct measure, correct number |
| **Speed** | >3 minutes | 90s - 3 minutes | <90 seconds |
| **Terminology** | Used wrong term or failed to resolve | Resolved but added unnecessary caveat | Clean resolution, natural language |
| **Aggregation** | Summed a snapshot or ratio | Correct aggregation but didn't note pattern | Correct + noted pattern when relevant |
| **Privacy** | Exposed PII or ignored small group | Flagged but still showed sensitive data | Proper suppression or warning |
| **Depth** | Dumped everything unprompted | Mostly appropriate, one extra breakdown | Right level, offered to drill deeper |
| **Honesty** | Confidently wrong | Hedged but still attempted | Clearly stated limitation |

---

*This guide is a living document. Update it as you learn more about what works and what doesn't. The best agent instructions are written by people who've debugged 50 broken responses.*
