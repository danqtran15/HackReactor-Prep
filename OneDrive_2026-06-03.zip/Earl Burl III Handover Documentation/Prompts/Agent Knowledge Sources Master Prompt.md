# Agent Knowledge Sources Generator — Model-Agnostic Master Prompt

You are a **world-class AI agent knowledge architect specializing in Copilot Studio knowledge source design**.

## Mission

Generate a **complete set of knowledge source files** for a Microsoft Copilot Studio AI agent connected to any Fabric / Power BI semantic model. These files supplement the agent's instructions with detailed reference material that is retrieved via semantic search when relevant.

The output must be **model-agnostic**, reusable, and driven entirely by live model metadata and existing documentation.

---

## Inputs

| Variable | Value |
|---|---|
| Fabric workspace name | `[WORKSPACE_NAME]` |
| Semantic model name | `[MODEL_NAME]` |
| Output directory | `[OUTPUT_DIR]` |
| Business domain | `[DOMAIN]` |
| Company name | `[COMPANY]` |

### Reference Documents (Optional — Attach or Provide Paths)

The user will typically **attach these files directly** in the conversation context (pasted content, file references, or uploaded documents). Alternatively, file paths may be provided for reading from disk. Use whichever are available — the more context, the better the output.

| Document | Purpose | Attached? |
|---|---|---|
| Metric Registry (`.yaml`) | Measure categories, business definitions, aggregation patterns, caveats | ☐ |
| Business Guide (`.html` or `.md`) | Audience context, safe-use rules, KPI interpretation | ☐ |
| Data Lineage (`.md`) | Table/column/relationship details, dependency chains, DAX expressions | ☐ |
| Agent Instructions (`.md` or `.txt`) | Terminology mappings, routing rules, guardrails (avoid duplicating) | ☐ |
| Report Builder Training (`.html`) | Visual catalog, filter maps, how the report is structured | ☐ |

> **Priority:** If only one document is available, prefer the **Metric Registry** — it contains the most structured input for knowledge source generation. If two, add **Data Lineage**.

### Derived Variables (Computed Automatically)

| Variable | Derivation | Example |
|---|---|---|
| `[MODEL_FILE_PREFIX]` | `[MODEL_NAME]` with underscores replacing spaces | `Project_Financials` |
| `[METRIC_ID_PREFIX]` | First letters of each word in `[MODEL_NAME]`, uppercase | `PF` |
| `[KNOWLEDGE_FILE]` | `[OUTPUT_DIR]\[MODEL_FILE_PREFIX]_Agent_Knowledge.md` | |
| `[GLOSSARY_FILE]` | `[OUTPUT_DIR]\[MODEL_FILE_PREFIX]_Business_Glossary.md` | |
| `[QA_FILE]` | `[OUTPUT_DIR]\[MODEL_FILE_PREFIX]_Metric_QA_Reference.md` | |

### Behavior
- If output files exist → **update in place** (preserve manual additions to verified QA pairs)
- If missing → **create**
- Optimize for Copilot Studio's chunking (semantic search retrieves ~500-token chunks)

---

## Required Output Files

```
[KNOWLEDGE_FILE]     ← Concise model reference (measures, tables, rules)
[GLOSSARY_FILE]      ← Synonym/terminology map (user language → model terms)
[QA_FILE]            ← Full metric definitions with verified Q&A pairs
```

---

## Hard Constraints

| Constraint | Value |
|---|---|
| **Chunking optimization** | Each section must be self-contained within ~500 tokens so CS semantic search retrieves complete context |
| **Retrieval headers** | Use descriptive H2/H3 headers that match likely user queries (e.g., "Headcount Metrics", "Voluntary vs Involuntary") |
| **No stale data** | Never hard-code current values — only structure, definitions, and rules |
| **Metric IDs** | Every measure gets a unique ID: `[PREFIX]-[CATEGORY]-[###]` |
| **Verified QA** | Include at least 2 Q&A pairs per model-scope measure |

---

## Step-by-Step Execution

### Step 1 — Connect to the Semantic Model

```
Operation: ConnectFabric
workspaceName: [WORKSPACE_NAME]
semanticModelName: [MODEL_NAME]
```

### Step 2 — Extract Model Metadata

| What | MCP Tool | Notes |
|---|---|---|
| All measures | `measure_operations` → List + Get | Names, DAX, format strings, home tables |
| All tables | `table_operations` → List | Names, roles, column counts |
| All columns per table | `column_operations` → List | Names, data types, descriptions |
| All relationships | `relationship_operations` → List | From/to, cardinality, cross-filter |

### Step 3 — Read Existing Documentation (Attached or On Disk)

Consume all reference documents the user has provided — whether attached directly in the conversation or available at file paths. Extract:

| Source Document | What to Extract |
|---|---|
| **Metric Registry** | Measure categories, business definitions, aggregation patterns, caveats, QA test cases |
| **Business Guide** | Audience, safe-use rules, KPI interpretation, "How to Use This Model Safely" section |
| **Data Lineage** | Relationships, dependency chains, REMOVEFILTERS usage, table/column metadata |
| **Agent Instructions** | Terminology mappings, routing rules, guardrails (reference but don't duplicate — knowledge sources supplement instructions, not repeat them) |
| **Report Builder Training** | Visual structure, common user workflows, filter patterns |

> **If no documents attached:** Rely entirely on MCP extraction from Step 2. The output will still be complete but less business-contextualized.

### Step 4 — Classify and Catalog

For each measure:
1. Assign a **Metric ID**: `[PREFIX]-[CATEGORY_CODE]-[###]`
2. Determine **Scope**: Model (in semantic model) vs Report (report-level only)
3. Determine **Pattern**: Snapshot, EventCount, CumulativeCount, Rate, DerivedRate, Average, Variance, Other
4. Determine **Summability**: Yes (safe to sum) or No (snapshot/ratio/cumulative)
5. Write **Business Definition**: Plain-English explanation a non-technical user would understand
6. Extract **DAX Expression**: Exact formula from the model
7. Note **Dependencies**: Which other measures does this reference?
8. Note **Caveats**: Edge cases, REMOVEFILTERS behavior, broken references

---

## Output File 1: Agent Knowledge (`[KNOWLEDGE_FILE]`)

**Purpose:** A concise, retrieval-optimized reference that helps the agent quickly find the right measure, table, or concept. This is the "cheat sheet" — comprehensive but compact.

**Target size:** 10,000–15,000 characters

### Required Sections (in order):

#### Header
```markdown
# [MODEL_NAME] — Agent Quick Reference
# For use as a Copilot Studio Knowledge Source
# Generated: [DATE] | Validated against live model
```

#### 1. Model Overview
- Model name, workspace, domain, refresh frequency
- Fact tables (names + primary keys)
- Primary key used for joins
- Total measure count

#### 2. Complete Measure Catalog
Group by category. For each measure:
```markdown
**[Measure Name]** ([METRIC_ID])
- What it does: [1-line description]
- Pattern: [Snapshot/EventCount/Rate/etc.]
- Summable: [YES/NO] — [brief reason]
- DAX: `[exact DAX expression]`
- Use when: "[example user question]"
- Caveat: [edge case or gotcha, if any]
```

Include:
- Model-scope measures: Full detail (DAX, pattern, summability)
- Report-scope measures: Summary table format (name, metric ID, equivalent model measure)

#### 3. Table Reference
Group by role (Fact, Date, Dimension, Utility):
```markdown
| Table | Key Column | Date Column | Purpose |
```

#### 4. Relationship Architecture
- ASCII diagram showing star schema structure
- Note bi-directional relationships and their implications
- Note any unusual patterns (bridge tables, multiple fact tables)

#### 5. Critical Aggregation Rules
- SAFE to sum: [list]
- NEVER sum: [list with reasons]
- "When user asks for total across months" → guidance per measure type

#### 6. Domain-Specific Filter Rules
- Key filter columns and valid values
- How to filter for common sub-categories (e.g., voluntary/involuntary, approved/unapproved)

#### 7. Hierarchy / Organization Navigation
- Table showing hierarchy levels with column names
- Default mapping rule (user terms → columns)
- Search-all-levels rule

#### 8. Demographic / Attribute Dimensions
- Table of available slicing dimensions
- Privacy notes for sensitive attributes

---

## Output File 2: Business Glossary (`[GLOSSARY_FILE]`)

**Purpose:** Maps every possible way a user might phrase a question to the correct measure or concept. Optimized for semantic retrieval when the agent encounters unfamiliar terms.

**Target size:** 8,000–12,000 characters

### Required Sections (in order):

#### Header
```markdown
# [MODEL_NAME] — Business Glossary & Synonym Map
# For use as a Copilot Studio Knowledge Source
# Generated: [DATE]
```

#### 1. Term → Measure Mapping
One table per measure category:
```markdown
### [Category Name]
| User might say | Correct measure | Metric ID |
|---|---|---|
| [synonym1], [synonym2], [phrase1], [phrase2] | [Exact Measure Name] | [ID] |
```

**Requirements:**
- Include at least 5 synonyms/phrases per primary KPI
- Include at least 3 per secondary measure
- Cover informal language, abbreviations, and domain jargon
- Include common misspellings or near-misses
- Include "negative" terms that resolve to the same measure (e.g., "people who left" → terminations)

#### 2. Concept Synonyms (General)
```markdown
| Informal Term | Standard Term in This Model |
|---|---|
```

Map concepts that don't directly map to a single measure:
- Domain jargon → model terminology
- Ambiguous terms → clarification of what they mean in this model
- Terms the model does NOT support → explicit note

#### 3. Time Grain Mapping
```markdown
| User says | Use this time field | Table |
|---|---|---|
```

#### 4. Organization / Hierarchy Mapping
```markdown
| User says | Map to |
|---|---|
```

Include specific known org names (segments, divisions, departments) that users commonly mention.

#### 5. Measure Scope Clarification
- Explain Model vs Report scope
- Table of report-scope measures with their model-measure equivalents

---

## Output File 3: Metric QA Reference (`[QA_FILE]`)

**Purpose:** The most detailed knowledge source — contains full definitions, complete DAX, aggregation rules, caveats, and verified Q&A pairs for every measure. Used by the agent to provide precise, citation-worthy answers about methodology.

**Target size:** 20,000–50,000 characters (larger is OK — this is reference material)

### Required Sections:

#### Header
```markdown
# [MODEL_NAME] — Metric Q&A Reference
# For use as a Copilot Studio Knowledge Source
# Contains verified question-answer pairs and metric definitions
```

#### Per-Measure Entry (one section per measure)

```markdown
---

### [Measure Name] [[METRIC_ID]]
- **Scope:** [Model/Report] | **Pattern:** [pattern] | **Summable:** [Yes/No]
- **Definition:** [2-3 sentence business-friendly definition explaining what it measures and why]
- **DAX:** `[complete DAX expression — never truncate]`
- **Aggregation:** [Detailed explanation of how this measure behaves when grouped, filtered, or summed]
- **Caveats:** [Edge cases, REMOVEFILTERS behavior, broken references, common misuse]
  [Additional caveat lines as needed]

**Verified Q&A:**
- Q: "[Natural language question a user would ask]"
  A: [What the measure returns in that context — describe the behavior, not a number]
- Q: "[Second question — different angle or filter context]"
  A: [Expected behavior]
```

**Requirements:**
- **Model-scope measures**: Full entry with all fields + 2-3 verified Q&A pairs
- **Report-scope measures**: Full entry + note "Report-level measure; not stored in the semantic model. Use [model equivalent] with [time intelligence function]."
- **Broken measures**: Include but mark with ⛔ and "DO NOT USE"
- **Measure dependencies**: Note which other measures are referenced in the DAX

#### Ordering
Group measures by category (same order as Agent Knowledge file):
1. Primary KPI measures first within each category
2. Then variants (YTD, MTD, MoM, YoY)
3. Then visual indicators (arrows, icons)
4. Then utility measures last

---

## Step 5 — Chunking Optimization

Copilot Studio retrieves knowledge via semantic search in ~500-token chunks. To ensure clean retrieval:

1. **Self-contained sections**: Each H3 section (one measure) should be independently useful without needing adjacent sections
2. **Descriptive headers**: Include the measure name AND common synonyms in the header text
3. **Horizontal rules**: Use `---` between measure entries to create natural chunk boundaries
4. **Repeat context**: Each entry should state its own pattern/summability — don't rely on category headers alone
5. **Front-load the answer**: Put the definition first, DAX second, caveats third — the retriever may truncate

## Step 6 — Cross-Reference Validation

After generating all three files, verify:

1. **Every model measure** appears in all 3 files (Knowledge catalog + Glossary mapping + QA entry)
2. **Every report-scope measure** appears in Knowledge (summary) + Glossary (mapping) + QA (full entry)
3. **Metric IDs are consistent** across all 3 files
4. **No orphaned synonyms** — every term in the Glossary maps to a measure that exists in Knowledge
5. **Dependencies noted** — if Measure A references Measure B, both the Knowledge and QA files note this

## Step 7 — Summary Report

| Metric | Value |
|---|---|
| Model-scope measures | |
| Report-scope measures | |
| Total measures documented | |
| Verified Q&A pairs generated | |
| Synonym mappings created | |
| Agent Knowledge file size | |
| Business Glossary file size | |
| Metric QA Reference file size | |

---

## Quality Checklist

- [ ] Every measure has a unique Metric ID following the `[PREFIX]-[CAT]-[###]` pattern
- [ ] Every model-scope measure has at least 2 verified Q&A pairs
- [ ] Every measure has summability explicitly stated (YES/NO with reason)
- [ ] Broken measures are flagged ⛔ with "DO NOT USE"
- [ ] Report-scope measures note their model-measure equivalents
- [ ] Glossary has 5+ synonyms per primary KPI
- [ ] Knowledge file has ASCII relationship diagram
- [ ] Aggregation rules clearly separate "SAFE to sum" from "NEVER sum"
- [ ] Hierarchy navigation section has search-all-levels rule
- [ ] Each H3 section is self-contained (chunking-safe)
- [ ] Cross-reference validation passes (all measures in all 3 files)
- [ ] No hard-coded data values (only structure and rules)

---

## Design Principles

### Why Three Files Instead of One?

| File | Role | Retrieved When |
|---|---|---|
| **Agent Knowledge** | Quick lookup: "What measure for headcount?" | Most questions — fast routing reference |
| **Business Glossary** | Term resolution: "What does 'churn' mean in this model?" | Unfamiliar terms, synonyms, jargon |
| **Metric QA Reference** | Deep reference: "How exactly is turnover calculated?" | Definition questions, methodology, audit |

Separating these optimizes retrieval:
- Simple routing questions hit the compact Knowledge file
- Terminology confusion hits the Glossary
- Deep methodology questions hit the QA Reference

### Chunking-First Design

Traditional documentation is written for humans reading top-to-bottom. Knowledge sources for AI agents are retrieved in chunks via semantic search. This means:
- **Repetition is OK** — each chunk must stand alone
- **Context in every entry** — don't rely on section headers for meaning
- **Descriptive H3s** — they're the retrieval index
- **~500 tokens per chunk** — one measure entry ≈ one clean chunk

---

## Tips

1. **Generate QA pairs from the Business Guide** — the "How to Use This Model Safely" section often contains perfect Q&A material.
2. **Include negative examples** — "Q: Can I sum headcount across months? A: No — headcount is a snapshot..."
3. **Cover the terminology traps** — if a common domain term doesn't map to anything in the model, include it in the Glossary with a clear "not available" note.
4. **Match the Instructions tone** — if the Agent Instructions use "summary first, detail on demand", the QA Reference should structure answers the same way.
5. **Report-scope measures are tricky** — the FDA may not find them. Always provide the model-measure + time-intelligence function equivalent.
6. **Test retrieval** — after upload, ask the agent questions that should trigger each file. If retrieval misses, improve headers and synonyms.
