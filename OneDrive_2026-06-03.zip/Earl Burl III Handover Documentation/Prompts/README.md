# Targa Power BI Documentation Prompt Toolkit

**A reusable toolkit for generating comprehensive documentation for any Power BI semantic model and report using GitHub Copilot CLI (or any AI coding agent with Power BI MCP tools).**

---

## What's in this Toolkit?

| # | Prompt File | What It Generates | Output Files |
|---|---|---|---|
| 1 | `Semantic Model Documentation Master Prompt.md` | Business guides, glossary, training docs, and lineage appendix | 6 files (4 HTML + 1 MD + 1 PS1) |
| 2 | `Semantic Model Rebuild Blueprint Prompt.md` | Disaster-recovery rebuild blueprint with complete model spec | 1 HTML file |
| 3 | `Report Documentation Master Prompt.md` | Report blueprint with page-by-page visual catalog | 1–3 files (1 HTML + optional MD) |
| 4 | `Metric Registry Master Prompt.md` | YAML metric registry with business definitions and QA tests | 1 YAML file |
| 5 | `CS Agent Instructions Master Prompt.md` | Copilot Studio agent instructions (query planner + response formatter) | 2 files (.md + .txt) |
| 6 | `FDA Instructions Master Prompt.md` | Fabric Data Agent instructions (schema + DAX reference) | 2 files (.md + .txt) |
| 7 | `Agent Knowledge Sources Master Prompt.md` | Knowledge source files for CS agent (quick ref, glossary, QA pairs) | 3 files (.md) |

**Total:** Up to **18 files** of production-quality documentation and agent configuration per model/report.

---

## Quick Start

### Prerequisites
- **GitHub Copilot CLI** (or equivalent AI agent) with access to:
  - `powerbi-modeling-mcp` tools (for live model extraction)
  - File system tools (for reading TMDL/PBIX and writing output)
- **Power BI MCP extension** connected to your Fabric workspace
- For report docs: The `.pbix` file downloaded locally

### Step 1: Connect to the Semantic Model
```
Use powerbi-modeling-mcp connection_operations → ConnectFabric
Workspace: "Your Workspace Name"
Semantic Model: "Your Model Name"
```

### Step 2: Fill in the Variables & Run

Open the prompt file, fill in the **Inputs** table at the top, and paste the entire prompt into your Copilot CLI session.

---

## Prompt-by-Prompt Guide

### 1. Semantic Model Documentation (`Semantic Model Documentation Master Prompt.md`)

**Purpose:** Generates a complete business-ready documentation package — glossary, training guides, and audit-grade lineage tracking.

**Variables to fill in:**
| Variable | Example |
|---|---|
| `[WORKSPACE_ROOT]` | `PROD - Engineering` |
| `[TMDL_FOLDER]` | `c:\Users\you\docs\My Model.SemanticModel` |
| `[MODEL_NAME]` | `Capex Flash` |
| `[OUTPUT_DIR]` | `c:\Users\you\docs\Engineering\` |

**Generates:**
```
[OUTPUT_DIR]\Business Glossary Data Dictionary.html
[OUTPUT_DIR]\[Model] Business Guide.html
[OUTPUT_DIR]\[Model] Report Builder Training.html
[OUTPUT_DIR]\[Model] Report Builder Training v2.html
[OUTPUT_DIR]\[Model] Data Lineage Detailed.md
[OUTPUT_DIR]\generate_lineage_appendix.ps1
```

**Tip:** Run this first — it exports the TMDL folder which is needed by the other prompts.

---

### 2. Rebuild Blueprint (`Semantic Model Rebuild Blueprint Prompt.md`)

**Purpose:** Creates a single, comprehensive HTML document with every detail needed to recreate the semantic model from scratch — a disaster-recovery and institutional-knowledge artifact.

**Variables to fill in:**
| Variable | Example |
|---|---|
| `[WORKSPACE_ROOT]` | `PROD - Engineering` |
| `[MODEL_NAME]` | `Capex Flash` |
| `[OUTPUT_DIR]` | `c:\Users\you\docs\Engineering\` |

**Generates:**
```
[OUTPUT_DIR]\[Model] Rebuild Blueprint.html
```

**What's inside:** Executive summary, model config, data sources (with full M/SQL), complete table/column/relationship/measure catalogs, dependency graph, security roles, rebuild checklist.

---

### 3. Report Documentation (`Report Documentation Master Prompt.md`)

**Purpose:** Documents every page, visual, slicer, filter, and conditional formatting rule in a Power BI report — sufficient to rebuild the report from scratch.

**Variables to fill in:**
| Variable | Example |
|---|---|
| `[WORKSPACE_NAME]` | `PROD - Engineering` |
| `[REPORT_NAME]` | `Capex Flash` |
| `[MODEL_NAME]` | `Capex Flash` |
| `[OUTPUT_DIR]` | `c:\Users\you\docs\Engineering\` |

**Also needs:** The `.pbix` file downloaded locally (for Layout JSON extraction).

**Generates:**
```
[OUTPUT_DIR]\[Report] Report Blueprint.html
[OUTPUT_DIR]\[Report] Visual Catalog.md      (optional)
[OUTPUT_DIR]\[Report] Filter Map.md           (optional)
```

---

### 4. Metric Registry (`Metric Registry Master Prompt.md`)

**Purpose:** Generates a structured YAML metric registry documenting every measure with business definitions, DAX formulas, aggregation rules, time behavior, and QA test cases — ready for AI agent grounding.

**Variables to fill in:**
| Variable | Example |
|---|---|
| `[WORKSPACE_NAME]` | `PROD - Engineering` |
| `[MODEL_NAME]` | `Capex Flash` |
| `[OUTPUT_DIR]` | `c:\Users\you\docs\Engineering\` |
| `[DOMAIN]` (optional) | `Engineering / Capital Projects` |
| `[BUSINESS_OWNER]` (optional) | `VP Engineering` |
| `[DATA_STEWARD]` (optional) | `Data & Analytics Team` |

**Generates:**
```
[OUTPUT_DIR]\[Model] Metric Registry.yaml
```

---

### 5. CS Agent Instructions (`CS Agent Instructions Master Prompt.md`)

**Purpose:** Generates a complete Copilot Studio agent instruction set — the "brain" that resolves user questions, routes to correct measures, applies privacy rules, and delegates precise query specs to a Fabric Data Agent.

**Variables to fill in:**
| Variable | Example |
|---|---|
| `[WORKSPACE_NAME]` | `PROD - Engineering` |
| `[MODEL_NAME]` | `Project Financials` |
| `[OUTPUT_DIR]` | `c:\Users\you\docs\Engineering\Project Financials\Agent Instructions\` |
| `[DOMAIN]` | `Engineering / Capital Projects` |
| `[AUDIENCE]` | `Project Managers and Engineering Leadership` |
| `[COMPANY]` | `Targa Resources` |
| `[METRIC_REGISTRY_PATH]` (optional) | Path to the Metric Registry YAML |
| `[BUSINESS_GUIDE_PATH]` (optional) | Path to the Business Guide HTML |

**Generates:**
```
[OUTPUT_DIR]\[Model]_Agent_Instructions.md
[OUTPUT_DIR]\[Model]_Agent_Instructions.txt   (paste-ready, ≤8,000 CRLF)
```

**Key features:** Measure routing, aggregation guardrails, terminology resolution, 1-FDA-call-per-question cap, conversational response depth, privacy rules.

---

### 6. FDA Instructions (`FDA Instructions Master Prompt.md`)

**Purpose:** Generates Fabric Data Agent instructions — the "hands" that receive precise query specs and generate correct DAX. Contains full schema reference (tables, columns, relationships, measures with DAX expressions).

**Variables to fill in:**
| Variable | Example |
|---|---|
| `[WORKSPACE_NAME]` | `PROD - Engineering` |
| `[MODEL_NAME]` | `Project Financials` |
| `[OUTPUT_DIR]` | `c:\Users\you\docs\Engineering\Project Financials\Agent Instructions\` |
| `[DOMAIN]` | `Engineering / Capital Projects` |
| `[COMPANY]` | `Targa Resources` |
| `[METRIC_REGISTRY_PATH]` (optional) | Path to the Metric Registry YAML |

**Generates:**
```
[OUTPUT_DIR]\[Model]_Fabric_Data_Agent_Instructions.md
[OUTPUT_DIR]\[Model]_Fabric_Data_Agent_Instructions.txt   (paste-ready, ≤15,000 CRLF)
```

**Key features:** Complete measure catalog with DAX, full table/column reference, relationship map with bi-directional warnings, REMOVEFILTERS documentation, "return only what requested" response style.

---

### 7. Agent Knowledge Sources (`Agent Knowledge Sources Master Prompt.md`)

**Purpose:** Generates three knowledge source files that are uploaded to Copilot Studio as retrieval-augmented grounding documents. These provide the agent with detailed measure reference, terminology resolution, and verified Q&A pairs.

**Variables to fill in:**
| Variable | Example |
|---|---|
| `[WORKSPACE_NAME]` | `PROD - Engineering` |
| `[MODEL_NAME]` | `Project Financials` |
| `[OUTPUT_DIR]` | `c:\Users\you\docs\Engineering\Project Financials\Knowledge Sources\` |
| `[DOMAIN]` | `Engineering / Capital Projects` |
| `[COMPANY]` | `Targa Resources` |
| `[METRIC_REGISTRY_PATH]` (optional) | Path to the Metric Registry YAML |
| `[BUSINESS_GUIDE_PATH]` (optional) | Path to the Business Guide HTML |
| `[DATA_LINEAGE_PATH]` (optional) | Path to the Data Lineage MD |
| `[AGENT_INSTRUCTIONS_PATH]` (optional) | Path to the CS Agent Instructions |

**Generates:**
```
[OUTPUT_DIR]\[Model]_Agent_Knowledge.md         (concise quick reference ~12K chars)
[OUTPUT_DIR]\[Model]_Business_Glossary.md       (synonym map ~10K chars)
[OUTPUT_DIR]\[Model]_Metric_QA_Reference.md     (full definitions + Q&A ~30K chars)
```

**Key features:** Chunking-optimized for CS semantic search (~500-token chunks), self-contained per-measure entries, metric ID cross-referencing across all 3 files, 2+ verified Q&A pairs per model measure, explicit summability/scope classification.

---

## Recommended Workflow

Run the prompts in this order for a complete documentation package:

```
┌─────────────────────────────────────────────────┐
│  1. Semantic Model Documentation                │
│     → Exports TMDL, generates 6 files           │
│     → Creates lineage + glossary + training     │
├─────────────────────────────────────────────────┤
│  2. Rebuild Blueprint                           │
│     → Extracts ALL model metadata via MCP       │
│     → Creates disaster-recovery blueprint       │
├─────────────────────────────────────────────────┤
│  3. Report Documentation                        │
│     → Requires PBIX file downloaded locally      │
│     → Documents every page, visual, filter      │
├─────────────────────────────────────────────────┤
│  4. Metric Registry                             │
│     → Creates YAML registry for AI grounding    │
│     → Always generated for every model          │
├─────────────────────────────────────────────────┤
│  5. CS Agent Instructions                       │
│     → Generates Copilot Studio instructions     │
│     → Uses metric registry + business guide     │
├─────────────────────────────────────────────────┤
│  6. FDA Instructions                            │
│     → Generates Fabric Data Agent instructions  │
│     → Full schema + DAX + relationships         │
├─────────────────────────────────────────────────┤
│  7. Agent Knowledge Sources                     │
│     → Generates 3 CS retrieval documents        │
│     → Quick ref + glossary + metric QA          │
└─────────────────────────────────────────────────┘
```

**Recommended order:** Run 1 → 4 first (documentation + registry), then 5 → 7 (agent artifacts). Prompts 5–7 benefit from having the metric registry, business guide, and lineage already generated.

**Shortcut:** You can run prompts 1–4 in a single session. Run 5–7 separately since they read the outputs of 1–4.

---

## Output Folder Structure (Example)

After running all 6 prompts for "Capex Flash":

```
Engineering/
├── Capex Flash/                          ← One subfolder per model
│   ├── Business Glossary Data Dictionary.html
│   ├── Capex Flash Business Guide.html
│   ├── Capex Flash Data Lineage Detailed.md
│   ├── Capex Flash Metric Registry.yaml
│   ├── Capex Flash Rebuild Blueprint.html
│   ├── Capex Flash Report Blueprint.html
│   ├── Capex Flash Report Builder Training.html
│   ├── Capex Flash Report Builder Training v2.html
│   ├── generate_lineage_appendix.ps1
│   ├── Agent Instructions/               ← From prompts 5 & 6
│   │   ├── Capex_Flash_Agent_Instructions.md
│   │   ├── Capex_Flash_Agent_Instructions.txt
│   │   ├── Capex_Flash_Fabric_Data_Agent_Instructions.md
│   │   └── Capex_Flash_Fabric_Data_Agent_Instructions.txt
│   └── Knowledge Sources/                ← From prompt 7
│       ├── Capex_Flash_Agent_Knowledge.md
│       ├── Capex_Flash_Business_Glossary.md
│       └── Capex_Flash_Metric_QA_Reference.md
├── Capex Flash.SemanticModel/            ← TMDL export (auto-generated)
│   ├── tables/
│   ├── relationships.tmdl
│   ├── model.tmdl
│   └── ...
├── EPC Transactions/
├── Execute Projects On-Budget/
└── Project Financials/
```

---

## Tips & Best Practices

1. **One model at a time** — Connect to the target model before pasting the prompt.

2. **Organize by domain** — Use subfolders per business area (e.g., `Engineering/`, `HR/`, `Finance/`).

3. **Re-run after model changes** — The prompts are idempotent; re-running updates existing files.

4. **PBIX download** — For report docs, download the `.pbix` from the Fabric workspace first. The agent extracts the Report/Layout JSON from it.

5. **Large models (100+ measures)** — May take 10–15 minutes per prompt. The agent handles pagination and batching automatically.

6. **Lineage script** — `generate_lineage_appendix.ps1` can be re-run manually anytime to regenerate the lineage MD from TMDL files without AI.

7. **AI agent grounding** — The Metric Registry YAML is designed for AI grounding. The Knowledge Sources (Prompt 7) are specifically optimized for Copilot Studio's semantic search retrieval — upload all 3 files as knowledge sources for best agent performance.

---

## Models Documented So Far

| Model | Workspace | Domain | Status |
|---|---|---|---|
| People Analytics | TEST - Fabric HR Data | HR / Workforce | ✅ Complete (all 7 prompts) |
| Capex Flash | PROD - Engineering | Engineering / Capital Projects | ✅ Complete (prompts 1–4) |
| EPC Transactions | PROD - Engineering | Engineering / EPC | ✅ Complete (prompts 1–4) |
| Execute Projects On-Budget | PROD - Engineering | Engineering / Project Execution | ✅ Complete (prompts 1–4) |
| Project Financials | PROD - Engineering | Engineering / Finance | ✅ Complete (prompts 1–4) |

---

## Questions?

Contact the Data & Analytics team or open an issue in this repository.
