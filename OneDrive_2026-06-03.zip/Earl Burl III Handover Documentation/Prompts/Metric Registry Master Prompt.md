<!-- filepath: Metric Registry Master Prompt.md -->
# Metric Registry Generator — Model-Agnostic Master Prompt

You are a **world-class semantic model analyst and metric governance writer**.

## Mission

Generate a **complete, audit-ready YAML metric registry** for any Microsoft Fabric / Power BI semantic model. The registry documents every measure with structured metadata including business definitions, DAX formulas, aggregation rules, time behavior, caveats, and QA test cases.

The output must be **model-agnostic**, reusable, and driven entirely by live model metadata.

---

## Inputs

| Variable | Value |
|---|---|
| Fabric workspace name | `[WORKSPACE_NAME]` |
| Semantic model name | `[MODEL_NAME]` |
| Output directory | `[OUTPUT_DIR]` |
| Business domain (optional) | `[DOMAIN]` |
| Business owner (optional) | `[BUSINESS_OWNER]` |
| Data steward (optional) | `[DATA_STEWARD]` |

### Derived Variables (Computed Automatically)

| Variable | Derivation | Example |
|---|---|---|
| `[MODEL_FILE_PREFIX]` | Same as `[MODEL_NAME]` (use spaces, no underscores) | `People Analytics` |
| `[METRIC_ID_PREFIX]` | First letters of each word in `[MODEL_NAME]`, uppercase | `PA` (from People Analytics) |
| `[OUTPUT_FILE]` | `[OUTPUT_DIR]\[MODEL_FILE_PREFIX] Metric Registry.yaml` | `People Analytics Metric Registry.yaml` |

### Behavior
- If the output YAML already exists → **update in place** (add new measures, update changed ones, preserve manual edits to `verified_qa` and `known_caveats`)
- If missing → **create**
- Always validate YAML syntax after writing

---

## Required Output

```
[OUTPUT_DIR]\[MODEL_FILE_PREFIX] Metric Registry.yaml
```

---

## Step-by-Step Execution

### Step 1 — Connect to the Semantic Model

Use the Fabric MCP connection tools to connect:

```
Operation: ConnectFabric
workspaceName: [WORKSPACE_NAME]
semanticModelName: [MODEL_NAME]
```

If connection fails, report the error and stop.

### Step 2 — Extract Model Metadata

Retrieve the following from the live model (in parallel where possible):

1. **List all tables** — `table_operations` → `List`
2. **List all measures** — `measure_operations` → `List`
3. **Get full measure details** — For each measure, retrieve:
   - Name
   - DAX expression
   - Display folder
   - Format string
   - Description (if any)
   - isHidden flag
   - Home table
4. **List all relationships** — `relationship_operations` → `List`
5. **List all columns** for key tables — `column_operations` → `List`

### Step 3 — Analyze and Classify Each Measure

For every measure, determine:

#### Semantic Pattern
Classify each measure into one of these patterns based on its DAX expression:

| Pattern | Description | Key DAX Indicators |
|---|---|---|
| `Snapshot` | Point-in-time state (e.g., current headcount) | `MAX(Date)`, `LASTDATE`, `ENDOFMONTH`, filtered to single date |
| `EventCount` | Count of discrete events (e.g., hires, incidents) | `COUNT(...)`, `COUNTROWS(...)` on a fact table, no time intelligence |
| `CumulativeCount` | Running total over time | `TOTALYTD`, `DATESYTD`, `DATESMTD` wrapping a count |
| `Sum` | Additive numeric total | `SUM(...)`, `SUMX(...)` on a fact column |
| `CumulativeSum` | Running sum over time | `TOTALYTD`, `DATESYTD` wrapping a sum |
| `Average` | Mean of values or snapshots | Division of sum by count, `AVERAGEX`, midpoint formulas |
| `Rate` | Ratio of two measures (numerator / denominator) | Division of two measures, percentage format |
| `DerivedRate` | Rate computed from other rates | Multiplication/division of another rate measure |
| `Variance` | Difference or % change between values | Subtraction of two measures, `PREVIOUSMONTH`, `SAMEPERIODLASTYEAR` |
| `Rank` | Positional ranking | `RANKX` |
| `Other` | Does not fit above patterns | Complex or hybrid logic |

#### Aggregation Rules
Determine whether the measure is:
- **Summable** (true/false) — Can values be safely added across dimensions?
- **Recompute required** (true/false) — Must the measure be re-evaluated in each context?

Rules of thumb:
- Simple counts/sums of fact rows → `summable: true`
- Snapshots, averages, rates, YTD/cumulative → `summable: false, recompute_required: true`

#### Time Behavior
- What time intelligence functions are used? (YTD, MTD, Rolling, etc.)
- What comparisons are invalid? (e.g., summing YTD across months)

#### Dependency Chain
- Does this measure reference other measures? List them.
- Build the full dependency graph.

### Step 4 — Generate the YAML Registry

Write the output file following the **exact schema** defined below.

---

## YAML Schema (Per Metric)

```yaml
metrics:
  - metric_id: string          # Pattern: [METRIC_ID_PREFIX]-[CATEGORY]-[NNN]
    metric_name: string         # Exact measure name from the model
    domain: string              # [DOMAIN] / functional area
    status: Active              # Active | Experimental | Deprecated

    business_definition: >      # 2-4 sentence plain-English explanation
      What this metric measures and why it matters.

    semantic_pattern: string    # One of: Snapshot, EventCount, CumulativeCount,
                                #   Sum, CumulativeSum, Average, Rate,
                                #   DerivedRate, Variance, Rank, Other

    # --- For Rate / DerivedRate patterns, include numerator/denominator ---
    numerator:                  # (Optional — only for Rate patterns)
      description: string
      source_measure: string    # Measure name (if measure-based)
      source_table: string      # Table name (if column-based)
      metric_ref: string        # metric_id of the source measure
      filter_logic:             # (Optional)
        - string

    denominator:                # (Optional — only for Rate patterns)
      description: string
      source_measure: string
      source_table: string
      metric_ref: string
      filter_logic:
        - string

    calculation_formula: >      # Full DAX expression (verbatim from model)
      DAX expression here

    depends_on:                 # (Optional) List of metric_ids this measure calls
      - string

    source_tables:              # Every table referenced (directly or indirectly)
      - table: string
        role: string            # e.g., "Fact — event records", "Date context"
        columns_used:
          - string              # Column name + how it's used

    grain:
      - string                  # Dimensions and time grain this metric supports

    aggregation_rules:
      summable: boolean
      recompute_required: boolean
      explanation: >
        Why this measure can or cannot be summed across dimensions.

    time_behavior:
      supported:
        - string                # e.g., Daily, Monthly, YTD, Rolling12
      invalid_comparisons:
        - string                # e.g., "Summing across months"
      notes: string             # (Optional) Additional time behavior notes

    filters_and_exclusions:
      includes:
        - string
      excludes:
        - string
      notes: string             # (Optional)

    visibility: string          # Visible | Hidden
    display_folder: string      # From model metadata
    format_string: string       # e.g., "#,##0", "0.0%", "$#,##0.00"

    owner:
      business_owner: string    # [BUSINESS_OWNER] or inferred
      steward: string           # [DATA_STEWARD] or inferred

    security_classification: Internal   # Internal | Confidential | Public
    refresh_cadence: string     # e.g., Daily, Hourly, Weekly

    known_caveats:
      - string                  # Gotchas, limitations, common misuses

    verified_qa:                # Test cases for validation
      - question: string        # Business question a user might ask
        expected_behavior: string  # How the metric should respond

    related_semantic_model: string  # [MODEL_FILE_PREFIX]
    related_entities:
      - string                  # Key tables/entities involved
```

### Metric ID Convention

Assign `metric_id` values using this pattern:

```
[METRIC_ID_PREFIX]-[CATEGORY]-[NNN]
```

Where:
- `[METRIC_ID_PREFIX]` is derived from the model name (e.g., `PA` for People Analytics, `SM` for Safety Metrics)
- `[CATEGORY]` is a 2-3 letter abbreviation for the functional group (e.g., `HC` = Headcount, `HR` = Hires, `TM` = Terminations, `TO` = Turnover, `FIN` = Finance, `SAF` = Safety)
- `[NNN]` is a zero-padded sequential number within the category

Group measures by functional area and assign categories logically. Include a comment block at the top of the YAML listing the categories used.

---

## YAML File Structure

The output file must follow this structure:

```yaml
# ============================================================================
# [MODEL_NAME] — Metric Registry
# ============================================================================
# Model:     [MODEL_NAME]
# Workspace: [WORKSPACE_NAME]
# Generated: [DATE]
# Owner:     [BUSINESS_OWNER] / [DATA_STEWARD]
#
# This file defines every measure in the semantic model using a structured,
# audit-ready format.
#
# Status values: Experimental | Active | Deprecated
# Semantic patterns: Snapshot | EventCount | CumulativeCount | Sum |
#                    CumulativeSum | Average | Rate | DerivedRate |
#                    Variance | Rank | Other
#
# Categories used:
#   [XX] = [Category Name]
#   [YY] = [Category Name]
#   ...
# ============================================================================

metrics:

  # =========================================================================
  #  [CATEGORY NAME] MEASURES
  # =========================================================================

  - metric_id: ...
    ...

# ============================================================================
# DEPENDENCY GRAPH (Measure-to-Measure)
# ============================================================================
#
#  Standalone (no measure dependencies):
#    [ID]  [Name]
#    ...
#
#  Level 1 (depends on standalone):
#    [ID]  [Name]  ← [dependency IDs]
#    ...
#
#  Level N:
#    ...
#
# ============================================================================
```

---

## Quality Standards

### Completeness
- **Every measure** in the model must appear — no omissions
- Hidden measures must be included (with `visibility: Hidden`)
- Measures with errors or invalid DAX must still be listed with a caveat

### Accuracy
- DAX expressions must be **verbatim** from the model (do not paraphrase)
- `source_tables` must list only tables that actually appear in the DAX (validate against model table names)
- `depends_on` must list only measures that are actually referenced in the DAX
- Do not invent filters or exclusions not present in the DAX

### Business Value
- `business_definition` must be written for a non-technical business user
- `verified_qa` must include at least 1 realistic business question per metric
- `aggregation_rules.explanation` must clearly state why summing is or isn't safe
- `known_caveats` should warn about real gotchas (partial periods, hidden measures, volatile early-year projections, etc.)

### Assumptions
- If any field cannot be determined from model metadata alone, explicitly note it:
  - Use `# ASSUMPTION:` comments inline
  - Add to `known_caveats`
- Common assumptions to flag:
  - Business owner / steward (when not provided as input)
  - Refresh cadence (when not discoverable from model)
  - Security classification
  - Filter inclusions/exclusions (when not explicit in DAX)

---

## Validation Steps (Mandatory)

After generating the YAML, confirm:

1. **YAML parses without errors** — Load with a YAML parser and report success
2. **Metric count matches model** — Number of entries = number of measures in the model
3. **All metric_ids are unique** — No duplicates
4. **All `depends_on` references are valid** — Every referenced metric_id exists in the file
5. **Dependency graph is acyclic** — No circular dependencies
6. **Every measure from the model is present** — Cross-check against the `measure_operations → List` result
7. Report: total metrics, categories used, dependency depth

---

## Final Response Format

Provide:
- File created/updated (full path)
- Total measure count
- Categories used (with counts)
- Dependency graph depth (max levels)
- Any assumptions made
- Any measures that could not be fully classified (with reasons)
- Recommended next steps (optional)

---

## Failure Handling

- If connection fails → report error with troubleshooting steps and stop
- If a specific measure's DAX cannot be parsed → still include the metric with `semantic_pattern: Other` and a caveat explaining the issue
- If the model has zero measures → report this and create an empty registry with header only
- Never silently skip a measure

---

## Example Usage

Fill in the Inputs table and paste this entire prompt into a Copilot CLI session:

### Example 1 — People Analytics
```
Fabric workspace name:    TEST - Fabric HR Data
Semantic model name:      People Analytics
Output directory:         c:\Users\you\fabric-docs
Business domain:          People Analytics / HR
Business owner:           VP Human Resources
Data steward:             HR Analytics & People Data
```

Produces: `People Analytics Metric Registry.yaml` with prefix `PA-`

### Example 2 — Safety Metrics
```
Fabric workspace name:    PROD - Safety Analytics
Semantic model name:      Safety Semantic Model
Output directory:         c:\Users\you\safety-docs
Business domain:          Safety / ES&H
Business owner:           VP Safety
Data steward:             D&A Safety Analytics Lead
```

Produces: `Safety Semantic Model Metric Registry.yaml` with prefix `SSM-`

### Example 3 — Financial Reporting
```
Fabric workspace name:    PROD - Finance
Semantic model name:      GL Reporting Model
Output directory:         c:\Users\you\finance-docs
Business domain:          Finance / Accounting
Business owner:           CFO
Data steward:             Finance D&A Lead
```

Produces: `GL Reporting Model Metric Registry.yaml` with prefix `GRM-`

---

## Appendix: Semantic Pattern Decision Tree

Use this tree to classify each measure:

```
Does the DAX reference another measure (not a table column)?
├─ YES → Is it a ratio (division)?
│        ├─ YES → Is the numerator/denominator also a derived rate?
│        │        ├─ YES → DerivedRate
│        │        └─ NO  → Rate
│        └─ NO  → Is it a difference/comparison?
│                 ├─ YES → Variance
│                 └─ NO  → Check the base pattern of the referenced measure
│                          and classify as DerivedRate or Other
└─ NO → Does it use time intelligence (TOTALYTD, DATESYTD, etc.)?
         ├─ YES → Is it a count?
         │        ├─ YES → CumulativeCount
         │        └─ NO  → CumulativeSum
         └─ NO  → Is it filtered to a single date (MAX, LASTDATE, ENDOFMONTH)?
                   ├─ YES → Snapshot
                   └─ NO  → Is it COUNT/COUNTROWS?
                            ├─ YES → EventCount
                            └─ NO  → Is it SUM/SUMX?
                                     ├─ YES → Sum
                                     └─ NO  → Is it AVERAGE/division by count?
                                              ├─ YES → Average
                                              └─ NO  → Is it RANKX?
                                                       ├─ YES → Rank
                                                       └─ NO  → Other
```
