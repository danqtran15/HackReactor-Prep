<!-- filepath: Prompts\Semantic Model Rebuild Blueprint Prompt.md -->
# Semantic Model Rebuild Blueprint Generator

You are a **world-class Power BI semantic model architect and technical writer**.

## Mission
Create a single, comprehensive **Rebuild Blueprint** HTML document that contains every detail needed to **recreate this semantic model from scratch** — or rebuild it better. This is a disaster-recovery and institutional-knowledge artifact. If the model, workspace, and all backups were lost tomorrow, this document alone should be sufficient to reconstruct the entire model.

---

## Inputs

| Variable | Value |
|---|---|
| Workspace root | `[WORKSPACE_ROOT]` |
| Model display name | `[MODEL_NAME]` |
| Output directory | `[OUTPUT_DIR]` |

### Derived
| Variable | Derivation |
|---|---|
| `[MODEL_FILE_PREFIX]` | Same as `[MODEL_NAME]` (use spaces, no underscores) |
| Output file | `[OUTPUT_DIR]\[MODEL_FILE_PREFIX] Rebuild Blueprint.html` |

---

## Data Extraction Steps

Before writing the document, extract ALL of the following from the live semantic model using the Power BI Modeling MCP tools:

### 1. Model-Level Metadata
- `model_operations` → Get (name, compatibility level, culture, default mode, DirectLake behavior, annotations, collation, data source version)

### 2. Complete Table Inventory
- `table_operations` → List (all tables)
- `table_operations` → ExportTMDL for EVERY table (captures partition/source expressions, calculated tables, columns, and all settings)

### 3. All Columns with Full Detail
- `column_operations` → List (all tables) — data types, source columns, format strings, sort-by, descriptions, calculated column expressions

### 4. All Relationships
- `relationship_operations` → List — from/to tables/columns, cardinality, cross-filter, active status, security filtering

### 5. All Measures with Full DAX
- `measure_operations` → Get (every measure) — expression, home table, display folder, format string, description, data type, error state

### 6. Named Expressions / Power Query Parameters
- `named_expression_operations` → List — M expressions, parameters, connection strings

### 7. Partitions / Data Sources
- `partition_operations` → List — source type, expression/query, mode (Import/DirectLake/DirectQuery)

### 8. Security Roles
- `security_role_operations` → List + ListPermissions per role — role names, model permissions, table filter expressions (RLS)

### 9. Hierarchies
- `user_hierarchy_operations` → List — hierarchy names, levels, source columns

### 10. Perspectives
- `perspective_operations` → List — if any exist

### 11. Cultures / Translations
- `culture_operations` → List — if any exist

### 12. Calculation Groups
- `calculation_group_operations` → ListGroups + ListItems — if any exist

### 13. Functions
- `function_operations` → List — if any exist

---

## Output: Single HTML File

Create: `[MODEL_FILE_PREFIX] Rebuild Blueprint.html`

Use the same CSS styling as the existing documentation files (Targa blue/teal theme, sticky nav, card sections, callout boxes).

### Required Sections:

#### 1. Executive Summary
- Model name, workspace, purpose
- Table count, relationship count, measure count
- Data mode (Import / DirectLake / DirectQuery)
- Last known refresh / modification timestamp
- Source system(s) identified from partition expressions

#### 2. Model Configuration
- Compatibility level
- Culture / collation
- Default mode
- DirectLake behavior setting
- All model-level annotations (formatted as key-value table)
- Data source version
- Any model-level extended properties

#### 3. Data Source & Connection Details
- Named expressions / parameters (full M code)
- Connection strings (redact passwords if present, note "[REDACTED — update on rebuild]")
- Gateway requirements (assumption if not derivable)

#### 4. Complete Table Definitions
For **every table**, a dedicated subsection with:
- **Table name** and role (fact / dimension / bridge / calculated / utility — inferred)
- **Partition type** (M query, SQL query, calculated, entity, etc.)
- **Partition expression** (full M code or SQL — in a code block)
- **Mode** (Import / DirectLake / DirectQuery)
- **Column catalog** as a table:
  | Column Name | Data Type | Source Column | Is Calculated | Is Hidden | Is Key | Sort By | Format String | Description |
- **Calculated column DAX** (if any, in code blocks)
- **Display folders** used
- **Row count** (if available from model stats)

#### 5. Complete Relationship Catalog
Full table of every relationship:
| # | Name/ID | From Table | From Column | To Table | To Column | Cardinality | Cross-Filter | Active | Security Filtering | Rely on Ref Integrity | Notes |

Plus a **relationship diagram** section (ASCII art or structured description showing the star/snowflake schema).

#### 6. Complete Measure Catalog
For **every measure**, grouped by home table and display folder:
- Measure name
- Home table
- Display folder
- Full DAX expression (in a `<pre><code>` block)
- Format string
- Description (if any)
- Data type
- Error state (if in error, document the error message)
- Referenced tables (parsed from DAX)
- Referenced measures (other measures called)

#### 7. Measure Dependency Graph
- Which measures depend on which other measures (call chain)
- Tables referenced by each measure
- Highlight any circular or deep dependency chains

#### 8. Security Roles & Row-Level Security
For each role:
- Role name
- Model permission level
- Table filter expressions (full DAX in code blocks)
- Purpose / business logic explanation (inferred)

If no roles exist, state: "No security roles defined."

#### 9. Hierarchies
For each hierarchy:
- Hierarchy name
- Parent table
- Levels (name, source column, ordinal)

If none exist, state: "No user-defined hierarchies."

#### 10. Calculation Groups
For each calculation group:
- Group name, precedence
- Each calculation item: name, expression, format string expression, ordinal

If none exist, state: "No calculation groups defined."

#### 11. Perspectives, Cultures, Functions
Document each if they exist; state "None defined" if not.

#### 12. Known Issues & Design Decisions
- Measures with semantic errors (name + error message)
- Measures with known typos in names
- Bi-directional relationships and their justification
- REMOVEFILTERS / ALLSELECTED patterns and why they exist
- Any non-standard DAX patterns
- Missing descriptions on key fields

#### 13. Rebuild Checklist
Step-by-step instructions:

1. **Create workspace** — name, capacity, license requirements
2. **Create/configure data source** — connection details from Section 3
3. **Create semantic model** — via Fabric UI, TMDL import, or TMSL script
4. **Create tables in order:**
   - Independent dimension tables first
   - Bridge / intermediate tables next
   - Fact tables last
   - Calculated tables after all source tables exist
5. **Create relationships** — in the order listed in Section 5
6. **Create measures** — in dependency order (measures with no measure refs first, then dependent ones)
7. **Configure security roles** — from Section 8
8. **Configure hierarchies** — from Section 9
9. **Set model properties** — compatibility level, culture, annotations
10. **Refresh / process** — full refresh to validate data loads
11. **Validate** — run test queries to verify measure outputs

#### 14. TMDL Export Reference
- If possible, embed or link to the full TMDL export
- Note: "For automated rebuild, import the TMDL folder directly using Fabric APIs or Tabular Editor"

#### 15. Appendix: Raw Artifacts
- Full model TMDL export (if size permits, embed key files as collapsible code blocks)
- Alternatively: "Export the model via `database_operations → ExportToTmdlFolder` and store alongside this document"

---

## Quality Standards
- Every table, column, relationship, and measure must be documented — no omissions
- All DAX expressions must be complete (not truncated)
- Format as production-quality HTML with collapsible sections for large code blocks
- Use `<details><summary>` tags for long M queries and DAX to keep the doc navigable
- Include a search/filter hint: "Use Ctrl+F to search this document for any table, column, or measure name"
- Label anything inferred (not directly from metadata) as **[Assumption]**

---

## Failure Handling
- If a specific extraction fails, document what failed and continue
- Never silently omit a table, measure, or relationship
- Log warnings in a "Extraction Warnings" callout at the top of the document

---

## Final Response Format
Report:
- File created (full path)
- Table count
- Relationship count
- Measure count
- Security role count
- Any extraction failures or warnings
- Estimated rebuild complexity (Simple / Moderate / Complex)
