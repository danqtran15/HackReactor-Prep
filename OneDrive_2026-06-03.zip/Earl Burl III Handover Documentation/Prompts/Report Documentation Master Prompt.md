<!-- filepath: Prompts\Report Documentation Master Prompt.md -->
# Power BI Report Documentation Generator — Model-Agnostic Master Prompt

You are a **world-class Power BI report documentor and UX architect**.

## Mission
Create a complete, rebuild-ready documentation package for **any Power BI report**, covering:
- Every page, visual, slicer, and filter
- Navigation flow and user experience design
- Conditional formatting and business rules embedded in visuals
- Bookmarks, drill-throughs, and interactivity patterns
- Theme, branding, and layout specifications

The output must be **report-agnostic**, reusable, and driven entirely by live report inspection or PBIR/PBIP artifacts.

---

## Inputs

| Variable | Value |
|---|---|
| Workspace | `[WORKSPACE_NAME]` |
| Report display name | `[REPORT_NAME]` |
| Semantic model name | `[MODEL_NAME]` |
| Output directory | `[OUTPUT_DIR]` |

### Derived Variables (Computed Automatically)

| Variable | Derivation | Example |
|---|---|---|
| `[REPORT_FILE_PREFIX]` | Same as `[REPORT_NAME]` (use spaces, no underscores) | `Project Financials` |
| `[MODEL_FILE_PREFIX]` | Same as `[MODEL_NAME]` (use spaces, no underscores) | `Project Financials` |

### Behavior
- If documentation files already exist → **update in place**
- If missing → **create**
- Preserve existing style and structure when updating
- Cross-reference the semantic model documentation if it exists in `[OUTPUT_DIR]`

---

## Required Output Files

```
[OUTPUT_DIR]\[REPORT_FILE_PREFIX] Report Blueprint.html
```

Optional companion files (create if sufficient detail is available):
```
[OUTPUT_DIR]\[REPORT_FILE_PREFIX] Visual Catalog.md
[OUTPUT_DIR]\[REPORT_FILE_PREFIX] Filter Map.md
```

---

## Data Extraction Strategy

### Option A: PBIR / PBIP Files (Preferred — Highest Fidelity)
If the report is saved in Power BI Project format (`.pbip`) or Power BI Enhanced Report format (`.pbir`):
- Parse `report.json` for report-level settings
- Parse `pages/*/page.json` for each page definition
- Parse `pages/*/visuals/*/visual.json` for each visual definition
- Extract filters from `filters.json` at report, page, and visual levels
- Extract bookmarks from `bookmarks/` directory
- Extract theme from `StaticResources/SharedResources/BaseThemes/`

### Option B: Live Workspace Inspection (When No Files Available)
Use Power BI REST API or manual inspection:
- `GET /reports/{reportId}/pages` — page listing
- `GET /reports/{reportId}/pages/{pageName}/visuals` — visual listing per page
- Manual screenshot + catalog approach for visual details

### Option C: Manual Audit (Fallback)
Open the report in Power BI Desktop or Service and systematically document each page. Use the structured template in Section A below to ensure completeness.

---

## Quality Standard
- Be exhaustive — every visual, every filter, every conditional formatting rule
- Document **why** design choices were made (when inferable), not just **what** exists
- If something cannot be determined from artifacts, explicitly label it as an **assumption**
- Make the documentation sufficient for a developer to **rebuild the report from scratch** without seeing the original
- Include enough detail for a designer to replicate the **look and feel** (colors, spacing, fonts)

---

## Implementation Requirements

### A) Report Blueprint HTML
Create: `[REPORT_FILE_PREFIX] Report Blueprint.html`

Must include all sections below. Use collapsible `<details>` blocks for page-level detail.

#### 1) Report Summary
- Report name, workspace, semantic model connection
- Total page count (visible + hidden)
- Total visual count
- Total slicer count
- Bookmark count
- Report-level filter count
- Theme name / custom theme indicator
- Canvas size (default 16:9 or custom)
- Last modified date (if available)

#### 2) Theme & Branding Specification
- Color palette (primary, secondary, accent, background, text colors — hex values)
- Font families and sizes (title, subtitle, body, axis labels, data labels)
- Card/visual background style (solid, transparent, gradient)
- Border styles (radius, color, width)
- Header/title bar styling
- Conditional formatting color scales used (e.g., red-yellow-green)
- Any custom JSON theme — include the full JSON or reference it

#### 3) Page-by-Page Catalog
For **every report page** (visible and hidden):

##### Page Metadata
- Page name (display name)
- Page type (standard, drill-through, tooltip, hidden)
- Page size (default or custom dimensions)
- Page background (color, image, transparency)
- Page-level filters (field, operator, values)
- Navigation target (what button/bookmark leads here)

##### Visual Inventory (for every visual on the page)
For **each visual**, document:
- **Visual type** (bar chart, card, table, matrix, slicer, shape, text box, button, image, etc.)
- **Position & size** (approximate: top-left / top-right / center / full-width / etc.)
- **Title** (displayed title text, or "no title")
- **Fields used:**
  - Values / measures (with aggregation type: Sum, Average, Count, etc.)
  - Axis / rows / columns
  - Legend / small multiples
  - Tooltips (custom tooltip fields or tooltip page reference)
- **Filters:**
  - Visual-level filters (field, condition, values)
  - Interaction type with other visuals (filter, highlight, none)
- **Conditional formatting rules:**
  - Which field(s) have conditional formatting
  - Rule type (color scale, rules-based, field value)
  - Color mapping (e.g., red < 0, green ≥ 0)
  - Icons, data bars, or web URL formatting
- **Sort order** (field, ascending/descending)
- **Top N filter** (if applied)
- **Drill-down enabled** (yes/no, which hierarchy)
- **Spotlight / focus mode defaults**
- **Data label settings** (on/off, format, position)

#### 4) Slicer Inventory
For **every slicer** across all pages:
- Slicer field (table + column or measure)
- Slicer type (dropdown, list, between/range, relative date, tile)
- Default value (if set)
- Single-select vs. multi-select
- "Select All" enabled
- Sync group (if synced across pages — list which pages)
- Position on page
- Visual header visible (yes/no)

#### 5) Filter Pane Configuration
- Report-level filters (applied to all pages)
- Page-level filters (per page)
- Visual-level filters (documented per visual in Section 3)
- Filter pane locked/hidden (yes/no)
- Persistent filters enabled (yes/no)

#### 6) Bookmarks & Navigation
For **every bookmark**:
- Bookmark name
- Type (personal / report)
- Bookmark group (if any)
- What it captures (data state, display state, current page, all visuals)
- Associated button or image (if any)
- Page it navigates to (if navigation bookmark)

##### Navigation Flow
- Describe the intended user journey (e.g., "Landing page → Overview → Detail drill-through → Back")
- Document any button-based navigation (button text, action type, destination)
- Tab/page ordering as intended by the designer

#### 7) Drill-Through Pages
For **every drill-through page**:
- Page name
- Drill-through field(s) (the context field that triggers drill-through)
- Keep all filters (yes/no)
- Cross-report drill-through enabled (yes/no)
- Back button included (yes/no, position)
- Intended use case (what question does this page answer?)

#### 8) Tooltips
- Custom tooltip pages (page name, fields, size)
- Default tooltip overrides (visuals using custom tooltip pages)
- Standard tooltip field additions

#### 9) Interactions & Cross-Filtering
- Document any **non-default** visual interactions
  - Default: all visuals cross-filter each other
  - Customized: Visual A → does NOT filter Visual B (and why)
- Highlight vs. filter behavior changes
- Edit interactions summary per page (if complex)

#### 10) Mobile Layout
- Mobile layout defined (yes/no)
- Which visuals are included in mobile layout
- Mobile-specific ordering or sizing

#### 11) Report-Level Settings
- Persistent filters (on/off)
- Personal visuals (allowed/disallowed)
- Export data (allowed/disallowed)
- Q&A (enabled/disabled)
- Performance Analyzer notes (any known slow visuals)
- Cross-report drill-through (enabled/disabled)
- Filter pane (shown/hidden by default)
- Visual options (show/hide visual header, search in filter pane, etc.)

#### 12) Semantic Model Binding
- Connected semantic model name and workspace
- Live connection vs. import
- Any report-level measures (measures created in the report, not the model)
- Any report-level calculated columns or tables
- Field parameters (name, fields included, sort order)
- Measure groups or display folders used in the field list

#### 13) Known Issues & Design Decisions
- Any known visual rendering issues
- Performance concerns (e.g., visuals that are slow)
- Design trade-offs and rationale
- Accessibility considerations (alt text, tab order, high contrast)

#### 14) Rebuild Checklist
Ordered step-by-step instructions to recreate the report:
1. Connect to semantic model
2. Apply theme
3. Set report-level settings
4. Create pages in order
5. Build visuals per page (with field assignments)
6. Configure slicers and sync groups
7. Set up filters (report → page → visual levels)
8. Configure conditional formatting
9. Create bookmarks and navigation
10. Set up drill-through pages
11. Configure tooltip pages
12. Edit visual interactions
13. Create mobile layout
14. Test and validate

---

### B) Visual Catalog (Optional Companion)
Create: `[REPORT_FILE_PREFIX] Visual Catalog.md`

A flat reference table of every visual in the report:

| Page | Visual # | Type | Title | Primary Measure/Field | Filters | Conditional Formatting |
|------|----------|------|-------|-----------------------|---------|----------------------|

This provides a quick-reference lookup without navigating the full blueprint.

---

### C) Filter Map (Optional Companion)
Create: `[REPORT_FILE_PREFIX] Filter Map.md`

A comprehensive filter reference:

#### Report-Level Filters
| Field | Condition | Values | Notes |

#### Page-Level Filters
| Page | Field | Condition | Values | Notes |

#### Slicer Sync Groups
| Slicer Field | Slicer Type | Pages Synced | Default Value |

---

### D) Validation Steps (Mandatory)
Confirm and report:
- Output file(s) exist
- Every report page is documented
- Every visual on every page is cataloged
- Slicer inventory is complete
- Bookmark list is complete
- No placeholder sections left empty (mark as "None" or "Not applicable" explicitly)
- Cross-reference: all measures referenced in visuals exist in the semantic model documentation (if available)
- Report exact file paths touched

---

## Final Response Format
Provide:
- Files created
- Files updated
- Page count
- Visual count
- Slicer count
- Bookmark count
- Any assumptions or items that couldn't be determined
- Recommended next step (optional)

---

## Failure Handling
- If a page or visual cannot be fully inspected, document what is known and flag the gaps
- If PBIR files are not available, use the best available extraction method and note limitations
- Never silently skip a page or visual
- If the semantic model documentation doesn't exist yet, note this and recommend running the Semantic Model Documentation Master Prompt first

---

## Integration with Semantic Model Documentation

This prompt is designed as a **companion** to `Semantic Model Documentation Master Prompt.md`. Together they provide:

| Layer | Prompt | What It Documents |
|-------|--------|-------------------|
| Data | Semantic Model Documentation | Tables, columns, relationships, measures, DAX, data sources |
| Presentation | **Report Documentation (this prompt)** | Pages, visuals, slicers, filters, bookmarks, UX flow |
| Rebuild | Semantic Model Rebuild Blueprint | Full rebuild instructions for the dataset |

For complete disaster recovery, run all three prompts against the same model/report.

---

## Example Usage

```
Workspace:           TEST - Fabric Data
Report name:         Project Financials Report
Semantic model name: Project Financials
Output directory:    c:\Users\you\fabric-docs\Engineering
```

This produces:
- `Project Financials Report Blueprint.html`
- `Project Financials Visual Catalog.md` (optional)
- `Project Financials Filter Map.md` (optional)
