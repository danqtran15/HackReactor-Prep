## Section 1: Prerequisites & Setup

Before you begin reverse-engineering a Power BI semantic model, make sure your local development environment is configured with the right extensions, MCP servers, and access.

### 1.1 VS Code Extensions

Install the following VS Code extensions:

| Extension | Marketplace ID | Purpose |
|---|---|---|
| **Microsoft Fabric Data Engineering** | `synapsevscode.synapse` | Fabric notebook authoring, lakehouse browsing, and the built-in **Fabric Notebook MCP server** that exposes lakehouse/notebook APIs to Copilot CLI |
| **GitHub Copilot** | `github.copilot` | Inline code completions and the Copilot engine |
| **GitHub Copilot Chat** | `github.copilot-chat` | Chat-based agent interface — this is where you issue natural-language prompts that invoke MCP tools |

> **Tip:** You can verify installed extensions by running `code --list-extensions` in your terminal. All three IDs should appear in the output.

### 1.2 MCP Servers

**What are MCP servers?** MCP (Model Context Protocol) servers are lightweight tool servers that run alongside your editor and expose live API capabilities to Copilot CLI. When you ask Copilot a question like *"List the tables in my semantic model,"* Copilot translates that into a structured tool call against the appropriate MCP server, which in turn calls the Power BI or Fabric REST API using your authenticated session. This means you never leave VS Code — Copilot CLI acts as the orchestration layer between your prompt, the MCP server, and the cloud service.

Three MCP servers are used in this workflow:

| MCP Server | What It Does | Key Capabilities |
|---|---|---|
| **Power BI Modeling MCP** (`powerbi-modeling-mcp`) | Connects to Power BI Desktop or Fabric semantic models and exposes read/write modeling operations | Connect to models, list tables/columns/measures/relationships, export TMDL, execute DAX queries, inspect partitions (M source queries) |
| **Fabric MCP** (`fabric_mcp`) | Interfaces with the OneLake data plane and Fabric item management | List workspaces, list items (lakehouses/notebooks/reports), browse OneLake files and tables, upload/download files, create items |
| **Fabric Notebook MCP** (`fabric-notebook-mcp`) | Provides notebook, lakehouse, and environment operations in Fabric | List artifacts in workspaces, browse lakehouse tables/files with schema detail, preview table data, get connection code snippets, query code examples |

> **Configuration note:** MCP servers are configured in your VS Code settings (`settings.json`) or in a `.vscode/mcp.json` file at the root of your project. The Fabric Data Engineering extension auto-registers the Fabric Notebook MCP server. The Power BI Modeling MCP and Fabric MCP may require separate configuration — check your organization's setup guide or the extension documentation for connection strings and registration steps.

### 1.3 Copilot CLI

Copilot CLI is the terminal-integrated agent that lets you issue natural-language prompts and have them resolved through tool calls, file edits, and shell commands.

**Installation options:**

- **Via VS Code Marketplace:** Install the GitHub Copilot and GitHub Copilot Chat extensions (see §1.1). The chat agent is available immediately in the Copilot Chat panel.
- **Via npm (standalone CLI):** `npm install -g @githubnext/github-copilot-cli`
- **Running:** Open a terminal in VS Code and type `copilot`, or open the Copilot Chat panel (`Ctrl+Shift+I` / `Cmd+Shift+I`).

**Useful commands:**

| Command | Purpose |
|---|---|
| `/mcp` | List registered MCP servers and their status |
| `/env` | Verify which tools are loaded in the current session |
| `@workspace` | Scope a prompt to your local project files |

> **Verify your setup:** After installation, open Copilot Chat and type `/mcp`. You should see `powerbi-modeling-mcp`, `fabric_mcp`, and `fabric-notebook-mcp` listed as available servers. If any are missing, check `.vscode/mcp.json` or your global VS Code settings.

### 1.4 Project Folder Structure

Adopt a consistent folder layout so that generated SQL views, documentation, and validation scripts are easy to find and version-control:

```
project-root/
├── .vscode/
│   ├── settings.json          # MCP server config, skill locations
│   ├── mcp.json               # MCP server registrations (alternative to settings.json)
│   └── extensions.json        # Recommended extensions for collaborators
├── .github/
│   └── instructions/          # Copilot instruction files (.instructions.md)
├── Views/
│   ├── VW_FactOrders.sql      # View DDL scripts — one file per view
│   ├── VW_DimCustomer.sql
│   └── Validation/
│       ├── VW_FactOrders_Validation.sql   # Row-count and value-match tests
│       └── VW_DimCustomer_Validation.sql
├── Documentation/
│   ├── Silver_Views_Documentation.md      # Generated view-level docs
│   ├── Validation_Report.md               # Test results summary
│   └── Data_Lineage.md                    # Column-level lineage mapping
├── Scripts/
│   ├── deploy_views.py        # Automation scripts for bulk deployment
│   └── generate_docs.py       # Documentation generation helpers
└── README.md
```

**Naming conventions:**

- View files: `VW_<LogicalName>.sql` — use the same name as the target SQL view.
- Validation files: `VW_<LogicalName>_Validation.sql` — paired with each view.
- Keep one view per file for clean diffs and pull-request reviews.

### 1.5 Authentication

All three MCP servers authenticate using credentials that are already present in your VS Code session. No separate API keys or service principals are required for interactive use.

| Layer | How It Authenticates | What You Need |
|---|---|---|
| **Copilot CLI** | GitHub login linked to your VS Code session | An active GitHub Copilot subscription |
| **MCP servers → Fabric / Power BI** | Azure AD (Entra ID) token from the VS Code Fabric extension | Sign in via `F1 → Azure: Sign In` or the Fabric extension's account picker |

**Minimum permissions required:**

| Action | Minimum Role |
|---|---|
| Read semantic model metadata (tables, measures, M queries) | **Viewer** on the Power BI workspace |
| Execute DAX queries against the model | **Viewer** on the Power BI workspace |
| Browse Lakehouse tables and preview data | **Viewer** on the Fabric workspace |
| Deploy SQL views to a Lakehouse | **Contributor** (or higher) on the Fabric workspace |
| Create or modify Fabric items (notebooks, lakehouses) | **Contributor** (or higher) on the Fabric workspace |

> **Security note:** MCP servers operate under *your* identity. Every API call respects the same row-level security, workspace roles, and tenant policies that apply when you use the Fabric portal directly. You cannot access anything you wouldn't be able to see in the browser.

---

## Section 2: Phase 1 — Workspace Discovery

### 2.1 Why Start Here

Before you can reverse-engineer transformation logic, you need a clear picture of the assets involved. Skipping this step leads to common mistakes: working against the wrong semantic model version, missing shared dependencies, or building views against tables that don't exist in your target Lakehouse.

Specifically, you need to identify:

1. **Which workspace** contains the report you want to reverse-engineer.
2. **Which semantic model** (dataset) powers that report — this is where all the Power Query M transformations, DAX measures, and table relationships live.
3. **Whether other reports share the same semantic model** — changes you make (or views you build) may affect consumers of those related reports.
4. **Which Lakehouse** contains the raw source tables that the semantic model reads from — this is where your SQL views will eventually be deployed.

Think of this phase as building an inventory. Every artifact you identify here will be referenced by name and ID in subsequent phases.

### 2.2 Scanning for Reports and Semantic Models

Start by listing the artifacts in the workspace that contains your target report.

**Copilot prompt:**
```
List all reports and datasets in the 'My Workspace' workspace.
```

**What happens behind the scenes:**

Copilot calls the Fabric Notebook MCP server:

```
Tool:       fabric-notebook-mcp → list_artifacts
Parameters: workspace: "My Workspace"
            artifact_type: "Report"    (first call)
            artifact_type: "Dataset"   (second call)
```

**What to look for in the results:**

| Field | Why It Matters |
|---|---|
| `displayName` | Match this to your target report (e.g., `"Sales Analytics Report"`) |
| `id` | The artifact GUID — you'll reference this in later phases |
| `type` | Confirms whether the artifact is a `Report`, `Dataset`, `SemanticModel`, etc. |

**Identify related reports.** If multiple reports reference the same semantic model (dataset), they share the same transformation logic. Document them now — when you translate M queries into SQL views, the output will serve all of these reports, not just the one you started with.

**Example output (simplified):**

```
Reports:
  - Sales Analytics Report        (id: a1b2c3d4-...)
  - Executive Sales Dashboard     (id: e5f6a7b8-...)

Datasets (Semantic Models):
  - Sales Analytics               (id: 9c8d7e6f-...)
```

In this example, both reports might reference the `Sales Analytics` dataset. Confirm by checking report-to-dataset bindings in the Fabric portal or by inspecting the report metadata.

### 2.3 Finding the Lakehouse

Next, locate the Lakehouse that contains the raw tables your semantic model reads from. This is often in a different workspace (e.g., a shared "Data Platform" workspace).

**Copilot prompt:**
```
List all lakehouses in the 'Data Platform' workspace.
```

**Behind the scenes:**

```
Tool:       fabric-notebook-mcp → list_artifacts
Parameters: workspace: "Data Platform"
            artifact_type: "Lakehouse"
```

**Expected output:**

```
Lakehouses:
  - LH_Silver    (id: 1a2b3c4d-...)
  - LH_Bronze    (id: 5e6f7a8b-...)
  - LH_Gold      (id: 9c0d1e2f-...)
```

If you're not sure which workspace contains the Lakehouse, you can scan across workspaces:

**Copilot prompt:**
```
List all workspaces I have access to.
```

```
Tool:       fabric_mcp → onelake_list_workspaces
```

Then iterate through candidate workspaces to find the one with the relevant Lakehouse.

### 2.4 Browsing Lakehouse Tables

Once you've identified the source Lakehouse, inspect its contents to confirm the raw tables exist and understand their schemas.

**Copilot prompt:**
```
Show me all tables in the 'LH_Silver' lakehouse in the 'Data Platform' workspace.
```

**Behind the scenes:**

```
Tool:       fabric-notebook-mcp → list_fabric_artifact_contents
Parameters: artifact_type: "lakehouse"
            artifact: "LH_Silver"
            workspace: "Data Platform"
            search_type: "tables"
```

This returns a list of Delta tables with their column names and data types. For example:

```
Tables in LH_Silver:
  - fact_orders      (12 columns: order_id INT, customer_id INT, order_date DATE, ...)
  - dim_customer     (8 columns: customer_id INT, customer_name STRING, ...)
  - dim_product      (6 columns: product_id INT, product_name STRING, ...)
  - dim_date         (15 columns: date_key INT, full_date DATE, ...)
```

**Preview sample data** to verify the tables contain what you expect:

**Copilot prompt:**
```
Preview the first 5 rows of the 'fact_orders' table in 'LH_Silver'.
```

```
Tool:       fabric-notebook-mcp → preview_lakehouse_table
Parameters: workspace: "Data Platform"
            lakehouse_id: "1a2b3c4d-..."
            table_name: "fact_orders"
            row_count: 5
```

> **Tip:** Previewing a few rows helps you spot data quality issues early — NULL-heavy columns, unexpected date formats, or mismatched IDs that will matter when you write SQL views later.

### 2.5 Decision Checkpoint

Before moving to Phase 2, confirm that you have identified every asset you'll need. Use this checklist:

- [ ] **Target report identified** — name and artifact ID recorded
- [ ] **Semantic model identified** — name and artifact ID recorded (this is the model you'll connect to in Phase 2)
- [ ] **Related reports cataloged** — list of other reports sharing the same semantic model, with their names and IDs
- [ ] **Source Lakehouse identified** — name, artifact ID, and workspace name recorded
- [ ] **Source tables confirmed** — tables exist in the Lakehouse, schemas inspected, sample data previewed

> **Save this inventory.** Record the names and IDs in your project README or a `Discovery_Notes.md` file. You'll reference them repeatedly in subsequent phases, and they make it easy for teammates to pick up where you left off.

If any item is missing — for example, you can't find the Lakehouse, or the semantic model name doesn't appear in the workspace — resolve it before proceeding. Phase 2 requires a live connection to the semantic model, and Phase 3 requires knowing exactly which Lakehouse tables to target.

---

## Section 3: Phase 2 — Connect to the Semantic Model

### 3.1 Why Connect

Connecting to the semantic model is the single most important step in the reverse-engineering workflow. Once connected, Copilot CLI (via the Power BI Modeling MCP server) has read access to the *entire* model metadata graph:

- **Tables and columns** — including data types, sort-by columns, and hidden flags
- **Relationships** — cardinality, cross-filter direction, and active/inactive status
- **Measures** — DAX expressions, format strings, display folders, and descriptions
- **Partitions** — the Power Query M expressions or SQL source queries that define how each table is populated
- **Calculation groups** — if the model uses them
- **Roles** — row-level security filter expressions

This metadata is the raw material you'll translate into SQL views. Without a live connection, you'd have to manually export TMDL or PBIX files and parse them offline — the MCP connection eliminates that friction entirely.

### 3.2 Connecting via Power BI Modeling MCP

To establish a connection, tell Copilot the workspace and semantic model name.

**Copilot prompt:**
```
Connect to the 'Sales Analytics' semantic model in the 'My Workspace' workspace.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → connection_operations
Parameters: operation: "ConnectFabric"
            workspaceName: "My Workspace"
            semanticModelName: "Sales Analytics"
```

Copilot authenticates using your Azure AD (Entra ID) credentials (the same identity you signed into the Fabric extension with) and opens a read connection to the model's Analysis Services endpoint.

**On success,** the MCP server returns:
- A **connection name** (auto-generated, e.g., `"conn-1"` or `"My Workspace - Sales Analytics"`)
- The **data source URL** (e.g., `powerbi://api.powerbi.com/v1.0/myorg/My Workspace`)
- The **database name** (matches the semantic model name)

All subsequent modeling commands — listing tables, exporting measures, inspecting partitions — automatically use this connection. You don't need to pass the connection name explicitly unless you have multiple connections open.

### 3.3 Verifying the Connection

After connecting, verify that the connection is active and pointing to the correct model.

**Copilot prompt:**
```
Show me the current connection details.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → connection_operations
Parameters: operation: "GetConnection"
```

Or, to see all open connections:

```
Tool:       powerbi-modeling-mcp → connection_operations
Parameters: operation: "ListConnections"
```

**A successful connection shows:**

```
Connection Name:  My Workspace - Sales Analytics
Data Source:      powerbi://api.powerbi.com/v1.0/myorg/My Workspace
Database:         Sales Analytics
Status:           Connected
```

**Quick smoke test:** Run a simple DAX query to confirm the connection is live and returning data:

**Copilot prompt:**
```
Run this DAX query: EVALUATE ROW("Test", 1)
```

```
Tool:       powerbi-modeling-mcp → dax_query_operations
Parameters: operation: "Execute"
            query: "EVALUATE ROW(\"Test\", 1)"
```

If this returns a single row with value `1`, your connection is healthy and ready for extraction.

### 3.4 Troubleshooting

| Issue | Cause | Fix |
|---|---|---|
| `"Cannot find semantic model"` | The model name doesn't match exactly (names are **case-sensitive**) | Use `fabric-notebook-mcp → list_artifacts` with `artifact_type: "Dataset"` to get the exact display name, then retry |
| Authentication error / `401 Unauthorized` | Azure AD token has expired or you're not signed in | Re-authenticate: press `F1` → `Azure: Sign In`, then retry the connection |
| Connection timeout | The Fabric capacity hosting the model is **paused** or **suspended** | Go to the Fabric admin portal and resume the capacity, wait 1–2 minutes, then retry |
| `"Dataset not found"` after a previously working connection | The model was renamed, moved to a different workspace, or deleted | Re-run the workspace discovery steps from Section 2 to locate the current model |
| `"The remote name could not be resolved"` | Network or proxy issue blocking the `powerbi://` endpoint | Verify your network allows outbound connections to `*.powerbi.com` and `*.analysis.windows.net` |
| `"Could not load model"` | Model is very large and initial load takes time | Increase the timeout if your tooling allows, or retry after a brief wait |

> **Pro tip:** If you see a vague error, ask Copilot to run `connection_operations` with `operation: "ListLocalInstances"` — this shows any locally running Analysis Services instances (e.g., Power BI Desktop) and can help you rule out connection target confusion.

### 3.5 Connection Lifecycle

Understanding how connections behave will save you from unexpected errors mid-workflow:

- **Session-scoped.** Connections persist for the duration of your Copilot CLI session. If you close VS Code or restart the Copilot Chat panel, the connection is dropped and you'll need to reconnect.
- **Reconnection is fast.** Re-running the `ConnectFabric` command takes only a few seconds. There's no penalty for reconnecting.
- **Multiple connections.** You can open connections to multiple semantic models simultaneously. This is useful when comparing two versions of a model or cross-referencing measures across models. Each connection gets a unique name.
- **Last-used connection.** The MCP server remembers which connection was used most recently. Subsequent commands (e.g., listing tables, exporting measures) automatically target the last-used connection unless you specify a different one.
- **Switching connections.** To target a specific connection when multiples are open, you can pass the `connectionName` parameter explicitly, or use `connection_operations` with `operation: "SetLastUsed"` and `connectionName: "conn-2"` to change the default.

**Recommended practice:** If your workflow spans multiple sessions (e.g., you reverse-engineer tables one day and measures the next), add the connection command to the top of your working notes so you can re-establish the connection with a single prompt at the start of each session.

---

## Section 4: Phase 3 — Extract Metadata

This is the core extraction phase where you pull everything out of the semantic model. With the connection established in Phase 2, you now have read access to every table, column, relationship, measure, and partition definition. The goal is to systematically extract all of this metadata so you have the raw material to analyze in Phase 4 and translate into SQL views in Phase 5.

### 4.1 Overview of What to Extract

| Artifact | MCP Tool | Why You Need It |
|---|---|---|
| Table list | `table_operations → List` | Understand the model's structure — fact tables, dimensions, calculated tables |
| Relationships | `relationship_operations → List` | Map joins between tables — cardinality, cross-filter direction, active/inactive |
| Measures | `measure_operations → List` | Catalog all DAX calculations — these encode business rules |
| Measure expressions | `measure_operations → Get` | Get the actual DAX code for each measure |
| TMDL export | `table_operations → ExportTMDL` | Get the full TMDL definition including columns, partitions, format strings |
| Partition source queries | `partition_operations → List` | **Critical** — these contain the M (Power Query) or SQL that defines how each table is populated |
| Column details | `column_operations → List` | Data types, format strings, sort-by-column, descriptions |

Extract these in the order listed. Tables first (to know what you're working with), then relationships (to understand how tables connect), then measures (to catalog business logic), then partitions (to get the actual source queries), and finally column details (to fill in data types and formatting).

### 4.2 Listing Tables

**Copilot prompt:**
```
List all tables in this semantic model.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → table_operations
Parameters: operation: "List"
```

**Interpreting the results:**

The response returns every table in the model, but not all of them are reverse-engineering targets. Filter the results:

- **Ignore auto-generated date tables.** Power BI creates `LocalDateTable_<GUID>` and `DateTableTemplate_<GUID>` tables automatically for any column marked as a date. These are internal to the engine and are not part of the author's design — skip them entirely.
- **Identify sourced tables.** These have M (Power Query) or SQL source expressions in their partitions. They read from a database, Lakehouse, or file. These are your primary reverse-engineering targets.
- **Identify calculated tables.** These are defined by a DAX expression (e.g., `CALENDAR(...)`, `DATATABLE(...)`, or `SUMMARIZE(...)`). They don't have M queries — instead, they're computed from other tables in the model. You may or may not need SQL equivalents for these.
- **Categorize by role.** As you review the table list, mentally (or in notes) categorize each table:
  - **Fact tables** — event-grain tables (e.g., `fact_orders`, `fact_shipments`)
  - **Dimension tables** — descriptive lookup tables (e.g., `dim_customer`, `dim_product`)
  - **Bridge/junction tables** — many-to-many resolvers
  - **Reference/utility tables** — parameter tables, status mappings, configuration data

**Example output (simplified):**

```
Tables:
  - fact_orders              (sourced — M query)
  - dim_customer             (sourced — M query)
  - dim_product              (sourced — M query)
  - dim_date                 (calculated — DAX CALENDAR expression)
  - bridge_order_product     (sourced — M query)
  - _Measures                (calculated — empty DAX table, used as a measure container)
  - LocalDateTable_abc123    (auto-generated — SKIP)
  - DateTableTemplate_xyz789 (auto-generated — SKIP)
```

In this example, the five sourced tables and the calculated `dim_date` are your targets. The `_Measures` table is just a container for measures (a common modeling pattern) — no SQL view needed.

### 4.3 Listing Relationships

**Copilot prompt:**
```
List all relationships in the model.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → relationship_operations
Parameters: operation: "List"
```

**What to capture for each relationship:**

| Field | What It Tells You |
|---|---|
| `fromTable` / `fromColumn` | The "many" side of the relationship (typically the fact table's foreign key) |
| `toTable` / `toColumn` | The "one" side (typically the dimension table's primary key) |
| Cardinality | `Many-to-One` (most common), `One-to-One`, or `Many-to-Many` |
| Cross-filter direction | `Single` (filters flow from "one" to "many" only) or `Both` (bidirectional — less common, used for specific DAX patterns) |
| `isActive` | If `false`, this is an **inactive relationship** — it's only used when a DAX measure explicitly invokes `USERELATIONSHIP()`. Still document it; the business logic it supports matters. |

**Example output (simplified):**

```
Relationships:
  1. fact_orders[customer_id]  →  dim_customer[customer_id]
     Cardinality: Many-to-One | Cross-filter: Single | Active: true

  2. fact_orders[product_id]   →  dim_product[product_id]
     Cardinality: Many-to-One | Cross-filter: Single | Active: true

  3. fact_orders[order_date]   →  dim_date[date_key]
     Cardinality: Many-to-One | Cross-filter: Single | Active: true

  4. fact_orders[ship_date]    →  dim_date[date_key]
     Cardinality: Many-to-One | Cross-filter: Single | Active: false
```

**Why this matters for SQL views:** Relationships define the join paths. Relationship #1 tells you that your SQL view will include `LEFT JOIN dim_customer ON fact_orders.customer_id = dim_customer.customer_id`. Relationship #4 (inactive) tells you that some DAX measures join `fact_orders` to `dim_date` on `ship_date` instead of `order_date` — you may need a second date join in your view or a separate view for ship-date analysis.

> **Document these in a table or diagram.** Relationships are the skeleton of the data model. Having them clearly documented makes Phase 5 (writing SQL views) dramatically faster.

### 4.4 Extracting Measures

**Copilot prompt (list all):**
```
List all measures in the model.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → measure_operations
Parameters: operation: "List"
```

This returns measure names, the tables they're assigned to, their display folders, and basic metadata. To get the actual DAX expression for a specific measure:

**Copilot prompt (get expression):**
```
Get the DAX expression for the 'Total Revenue' measure.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → measure_operations
Parameters: operation: "Get"
            references: [{ "name": "Total Revenue" }]
```

**What to look for in measure expressions:**

- **`CALCULATE` with filters** — These encode business rules. For example, `CALCULATE(COUNT(Orders[ID]), Orders[Status] = "Active")` tells you that "Active Orders" only counts records where Status equals Active. You may need a SQL `WHERE` clause or a `CASE WHEN` column to support this.
- **`DISTINCTCOUNT` vs. `COUNT`** — `DISTINCTCOUNT` tells you the measure cares about unique values, which hints at grain expectations. If the source has duplicate rows per entity, you may need deduplication in your SQL view.
- **`DIVIDE`** — Safe division (returns BLANK instead of error on divide-by-zero). The SQL equivalent is `CASE WHEN denominator = 0 THEN NULL ELSE numerator / denominator END` or `NULLIF`.
- **`SWITCH` / `IF`** — Conditional logic that may need SQL `CASE` statements if you decide to pre-compute the result in a view column.
- **`RELATED` / `RELATEDTABLE`** — These traverse relationships. They tell you which tables are joined and how the measure crosses from one table to another. This informs your SQL JOIN structure.
- **`USERELATIONSHIP`** — Activates an inactive relationship for a specific calculation. Cross-reference this with the relationship list from §4.3 to understand the alternate join path.
- **Time intelligence functions** (`SAMEPERIODLASTYEAR`, `DATESYTD`, etc.) — These are typically left in DAX and not replicated in SQL. Note them but don't plan to translate them.

> **Pro tip:** For models with many measures, ask Copilot to export them in bulk: *"List all measures with their DAX expressions."* This saves repeated individual `Get` calls.

### 4.5 Exporting TMDL

**Copilot prompt:**
```
Export the TMDL for the 'fact_orders' table.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → table_operations
Parameters: operation: "ExportTMDL"
            references: [{ "name": "fact_orders" }]
```

**What TMDL gives you:**

TMDL (Tabular Model Definition Language) is a YAML-like serialization format that captures the complete definition of a table in a single, readable document:

- **Column definitions** — name, data type (`Int64`, `String`, `DateTime`, `Double`, etc.), format string, `isHidden`, `sortByColumn`, `summarizeBy`, description, and lineage tags.
- **Partition definitions** — including the full M expression or SQL query that populates the table.
- **Annotations** — model-author notes, Power BI internal metadata, and extended properties.
- **Relationships involving this table** — referenced by name (cross-reference with §4.3).

**When to use TMDL vs. individual tool calls:**

- Use `ExportTMDL` when you want the **full picture** of a single table — all columns, partitions, and metadata in one output. This is ideal for complex tables with many columns or multiple partitions.
- Use individual tool calls (`column_operations → List`, `partition_operations → List`) when you want to **compare across tables** or work with metadata programmatically.

**Example TMDL snippet (simplified):**

```yaml
table fact_orders
  lineageTag: a1b2c3d4-...

  column order_id
    dataType: int64
    isKey: true
    sourceColumn: order_id
    summarizeBy: none

  column customer_id
    dataType: int64
    sourceColumn: customer_id
    summarizeBy: none

  column revenue
    dataType: double
    formatString: $#,##0.00
    sourceColumn: revenue
    summarizeBy: sum

  partition fact_orders
    mode: import
    source
      type: m
      expression
        let
          Source = Sql.Database("server", "db"),
          dbo_orders = Source{[Schema="dbo", Item="orders"]}[Data]
        in
          dbo_orders
```

### 4.6 Extracting Partition Source Queries (Most Critical Step)

**Copilot prompt:**
```
List all partitions in the model, I need to see the source M queries.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → partition_operations
Parameters: operation: "List"
```

**This is the single most important extraction step.** Partitions contain the source expressions — either Power Query M code or native SQL — that define how each table's data is loaded. These expressions *are* the transformation logic you're reverse-engineering. Everything else (tables, columns, relationships) is structure; partitions are the *behavior*.

Each table typically has one partition, but some models use multiple partitions (e.g., one per year for incremental refresh). For reverse-engineering purposes, you need the M expression from every partition.

#### Reading an M Expression

A typical M expression from a partition:

```m
let
    Source = Sql.Database("server.database.windows.net", "mydb"),
    dbo_orders = Source{[Schema="dbo", Item="orders"]}[Data],
    #"Filtered Rows" = Table.SelectRows(dbo_orders, each [status] <> "DELETED"),
    #"Renamed Columns" = Table.RenameColumns(#"Filtered Rows", {
        {"order_id", "Order ID"},
        {"cust_id", "Customer ID"}
    }),
    #"Added Custom" = Table.AddColumn(#"Renamed Columns", "Order Key",
        each [order_id] & "_" & [order_type])
in
    #"Added Custom"
```

From this single expression you can extract four critical pieces of information:

1. **Source table**: `dbo.orders` — this is the raw table your SQL view will read from.
2. **Filters**: `status <> 'DELETED'` — this becomes a `WHERE` clause in your SQL view.
3. **Column renames**: `order_id` → `Order ID`, `cust_id` → `Customer ID` — these become column aliases in your `SELECT` list.
4. **Computed columns**: `Order Key` = `order_id + '_' + order_type` — this becomes a `CONCAT()` expression in your SQL view.

#### Reading a Native SQL Source

Some partitions bypass M transformations and embed raw SQL directly using `Value.NativeQuery`:

```m
let
    Source = Sql.Database("server", "db"),
    result = Value.NativeQuery(Source,
        "SELECT o.order_id, o.customer_id, o.revenue, o.order_date
         FROM dbo.orders o
         WHERE o.status <> 'DELETED'
           AND o.order_date >= '2020-01-01'",
        null, [EnableFolding=true])
in
    result
```

Here the actual SQL is embedded in the M expression. This is the easiest case — you can lift the SQL almost directly and adapt it into your view definition. Check for:
- Hard-coded date filters that may need to be parameterized or removed
- Server/database references that may differ between environments
- The `EnableFolding=true` option (indicates the author intended the query to push down to the source)

#### Calculated Table Partitions

For calculated tables (identified in §4.2), the partition contains a DAX expression instead of M:

```dax
CALENDAR(DATE(2020, 1, 1), DATE(2030, 12, 31))
```

These don't have a SQL source to reverse-engineer. Decide whether to:
- Recreate the logic as a SQL view (e.g., a date dimension generator)
- Use an existing date dimension table in your Lakehouse
- Skip the table if it's only needed for DAX time intelligence

### 4.7 Extracting Column Details

**Copilot prompt:**
```
List all columns for the 'fact_orders' table.
```

**Behind the scenes:**

```
Tool:       powerbi-modeling-mcp → column_operations
Parameters: operation: "List"
            filter: { "tableNames": ["fact_orders"] }
```

**What to capture:**

| Column Property | Why It Matters |
|---|---|
| `name` | The column name as it appears in the semantic model (may differ from the source column) |
| `dataType` | `Int64`, `String`, `DateTime`, `Double`, `Boolean`, `Decimal` — maps to SQL data types |
| `sourceColumn` | The original column name from the source — use this in your SQL `SELECT` |
| `isHidden` | Hidden columns are used internally (e.g., for relationships) but not shown to report users |
| `sortByColumn` | If set, indicates a display-order dependency (e.g., month name sorted by month number) |
| `formatString` | Formatting like `$#,##0.00` or `yyyy-MM-dd` — informational, but useful for documentation |
| `description` | Author-provided documentation — capture this for your view documentation |
| `expression` | If present, this is a **calculated column** (DAX). It doesn't come from the source — you may need to replicate the logic in SQL. |

> **Calculated columns** (those with an `expression` property) are computed by the DAX engine after data load. If the calculation is simple (e.g., string concatenation, date math), consider adding it to your SQL view. If it depends on relationships or other DAX concepts, leave it for the semantic model layer.

### 4.8 Extraction Checklist

Before moving to Phase 4 (analysis), verify that you've captured everything:

- [ ] All non-date tables listed and categorized (fact, dimension, calculated, bridge, utility)
- [ ] All relationships documented (from/to columns, cardinality, cross-filter direction, active/inactive)
- [ ] All measures cataloged with full DAX expressions
- [ ] Partition M/SQL expressions extracted for every target table
- [ ] Column details captured (data types, source columns, calculated column expressions)
- [ ] TMDL exported for tables with complex column definitions or multiple partitions
- [ ] Auto-generated date tables identified and excluded from the target list

> **Save your extraction artifacts.** Whether you're working in Copilot Chat history, markdown files, or a structured notes document, save the raw output from each extraction step. You'll reference it repeatedly during analysis and SQL translation.

---

## Section 5: Phase 4 — Analyze Transformation Logic

### 5.1 Goal

Transform the extracted metadata into a clear understanding of what each table does, so you can write equivalent SQL views. This is detective work — you're piecing together the business logic from M expressions, DAX measures, and relationship patterns.

By the end of this phase, you should be able to describe, for each target table:
1. Which source table(s) it reads from
2. What filters are applied
3. What columns are renamed, added, or removed
4. What joins or merges are performed
5. Whether deduplication or aggregation occurs
6. What computed columns exist and how they're calculated

### 5.2 Deconstructing Power Query M Expressions

M expressions are read top-to-bottom. Each step creates a new intermediate table by transforming the previous step's output. Here's a systematic approach:

#### Step-by-step approach:

1. **Find the source table** — Look for `Sql.Database(...)`, `Sql.Databases(...)`, or Lakehouse table references. The first one or two steps in the M expression typically establish the connection and select the source table. This tells you which raw table your SQL view will query.

2. **Trace the filter chain** — `Table.SelectRows` calls are `WHERE` clauses. Multiple chained `Table.SelectRows` steps become `AND` conditions. Pay attention to the filter function: `each [col] = "X"` becomes `WHERE col = 'X'`; `each [col] <> null` becomes `WHERE col IS NOT NULL`.

3. **Map column renames** — `Table.RenameColumns` tells you the mapping from source column name to the friendly name used in the semantic model. In your SQL view, this becomes `source_column AS [Friendly Name]`. Track these carefully — the semantic model's column names are what report authors see, and your SQL view should match them.

4. **Identify computed columns** — `Table.AddColumn` with an `each` expression creates a new column from existing data. The `each` expression is a row-level function — translate it to a SQL column expression. Simple cases (concatenation, arithmetic, date math) translate directly. Complex cases (nested `if`/`then`/`else`, `try`/`otherwise`) require more thought.

5. **Find joins/merges** — `Table.NestedJoin` or `Table.Join` are SQL JOINs. Note the join type: `JoinKind.LeftOuter` → `LEFT JOIN`, `JoinKind.Inner` → `INNER JOIN`, `JoinKind.FullOuter` → `FULL OUTER JOIN`. The merged column is typically expanded in a subsequent `Table.ExpandTableColumn` step.

6. **Spot aggregations** — `Table.Group` is `GROUP BY`. Note the grouping columns and the aggregation functions (`Table.RowCount` → `COUNT(*)`, `List.Sum` → `SUM()`, `List.Average` → `AVG()`, `List.Max` → `MAX()`).

7. **Check for deduplication** — `Table.Distinct` removes duplicate rows. If applied to a subset of columns, it's equivalent to `SELECT DISTINCT`. Some models use a sort-then-keep-first pattern (`Table.Sort` followed by `Table.FirstN(_, 1)` per group) — this maps to `ROW_NUMBER() OVER (PARTITION BY ... ORDER BY ...) = 1`.

#### Common M → SQL Pattern Map

| M Function | SQL Equivalent |
|---|---|
| `Table.SelectRows(t, each [col] = "X")` | `WHERE col = 'X'` |
| `Table.SelectRows(t, each [col] <> null)` | `WHERE col IS NOT NULL` |
| `Table.RenameColumns(t, {{"old", "new"}})` | `SELECT old AS [new]` |
| `Table.AddColumn(t, "New", each [A] & "_" & [B])` | `SELECT CONCAT(A, '_', B) AS [New]` |
| `Table.AddColumn(t, "Flag", each if [X] > 0 then "Yes" else "No")` | `CASE WHEN X > 0 THEN 'Yes' ELSE 'No' END AS [Flag]` |
| `Table.NestedJoin(t1, "key", t2, "key", "merged", JoinKind.LeftOuter)` | `LEFT JOIN t2 ON t1.key = t2.key` |
| `Table.NestedJoin(t1, "key", t2, "key", "merged", JoinKind.Inner)` | `INNER JOIN t2 ON t1.key = t2.key` |
| `Table.ExpandTableColumn(t, "merged", {"col1", "col2"})` | Columns from the JOINed table (already available in SQL after the JOIN) |
| `Table.Group(t, {"grpCol"}, {{"cnt", each Table.RowCount(_)}})` | `SELECT grpCol, COUNT(*) AS cnt GROUP BY grpCol` |
| `Table.Group(t, {"grpCol"}, {{"total", each List.Sum(_[amount])}})` | `SELECT grpCol, SUM(amount) AS total GROUP BY grpCol` |
| `Table.Distinct(t, {"col"})` | `SELECT DISTINCT` or `ROW_NUMBER() OVER (PARTITION BY col ...)` |
| `Table.Sort(t, {{"col", Order.Descending}})` | `ORDER BY col DESC` |
| `Table.TransformColumns(t, {{"col", Text.Upper}})` | `UPPER(col)` |
| `Table.TransformColumns(t, {{"col", Text.Trim}})` | `LTRIM(RTRIM(col))` or `TRIM(col)` |
| `Table.ReplaceValue(t, "old", "new", Replacer.ReplaceText, {"col"})` | `REPLACE(col, 'old', 'new')` or `CASE WHEN col = 'old' THEN 'new' ELSE col END` |
| `Table.RemoveColumns(t, {"col1", "col2"})` | Simply omit those columns from your `SELECT` list |
| `Table.SelectColumns(t, {"col1", "col2"})` | `SELECT col1, col2` (only these columns) |
| `Table.Pivot(t, ...)` / `Table.Unpivot(t, ...)` | `PIVOT` / `UNPIVOT` or conditional `CASE` aggregation |
| `Table.TransformColumnTypes(t, {{"col", Int64.Type}})` | `CAST(col AS BIGINT)` |

### 5.3 Analyzing DAX Measures

Not all DAX measures need to be replicated in SQL views. Most measures are *aggregation-time* calculations that only make sense in a report context (e.g., "Total Revenue by Region filtered by Year"). Your SQL views provide the *row-level data*; the semantic model handles aggregation.

**Categorize each measure:**

| Category | Action | Example |
|---|---|---|
| **Simple aggregation** | Usually NOT replicated in SQL — let the semantic model handle it | `Total Revenue := SUM(fact_orders[Revenue])` |
| **Filtered aggregation** | May need a SQL column to support the filter | `Active Orders := CALCULATE(COUNT(fact_orders[ID]), fact_orders[Status] = "Active")` |
| **Calculated status/flag** | Consider adding as a SQL computed column | `Is Late := IF(fact_orders[Ship Date] > fact_orders[Due Date], "Yes", "No")` |
| **Cross-table calculation** | Understand the relationship traversal — informs your JOIN design | `Customer Orders := COUNTROWS(RELATEDTABLE(fact_orders))` |
| **Time intelligence** | Leave in DAX — these depend on the date table and filter context | `Revenue YTD := TOTALYTD(SUM(fact_orders[Revenue]), dim_date[Date])` |
| **Format-only** | Ignore — these just control display formatting | `Revenue Display := FORMAT([Total Revenue], "$#,##0")` |

**Key decision rule:** If a measure's filter logic (the second argument to `CALCULATE`) references a column that doesn't exist in your SQL view, you either need to:
1. Add that column to the view, or
2. Add a pre-computed flag/status column that encapsulates the filter condition

For example, if a measure filters by `Orders[Priority] = "High"` and the `Priority` column isn't in your source table, check the M expression — it might be a computed column. If so, replicate that computation in your SQL view.

### 5.4 Identifying Deduplication Patterns

A very common pattern in semantic models: the source table has multiple rows per entity, but the model keeps only one (usually the latest). This is critical to identify because it changes the grain of your SQL view.

**Signs of deduplication in M:**
- `Table.Distinct(t)` — removes exact duplicate rows
- `Table.Distinct(t, {"entity_id"})` — keeps one row per entity (non-deterministic which row is kept)
- A `Table.Sort` step followed by a `Table.Group` with `Table.FirstN(_, 1)` or `List.First` — keeps the first row per group after sorting (deterministic)
- A `Table.Group` step that aggregates to a single row per group

**SQL equivalents:**

```sql
-- Pattern 1: Simple deduplication (remove exact duplicates)
SELECT DISTINCT * FROM source_table

-- Pattern 2: Keep latest record per entity (most common)
SELECT *
FROM (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY entity_id
            ORDER BY modified_date DESC
        ) AS rn
    FROM source_table
) ranked
WHERE rn = 1

-- Pattern 3: Keep record with max ID per parent
SELECT s.*
FROM source_table s
INNER JOIN (
    SELECT parent_id, MAX(record_id) AS max_id
    FROM source_table
    GROUP BY parent_id
) latest ON s.record_id = latest.max_id
```

> **Watch for implicit deduplication.** Sometimes the M expression doesn't explicitly deduplicate, but the source table has a unique constraint that the model author relied on. Check the column properties — if a column has `isKey: true`, the model expects unique values in that column. If your source data has duplicates, your view needs deduplication logic.

### 5.5 Recognizing Composite Key Patterns

Many semantic models create composite keys by concatenating columns:

**In M:**
```m
Table.AddColumn(t, "Key", each Text.From([id]) & "_" & [type])
```

**In SQL:**
```sql
SELECT CONCAT(CAST(id AS VARCHAR), '_', type) AS [Key]
```

These composite keys serve two purposes:

1. **Primary keys** for the table — the relationship's "one" side joins on this composite key. Without it, the relationship would need a multi-column join, which Power BI doesn't support natively.
2. **Foreign keys** in related tables — another table creates the same composite key pattern so it can join to this one.

**How to document them:**

For each composite key, record:
- The composite key column name (e.g., `Order Key`)
- The component columns (e.g., `order_id` + `order_type`)
- The separator character (e.g., `_`)
- Which relationships use this key (cross-reference with §4.3)
- Whether the same concatenation pattern appears in other tables (it must, for the join to work)

When you write your SQL views, you must ensure both sides of a composite-key relationship produce the key with the same logic — same column order, same separator, same data type handling (especially `NULL` values and type casting).

### 5.6 Handling String Transformations

String transformations are among the most common M operations. They often serve data-cleansing purposes — normalizing messy source data before it enters the semantic model.

**Common patterns:**

| Pattern | M Code | SQL Equivalent |
|---|---|---|
| Trim whitespace | `Text.Trim([col])` | `TRIM(col)` or `LTRIM(RTRIM(col))` |
| Uppercase for comparison | `Text.Upper(Text.Trim([col]))` | `UPPER(TRIM(col))` |
| Replace specific values | `Table.ReplaceValue(t, "old", "new", Replacer.ReplaceText, {"col"})` | `REPLACE(col, 'old', 'new')` |
| Replace null with default | `if [col] = null then "Unknown" else [col]` | `ISNULL(col, 'Unknown')` or `COALESCE(col, 'Unknown')` |
| Extract substring | `Text.Start([col], 3)` | `LEFT(col, 3)` |
| Concatenate with separator | `[A] & " - " & [B]` | `CONCAT(A, ' - ', B)` |

**HTML content:** Some source fields contain HTML markup (e.g., rich-text descriptions from ticketing systems or CMS platforms). The M expression might strip tags, or it might pass them through. Decide whether to:
- **Strip HTML in SQL** — complex and error-prone. Requires recursive `REPLACE` or a CLR function. Generally not recommended unless you have a well-tested utility function.
- **Preserve raw HTML** — pass it through and let the report layer or a downstream application handle rendering. This is usually the safer choice.
- **Extract plain text in M** — if the original M expression strips HTML, you'll need to replicate that logic. Consider using a SQL scalar function if the pattern is complex.

### 5.7 Understanding Reference Tables

In Power Query, a "Reference" step creates a new query that starts from the output of another query *without re-fetching data from the source*. This is the M equivalent of a SQL view built on top of another view.

**How to recognize it:**

If Table B's M expression starts with `= TableA` (a direct reference to another query name) rather than `Sql.Database(...)`, it's a reference table. It takes the output of Table A and applies additional transformations — joins, filters, computed columns, etc.

**What this means for your SQL views:**

Reference tables create a **build-order dependency**. You must create views in the right sequence:
- **View A** (base): Reads from the raw source table
- **View B** (reference): `SELECT * FROM View_A LEFT JOIN ...` — builds on View A's output

If you try to create View B before View A exists, the SQL will fail.

**Mapping the dependency chain:**

```
TableA  → reads from dbo.orders
TableB  → references TableA, adds JOIN to dbo.customers
TableC  → references TableB, adds computed columns
```

This maps to:
```
VW_TableA  → SELECT ... FROM dbo.orders
VW_TableB  → SELECT ... FROM VW_TableA LEFT JOIN dbo.customers ...
VW_TableC  → SELECT ... FROM VW_TableB
```

Document the dependency chain for all reference tables. In Phase 5, you'll create views in dependency order — base tables first, then derived tables.

> **Performance consideration:** Deep reference chains (A → B → C → D) can create deeply nested view stacks in SQL. If you're concerned about query performance, consider flattening the chain: instead of View C reading from View B which reads from View A, have View C read directly from the source tables and replicate all the logic in a single query.

### 5.8 Analysis Checklist

Before moving to Phase 5 (writing SQL views), verify that your analysis is complete:

- [ ] Each target table's M expression fully deconstructed (source, filters, renames, joins, computed columns)
- [ ] Source tables identified for every target (you know exactly which `dbo.tablename` or Lakehouse table to query)
- [ ] All column renames documented (source column → semantic model column name)
- [ ] Computed columns translated to SQL expressions (or flagged as too complex for SQL)
- [ ] DAX measures categorized (replicate in SQL vs. leave in semantic model)
- [ ] Deduplication logic identified and SQL equivalent planned
- [ ] Composite key patterns documented (component columns, separator, both sides of relationship)
- [ ] String transformations cataloged with SQL equivalents
- [ ] Reference table dependencies mapped and build order determined
- [ ] Join paths confirmed (relationship metadata matches M expression join logic)

## Section 6: Phase 5 — Map Source Tables

### 6.1 Goal

Confirm that every source table referenced by the semantic model's M queries actually exists in your Fabric Lakehouse, and that the column names match. This phase bridges the gap between the transformation logic you documented in Phase 4 and the real-world schema in your Lakehouse — without it, you'll write views that fail on the first column reference.

### 6.2 Listing Lakehouse Tables and Columns

Start by browsing the contents of the target Lakehouse to see what tables are available and what columns they contain.

**Copilot prompt:**
```
Show me all tables in the 'LH_Silver' lakehouse in the 'Data Platform' workspace.
```

**Behind the scenes**, Copilot invokes:

```
fabric-notebook-mcp → list_fabric_artifact_contents
  artifact_type: "lakehouse"
  artifact:      "LH_Silver"
  workspace:     "Data Platform"
  search_type:   "tables"
```

This returns a list of table names along with their column names and data types — enough for a quick side-by-side comparison with the M query's source references.

**Alternative approaches:**

For schema-level browsing when you need to see tables organized by schema (e.g., `dbo`, `staging`, `analytics`):

```
fabric_mcp → onelake_list_tables
  namespace: "dbo"
  item:      "LH_Silver.Lakehouse"
  workspace: "Data Platform"
```

To preview sample data and verify that column values look correct:

```
fabric-notebook-mcp → preview_lakehouse_table
  workspace:    "Data Platform"
  lakehouse_id: "<lakehouse-guid>"
  table_name:   "orders"
  row_count:    5
```

> **Tip:** Previewing even 5 rows is valuable — it confirms that the table is populated, that column data types are as expected, and that you're looking at the right table (not a stale copy).

### 6.3 Schema Inspection via SQL

When MCP metadata isn't detailed enough — for example, you need character length limits, nullability, or exact data types — query the SQL Analytics Endpoint directly. Open the Fabric SQL editor for your Lakehouse and run:

```sql
-- List all tables in a schema
SELECT TABLE_SCHEMA, TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'dbo'
ORDER BY TABLE_NAME;
```

```sql
-- Get column details for a specific table
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'orders'
ORDER BY ORDINAL_POSITION;
```

These queries give you the ground truth that MCP metadata summarizes. Use them when:
- A column's data type matters (e.g., `INT` vs. `BIGINT` for key columns)
- You need to confirm `VARCHAR` lengths before defining composite keys
- You suspect a table exists under a different schema than expected

### 6.4 Handling Column Name Mismatches

This is a **very common gotcha**. The semantic model's M query may reference column names that don't match the Lakehouse table. This happens because:

- **The original source was a different database** (e.g., on-prem SQL Server) with different naming conventions
- **Columns were renamed during migration** to Fabric — a DBA may have shortened or standardized names
- **The Lakehouse mirrors a different schema version** — column names evolved but the semantic model wasn't updated

**How to resolve:**

1. Extract the M query's source column references from your Phase 4 analysis
2. List the actual Lakehouse table columns via `INFORMATION_SCHEMA.COLUMNS`
3. Create a mapping table documenting every mismatch:

| M Query Column | Lakehouse Column | Notes |
|---|---|---|
| `priority` | `causepriority` | Renamed in source system |
| `plusgimprreqd` | `impreqd` | Legacy prefix stripped during migration |
| `order_date` | `orderdate` | Underscore removed to match naming standard |
| `cust_name` | `customer_name` | Expanded abbreviation |
| `amt` | `total_amount` | Column renamed for clarity |

4. In your SQL view, always reference the **Lakehouse column name** (the one that actually exists) and use `AS [Friendly Name]` to apply the semantic model's display name:

```sql
-- Use the REAL column name, alias to the FRIENDLY name
SELECT
    t.causepriority    AS [Priority],
    t.impreqd          AS [Improvement Required],
    t.orderdate        AS [Order Date]
FROM [dbo].[orders] t;
```

> **Key principle:** The Lakehouse column name goes in the `FROM`/`JOIN`/`WHERE` clauses. The semantic model's friendly name goes in the `AS` alias. Never the other way around.

### 6.5 Cross-Referencing Semantic Models

Sometimes multiple semantic models in the same workspace reference the same source tables. This is worth checking because:

- **Reuse existing views:** If Model A has already been reverse-engineered into SQL views, Model B can reference those views instead of rebuilding from scratch
- **Avoid duplicate logic:** Shared source tables should have a single, canonical view definition
- **Spot inconsistencies:** If two models interpret the same source column differently, you need to decide which interpretation is correct

**Copilot prompt:**
```
List all semantic models in the 'Data Platform' workspace, then show me the
partition source queries for each.
```

**Behind the scenes**, Copilot chains:

1. `fabric-notebook-mcp → list_artifacts` with `artifact_type: "Dataset"` to enumerate semantic models
2. `powerbi-modeling-mcp → partition_operations` with `operation: "List"` for each model to retrieve partition M queries

Review the results for shared table references. If you find that `fact_orders` is referenced by three models, build the `VW_Orders` view once and let all three models consume it.

### 6.6 Mapping Checklist

Before proceeding to Phase 6 (SQL view design), verify:

- [ ] Every source table referenced in M queries exists in the Lakehouse
- [ ] Column names verified — all mismatches documented in a mapping table
- [ ] Data types confirmed for key columns (especially columns used in joins or composite keys)
- [ ] Sample data reviewed for at least one key table per subject area
- [ ] Cross-references to other semantic models documented (shared sources identified)
- [ ] Missing tables or columns flagged for investigation with the data engineering team

## Section 7: Phase 6 — Design SQL Views

### 7.1 Goal

Translate the transformation logic (from Phase 4) and source table mappings (from Phase 5) into well-structured SQL views that can replace the semantic model's Power Query M logic. Each view should be a self-contained, readable SQL definition that a data engineer can deploy to a Fabric Lakehouse SQL endpoint and a report author can query without needing to understand the underlying source tables.

### 7.2 Naming Conventions

Establish consistent naming before you start writing views. Inconsistent naming creates confusion once you have dozens of views in a schema.

| Element | Convention | Example |
|---|---|---|
| **View name** | `VW_` prefix + descriptive PascalCase name | `VW_Orders`, `VW_Customer_Summary` |
| **File name** | View name + `_Fabric.sql` suffix | `VW_Orders_Fabric.sql` |
| **Schema** | Match the source schema | `dbo`, `sales`, `analytics` |
| **Column names** | `[Friendly Names]` in square brackets | `[Order ID]`, `[Customer Name]` |
| **Audit columns** | Standard set, always last | `[Fabric Loaded Date]`, `[Fabric Loaded By]` |

> **Why `_Fabric.sql`?** The suffix distinguishes these view definitions from other SQL artifacts (stored procedures, migration scripts, ad-hoc queries). It also signals that the view is designed for the Fabric SQL endpoint's specific syntax and limitations.

### 7.3 View Template

Use this template as the starting point for every view. Not every view will need every section — remove what doesn't apply.

```sql
CREATE OR ALTER VIEW [schema].[VW_ViewName] AS

-- ── CTEs ────────────────────────────────────────────────────────
-- Optional CTEs for deduplication, ranking, or pre-aggregation.
-- Name each CTE descriptively (not "cte1", "cte2").

WITH deduped AS (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY parent_id
            ORDER BY record_id DESC
        ) AS rn
    FROM [schema].[source_table]
    WHERE /* filter conditions from M expression */
),
long_desc AS (
    SELECT ld.*,
        ROW_NUMBER() OVER (
            PARTITION BY ldkey
            ORDER BY descriptionid DESC
        ) AS rn
    FROM [schema].[descriptions] ld
    WHERE ldownertable = 'TARGET_TABLE'
)

-- ── Main SELECT ─────────────────────────────────────────────────
SELECT
    -- Primary Key / Identifiers
    t.record_id                                    AS [Record ID],
    t.record_uid                                   AS [RECORDUID],

    -- Composite Keys
    CONCAT(t.record_id, '_', t.record_type)        AS [Record PK ID],
    CONCAT(t.parent_id, '_', t.parent_type)        AS [Parent FK ID],

    -- Status & Classification
    t.status                                       AS [Status],
    CASE
        WHEN UPPER(LTRIM(RTRIM(t.category))) = 'LONGCATEGORYNAME'
        THEN 'Short'
        ELSE t.category
    END                                            AS [Category],

    -- Descriptions
    t.summary                                      AS [Summary],
    ld.description_text                            AS [Long Description],

    -- Dates
    t.created_date                                 AS [Created Date],
    t.modified_date                                AS [Modified Date],

    -- Lookups (resolved via JOIN)
    p.display_name                                 AS [Owner Name],

    -- Audit
    t.FABRIC_LOADED_DATE                           AS [Fabric Loaded Date],
    t.FABRIC_LOADED_BY                             AS [Fabric Loaded By]

FROM deduped t
LEFT JOIN long_desc ld
    ON ld.ldkey = t.record_uid AND ld.rn = 1
LEFT JOIN [schema].[persons] p
    ON p.person_id = t.owner_id

WHERE t.rn = 1;  -- Keep only the latest record per parent
```

> **Reading the template:** Columns are grouped by purpose (identifiers, keys, status, descriptions, dates, lookups, audit) and each group is separated by a comment line. This makes the view scannable even when it grows to 50+ columns.

### 7.4 Common CTE Patterns

These patterns recur across nearly every reverse-engineering project. Match them to the M expression patterns you identified in Phase 4.

#### Pattern 1: Deduplication — Keep Latest Record per Group

```sql
WITH latest AS (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY parent_id
            ORDER BY record_id DESC  -- or ORDER BY created_date DESC
        ) AS rn
    FROM [schema].[source_table]
    WHERE type = 'TARGET_TYPE'
)
SELECT ... FROM latest WHERE rn = 1;
```

**Use when:** The M query uses `Table.Distinct`, groups by a parent key and keeps `MAX(id)`, or otherwise reduces multiple rows to one per group. This is the single most common pattern — most source systems store multiple revisions, and the semantic model only wants the latest.

#### Pattern 2: Deduplication with Count — MAX + GROUP BY

```sql
WITH latest_ids AS (
    SELECT
        MAX(record_id) AS max_id,
        parent_id,
        COUNT(*) AS records_per_parent
    FROM [schema].[source_table]
    WHERE type = 'TARGET_TYPE'
    GROUP BY parent_id
)
SELECT t.*, sub.records_per_parent AS [Records Per Parent]
FROM [schema].[source_table] t
INNER JOIN latest_ids sub ON sub.max_id = t.record_id;
```

**Use when:** You need both the latest record **and** a count of how many records exist per group (e.g., "Investigations Per Incident", "Line Items Per Order"). The `INNER JOIN` back to the source table retrieves the full row for the latest record.

#### Pattern 3: Ranked Long Descriptions

```sql
WITH ld_ranked AS (
    SELECT
        ldkey,
        ldtext,
        ROW_NUMBER() OVER (
            PARTITION BY ldkey
            ORDER BY longdescriptionid DESC
        ) AS rn
    FROM [schema].[longdescription]
    WHERE ldownertable = 'SOURCE_TABLE'
)
```

**Use when:** The source system stores multiple revisions of text descriptions (common in ERP and work management systems) and the semantic model only needs the most recent version. Join with `AND ld_ranked.rn = 1` in the main query.

#### Pattern 4: Conditional Aggregation (Pivot)

```sql
SELECT
    t.record_id,
    SUM(CASE WHEN wo.status IN ('CAN','CLOSE','COMP') THEN 1 ELSE 0 END) AS [Closed Actions],
    SUM(CASE WHEN wo.status NOT IN ('CAN','CLOSE','COMP') THEN 1 ELSE 0 END) AS [Open Actions]
FROM [schema].[tickets] t
INNER JOIN [schema].[related_records] rr ON rr.record_key = t.record_id
INNER JOIN [schema].[work_orders] wo ON wo.wo_num = rr.related_key
GROUP BY t.record_id;
```

**Use when:** The M query uses `Table.Pivot`, `Table.Group` with conditional counts, or `COUNTROWS(FILTER(...))` in DAX. This pattern converts row-level status values into columnar counts.

### 7.5 Composite Key Construction

Composite keys follow the pattern `CONCAT(id_column, '_', type_column)`:

```sql
CONCAT(t.record_id, '_', t.record_class)  AS [Record PK ID]
```

**Rules:**

- **Primary composite key** (`PK ID`): uniquely identifies the record in **this** view
- **Foreign composite key** (`FK ID`): links to another view's PK ID
- **Naming convention:** Use `[EntityName PK ID]` for primary keys and `[ParentEntity FK ID]` for foreign keys
- **Type suffix purpose:** The type column enables joins across heterogeneous record types — e.g., a `related_records` table where records of type `ORDER`, `TICKET`, and `ASSET` all share the same ID sequence
- **Separator:** Always use `'_'` (underscore) as the separator in `CONCAT`. This must be consistent across all views so that cross-view joins work

```sql
-- Primary key in VW_Orders
CONCAT(o.order_id, '_', o.order_class)      AS [Order PK ID]

-- Foreign key in VW_Order_Details referencing VW_Orders
CONCAT(d.parent_id, '_', d.parent_class)     AS [Order FK ID]
```

### 7.6 String Normalization

Source data frequently contains leading/trailing whitespace and inconsistent casing. Normalize all string comparisons to prevent silent filter failures:

```sql
-- For WHERE clauses
WHERE UPPER(LTRIM(RTRIM(t.record_class))) = 'TARGET_CLASS'

-- For CASE expressions
CASE
    WHEN UPPER(LTRIM(RTRIM(t.category))) = 'LONGNAME'
    THEN 'Short'
    ELSE t.category
END AS [Category]
```

**Always use `UPPER(LTRIM(RTRIM(...)))`** — this three-function pattern handles:
- Leading spaces (`LTRIM`)
- Trailing spaces (`RTRIM`)
- Case variations (`UPPER`)

> **Common mistake:** Writing `WHERE t.status = 'OPEN'` without normalization. This silently excludes rows where the value is `'Open'`, `' OPEN '`, or `'open'`. In source systems that were originally case-insensitive (e.g., Oracle, IBM Maximo), these variations are extremely common.

### 7.7 EAV (Entity-Attribute-Value) Pivots

Some source systems store dynamic attributes as rows in an Entity-Attribute-Value table rather than as columns. When the M query references these attributes, pivot them into columns in your view:

```sql
SELECT
    e.entity_id,
    MAX(CASE WHEN s.attr_name = 'COLOR' THEN s.attr_value END)  AS [Color],
    MAX(CASE WHEN s.attr_name = 'SIZE' THEN s.attr_value END)   AS [Size],
    MAX(CASE WHEN s.attr_name = 'WEIGHT' THEN s.attr_value END) AS [Weight]
FROM [schema].[events] e
LEFT JOIN [schema].[event_specs] s ON s.event_id = e.event_id
GROUP BY e.entity_id;
```

**Key points:**
- `MAX()` with `CASE` is the standard SQL pivot pattern — each `CASE` expression produces one output column
- Use `LEFT JOIN` (not `INNER JOIN`) so that entities without a given attribute still appear in the result (with `NULL` values)
- The attribute names (`'COLOR'`, `'SIZE'`, etc.) come from your Phase 4 analysis of the M query — look for `Table.Pivot` or filtered joins against specification/attribute tables
- If the attribute list is long, document which attributes you're including and why (usually only the ones the semantic model actually uses)

### 7.8 Fabric SQL Endpoint Limitations

The Fabric Lakehouse SQL Analytics Endpoint is **not** full SQL Server. Be aware of these constraints when writing views:

| Limitation | Workaround |
|---|---|
| No recursive CTEs | Use iterative approaches or flatten hierarchies in an upstream ETL step |
| No `NVARCHAR(MAX)` in some contexts | Use `VARCHAR(MAX)` or `CAST` to a bounded length |
| No `CREATE FUNCTION` or `CREATE PROCEDURE` | All logic must live in views or inline CTE expressions |
| No cross-database queries | All source tables must be in the same Lakehouse (or use shortcuts) |
| `CREATE OR ALTER VIEW` syntax required | Cannot use the `DROP VIEW IF EXISTS` + `CREATE VIEW` two-statement pattern |
| Limited temp table support | Use CTEs instead of `#temp` tables |
| No `MERGE` statement | Use separate `INSERT`/`UPDATE` logic or handle in ETL pipelines |
| Read-only for Delta tables | Views can only `SELECT` — no `INSERT`, `UPDATE`, or `DELETE` on underlying tables |

> **Practical impact:** The most frequent surprise is the `CREATE OR ALTER VIEW` requirement. If you copy-paste a view definition from SQL Server Management Studio, you'll need to change `CREATE VIEW` to `CREATE OR ALTER VIEW`. The `DROP/CREATE` pattern fails because `DROP VIEW IF EXISTS` may not be supported or may cause issues with dependent objects.

### 7.9 Leveraging Copilot for View Design

Once you have the M expression analyzed and the source table mapping confirmed, let Copilot draft the view for you.

**Copilot prompt:**
```
Based on this M expression:

[paste the full M expression from Phase 4]

Create a SQL view named [dbo].[VW_Orders] that reads from [dbo].[orders]
in the Fabric Lakehouse. Requirements:
- Use [Friendly Names] for all columns
- Include a deduplication CTE that keeps only the latest record per parent_id
- Add composite keys: CONCAT(order_id, '_', order_class) AS [Order PK ID]
- Include [Fabric Loaded Date] and [Fabric Loaded By] audit columns
- Use UPPER(LTRIM(RTRIM(...))) for all string comparisons in WHERE clauses
```

**Review the generated view against:**

1. **M expression logic** — Are all filters, joins, column renames, and computed columns captured?
2. **Source table schema** — Do the column names match what actually exists in the Lakehouse (from Phase 5)?
3. **Naming conventions** — Are all column aliases in `[Brackets]` with friendly names?
4. **Deduplication** — Is the `PARTITION BY` / `ORDER BY` logic correct for your use case?
5. **Fabric compatibility** — Does the syntax comply with the limitations in §7.8?

> **Iterate:** Copilot's first draft is rarely perfect. Paste the generated SQL back with specific corrections: *"The deduplication should partition by customer_id, not parent_id. Also add a LEFT JOIN to dbo.regions on region_code."*

### 7.10 Design Checklist

Before deploying a view, verify every item:

- [ ] View uses `CREATE OR ALTER VIEW` syntax (Fabric requirement)
- [ ] View name follows `VW_` prefix convention
- [ ] File saved as `VW_ViewName_Fabric.sql`
- [ ] Composite keys defined for PK and FK columns using `CONCAT` pattern
- [ ] Deduplication CTE implemented where source has multiple records per entity
- [ ] String normalization (`UPPER(LTRIM(RTRIM(...)))`) applied to all `WHERE` and `CASE` comparisons
- [ ] Column aliases match the semantic model's friendly names (from Phase 4 column mapping)
- [ ] Audit columns included as the last two columns: `[Fabric Loaded Date]`, `[Fabric Loaded By]`
- [ ] Fabric SQL endpoint limitations accounted for (no recursive CTEs, no UDFs, etc.)
- [ ] View tested against the SQL Analytics Endpoint — runs without errors
- [ ] Row count sanity-checked against the semantic model's table (should be in the same ballpark)
- [ ] View dependency order documented (which views must be created before which)

---

## Section 8: Phase 7 — Build, Deploy & Iterate

### 8.1 Deployment Method

Fabric Lakehouse SQL views are deployed manually through the SQL Analytics Endpoint. There is no CI/CD pipeline for DDL in Fabric today, so the process is hands-on:

1. **Write the DDL** — Save each `CREATE OR ALTER VIEW` statement in a `.sql` file in your project folder (one file per view, named `VW_ViewName_Fabric.sql`).
2. **Open the SQL Analytics Endpoint** — In the Fabric portal, navigate to your Lakehouse and click the **SQL Analytics Endpoint** (not the Lakehouse endpoint). The URL will contain `/sqlanyticsendpoint/` or show "SQL analytics endpoint" in the header bar.
3. **Paste the DDL** — Open the SQL query editor and paste the full `CREATE OR ALTER VIEW` statement.
4. **Execute** — Click **Run** (▶). A successful execution returns `Commands completed successfully`.
5. **Verify** — Expand the **Views** folder in the schema browser on the left. Your new view should appear. If it doesn't, click **Refresh**.

> ⚠️ **Critical distinction:** The **SQL Analytics Endpoint** and the **Lakehouse endpoint** look similar in the Fabric portal but serve different purposes. Only the SQL Analytics Endpoint supports DDL statements like `CREATE OR ALTER VIEW`. If you paste DDL into the Lakehouse endpoint query editor, it will fail. Look for "SQL analytics endpoint" in the workspace item list — it has a different icon (a database cylinder with a lightning bolt) than the Lakehouse item (a plain database cylinder).

### 8.2 Deployment Order

When your view set includes dependent views (views that `SELECT` from other custom views), you must deploy them in dependency order. Deploying a view that references another view that doesn't exist yet will fail with `Invalid object name`.

**Rule:** Deploy leaf views first, then composite views.

```
1. Independent views first   (read from raw Lakehouse tables only)
2. Dependent views last      (reference other custom views)
```

**Example deployment sequence:**

```
Step 1: VW_Detail_A        (reads from raw tables only)
Step 2: VW_Detail_B        (reads from raw tables only)
Step 3: VW_Aggregated_C    (reads from raw tables only)
Step 4: VW_Reference       (SELECT * FROM VW_Detail_A LEFT JOIN VW_Detail_B LEFT JOIN VW_Aggregated_C)
```

Steps 1–3 can be deployed in any order (they are independent). Step 4 must come last because it depends on the views created in Steps 1–3.

> **Best practice:** Document the deployment order in your project README or in a dedicated `DEPLOYMENT_ORDER.md` file. This is especially important when someone else needs to redeploy the views (e.g., after a Lakehouse migration or schema change).

### 8.3 Common Deployment Errors and Fixes

| Error | Cause | Fix |
|---|---|---|
| `Invalid column name 'xyz'` | Column doesn't exist in the source table (name mismatch or typo) | Query `INFORMATION_SCHEMA.COLUMNS` to find the actual column name |
| `Invalid object name 'schema.table'` | Source table doesn't exist, or wrong schema specified | Verify with `SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'tablename'` |
| `CREATE VIEW must be the only statement in the batch` | Multiple statements pasted in the query window (e.g., a `GO` separator or a stray `SELECT`) | Run exactly one `CREATE OR ALTER VIEW` statement per execution — nothing else in the query window |
| `The multi-part identifier could not be bound` | A table alias or column reference doesn't match any table in the `FROM`/`JOIN` clauses | Check that every alias used in `SELECT` and `WHERE` is defined in `FROM` or `JOIN`, and that CTE names are spelled correctly |
| `Ambiguous column name` | Two joined tables share a column name and the reference doesn't specify which table | Prefix every column with its table alias (e.g., `t.status` instead of just `status`) |
| `Types don't match between the anchor and the recursive member` | A recursive CTE was attempted | Fabric's SQL Analytics Endpoint does not support recursive CTEs — use a different approach (e.g., flatten hierarchies upstream, use iterative CTEs, or pre-compute in an ETL step) |
| View creates successfully but returns 0 rows | A `WHERE` filter is too restrictive, a `JOIN` condition eliminates all matches, or case sensitivity causes mismatches | Test the inner query (each CTE and each `JOIN`) separately. Check for case-sensitivity issues with `UPPER()` wrapping |

### 8.4 Iterating with Copilot

When deployment fails, feed the error back to Copilot for diagnosis. Copilot can use MCP tools to inspect the live Lakehouse schema and pinpoint the issue.

**Example prompt for a column-name error:**

```
Copilot prompt: "I got this error when deploying my view: 'Invalid column name priority'.
The view references [dbo].[my_table]. Can you check what columns actually exist
in that table and suggest the correct column name?"
```

**What Copilot can do with MCP:**

- **Inspect schema:** Query `INFORMATION_SCHEMA.COLUMNS` via the Fabric Notebook MCP or Fabric MCP to list actual column names and data types.
- **Compare references:** Diff the view's column references against the real table schema and flag mismatches.
- **Suggest corrections:** Propose the correct column name (e.g., `priority_code` instead of `priority`) and regenerate the affected `SELECT` or `CASE` expression.
- **Regenerate DDL:** If multiple columns are wrong, ask Copilot to regenerate the entire view using the corrected column names from the schema inspection.

**Iterative debugging loop:**

```
1. Deploy view → error
2. Paste error into Copilot Chat
3. Copilot inspects schema via MCP, suggests fix
4. Apply fix to .sql file
5. Re-deploy → success (or repeat from step 1)
```

> **Tip:** Each iteration should fix one category of error. Don't try to fix everything at once — deploy after each fix so you can catch cascading issues early.

### 8.5 Verifying Deployed Views

After a successful deployment (no errors), verify that the view actually returns correct data. Run these checks in the SQL Analytics Endpoint query editor:

```sql
-- 1. Row count — should be non-zero and in the expected range
SELECT COUNT(*) AS row_count FROM [dbo].[VW_MyView];

-- 2. Sample data — spot-check that columns are populated and values look reasonable
SELECT TOP 10 * FROM [dbo].[VW_MyView];

-- 3. Column inventory — verify column names and data types match your design
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'VW_MyView'
ORDER BY ORDINAL_POSITION;
```

**What to look for:**

- **Row count:** Should be in the same ballpark as the semantic model's table row count. A count of 0 means something is wrong (see §8.3). A count much higher than expected suggests a `JOIN` is fanning out rows.
- **Sample data:** Columns should not be all `NULL`. Friendly names should appear as column headers. Date columns should contain valid dates.
- **Column inventory:** Every column from your design document should appear. Data types should be appropriate (e.g., dates as `DATE` or `DATETIME2`, not `VARCHAR`).

### 8.6 Build Checklist

Before moving to validation (Section 9), confirm:

- [ ] All views deployed to the SQL Analytics Endpoint in correct dependency order
- [ ] Each view executes without errors
- [ ] Each view returns a non-zero row count
- [ ] Column names and data types verified via `INFORMATION_SCHEMA.COLUMNS`
- [ ] Sample data spot-checked (no all-`NULL` columns, reasonable values)
- [ ] No deployment errors remaining
- [ ] `.sql` files in your project folder match what is deployed (no uncommitted fixes)

---

## Section 9: Phase 8 — Validation

### 9.1 Why Validate

Deploying a view without errors does not mean it is correct. Your SQL views are a translation of the semantic model's Power Query M logic, and translation errors are common. Validation ensures:

- **Correct grain** — No unintended row duplication from `JOIN` fan-outs or missing deduplication.
- **Correct row counts** — All expected records are present and no records are dropped by overly restrictive filters.
- **Correct transformations** — Filters, column renames, `CASE` replacements, and computed columns produce the same results as the original Power Query logic.
- **Correct joins** — Cross-view relationships work as expected (no orphaned records, no unexpected `NULL` keys).

> **Goal:** Every test should either return **0 rows** (meaning no violations found) or return **informational data** that you review for reasonableness. If a test returns rows when it shouldn't, you have a bug to fix.

### 9.2 Validation Script Structure

Organize your validation tests into a single `.sql` file per view set (or per project). Use a clear header and section structure so anyone can run the tests:

```sql
-- ═══════════════════════════════════════════════════════════════════
-- Validation Test Cases — [View Name(s)]
-- ═══════════════════════════════════════════════════════════════════
-- Target:   [Lakehouse Name] SQL Analytics Endpoint
-- Date:     YYYY-MM-DD
-- Author:   [Your Name]
-- Usage:    Run each test individually in Fabric SQL query editor.
--           Tests expecting "0 rows" pass when the result set is empty.
--           Tests marked "informational" return data for manual review.
-- ═══════════════════════════════════════════════════════════════════
```

Name the file `VW_ViewName_Validation.sql` and store it alongside your view DDL files.

### 9.3 Test Pattern Catalog

Use these reusable test patterns. Copy and adapt them for each view by replacing `[schema]`, `[VW_MyView]`, and column names with your actual values.

#### Pattern 1: Grain Check (no duplicates on primary key)

```sql
-- TEST: No duplicate primary keys
-- Expected: 0 rows (every primary key is unique)
SELECT [Record ID], COUNT(*) AS cnt
FROM [dbo].[VW_MyView]
GROUP BY [Record ID]
HAVING COUNT(*) > 1;
```

#### Pattern 2: Row Count Reconciliation

```sql
-- TEST: View row count matches filtered source count
-- Expected: Both counts should be equal
SELECT
    (SELECT COUNT(*) FROM [dbo].[VW_MyView]) AS view_rows,
    (SELECT COUNT(*) FROM [dbo].[source_table] WHERE [type] = 'EXPECTED') AS source_rows;
```

#### Pattern 3: Filter Validation

```sql
-- TEST: All rows match expected filter criteria
-- Expected: 0 rows (no rows outside the expected filter)
SELECT [Record ID], [Type]
FROM [dbo].[VW_MyView]
WHERE UPPER([Type]) <> 'EXPECTED_TYPE';
```

#### Pattern 4: Composite Key Format

```sql
-- TEST: Composite key follows expected CONCAT pattern
-- Expected: 0 rows (every key matches the pattern)
SELECT [Record PK ID]
FROM [dbo].[VW_MyView]
WHERE [Record PK ID] NOT LIKE '%[_]EXPECTED_SUFFIX';
```

#### Pattern 5: Non-Negative Counts

```sql
-- TEST: Aggregated counts are non-negative
-- Expected: 0 rows
SELECT [Record ID], [Open Count], [Closed Count]
FROM [dbo].[VW_MyView]
WHERE [Open Count] < 0 OR [Closed Count] < 0;
```

#### Pattern 6: Referential Integrity (Cross-View)

```sql
-- TEST: Every child record references a valid parent (no orphans)
-- Expected: 0 rows
SELECT child.[Record ID], child.[Parent ID]
FROM [dbo].[VW_Child] child
WHERE NOT EXISTS (
    SELECT 1
    FROM [dbo].[VW_Parent] parent
    WHERE parent.[Record ID] = child.[Parent ID]
);
```

#### Pattern 7: Value Transformation

```sql
-- TEST: String replacement worked — no raw/unshortened values remain
-- Expected: 0 rows
SELECT [Record ID], [Category]
FROM [dbo].[VW_MyView]
WHERE [Category] LIKE '%LONGORIGINALVALUE%';
```

#### Pattern 8: Join Verification (cross-view counts match)

```sql
-- TEST: Distinct parent counts are consistent across child and parent views
-- Expected: Both counts should be equal
SELECT
    (SELECT COUNT(DISTINCT [Parent ID])
     FROM [dbo].[VW_Child]) AS parents_referenced_by_children,
    (SELECT COUNT(DISTINCT p.[Record ID])
     FROM [dbo].[VW_Parent] p
     WHERE EXISTS (
         SELECT 1 FROM [dbo].[VW_Child] c
         WHERE c.[Parent ID] = p.[Record ID]
     )) AS parents_with_children;
```

#### Pattern 9: Sample Data (informational)

```sql
-- TEST: Spot-check data quality (informational — review manually)
-- Expected: Columns populated with reasonable values
SELECT TOP 10
    [Record ID], [Status], [Created Date], [Owner Name]
FROM [dbo].[VW_MyView]
ORDER BY [Created Date] DESC;
```

#### Pattern 10: Status Distribution (informational)

```sql
-- TEST: Status distribution (informational — review for plausibility)
-- Expected: Returns known statuses with plausible counts
SELECT [Status], COUNT(*) AS cnt
FROM [dbo].[VW_MyView]
GROUP BY [Status]
ORDER BY cnt DESC;
```

### 9.4 Running Tests

1. Open the **SQL Analytics Endpoint** for your Lakehouse in the Fabric portal.
2. Paste **one test at a time** into the query editor and execute.
3. Evaluate the result:
   - Tests expecting **"0 rows"** pass when the result set is empty.
   - Tests marked **"informational"** return data — review the output for reasonableness (plausible counts, expected statuses, non-`NULL` values).
4. Record results: test ID, pass/fail, actual value(s), and notes.

> ⚠️ **Do not run the entire validation script at once.** The Fabric SQL query editor may time out on large scripts, and a single failing query can block subsequent queries. Run tests individually.

**Handling failures:**

- If a grain check fails (duplicates found), revisit your deduplication CTE — the `PARTITION BY` or `ORDER BY` clause is likely wrong.
- If row counts don't match, check your `WHERE` filters for case-sensitivity issues (`UPPER()` wrapping) or missing filter conditions.
- If orphan records appear in cross-view tests, check that your join keys are correctly constructed (especially composite keys built with `CONCAT`).
- Use the iterative Copilot debugging loop from §8.4 to diagnose and fix issues.

### 9.5 Cross-View Validation

When your project includes multiple related views (parent-child, header-detail), add cross-view validation tests beyond simple referential integrity:

- **No orphans:** Every child record references a valid parent (Pattern 6).
- **Bidirectional count consistency:** The count of distinct parents referenced by children should match the count of parents that have children (Pattern 8).
- **Shared attribute consistency:** If both parent and child views include a shared attribute (e.g., site, region, organization), verify they agree:

```sql
-- TEST: Shared attribute consistent across views
-- Expected: 0 rows
SELECT child.[Record ID], child.[Site], parent.[Site]
FROM [dbo].[VW_Child] child
INNER JOIN [dbo].[VW_Parent] parent
    ON child.[Parent ID] = parent.[Record ID]
WHERE child.[Site] <> parent.[Site];
```

- **Operational plausibility:** Status combinations should make sense (e.g., a closed parent shouldn't have open children if the business logic says otherwise).

### 9.6 Validation Checklist

- [ ] Grain check passes for every view (no duplicate primary keys)
- [ ] Row counts reconcile with source table expectations
- [ ] All filter conditions validated (no unexpected record types leak through)
- [ ] Composite keys follow the expected `CONCAT` pattern
- [ ] Cross-view referential integrity passes (0 orphans)
- [ ] Cross-view count consistency confirmed
- [ ] Informational tests show plausible data distributions and populated columns
- [ ] All test results documented in a validation report (see Section 10)

---

## Section 10: Phase 9 — Documentation

### 10.1 Why Document

Your SQL views are a translation of complex Power Query M expressions, DAX measures, and implicit Power BI conventions into explicit SQL. Without documentation, the next engineer (or future you) will face the same reverse-engineering effort you just completed — this time against your SQL views instead of the semantic model.

Good documentation answers three questions:
1. **What does this view do?** (grain, filters, purpose)
2. **Why is it structured this way?** (which M logic or DAX pattern it replicates)
3. **How do I redeploy or modify it?** (dependencies, deployment order, known constraints)

### 10.2 Technical View Documentation

For each view, create a documentation section (in a Markdown file or a shared wiki page) that covers:

| Property | What to Include |
|---|---|
| **View name** | Fully qualified name: `[schema].[VW_ViewName]` |
| **Purpose** | One-sentence description of what the view provides |
| **Grain** | What one row represents (e.g., "1 row per work order, deduplicated to the latest record per `parent_id`") |
| **Source filter** | Any `WHERE` clause filters applied to the source table (e.g., `WHERE UPPER(type) = 'INCIDENT'`) |
| **SQL file** | Path to the `.sql` script in your project folder (e.g., `views/VW_Orders_Fabric.sql`) |
| **Replaces** | What this view replaces in the original semantic model (e.g., "Orders table — previously built via Power Query with 12 transformation steps") |
| **Dependencies** | Other custom views this view depends on (e.g., "Requires `VW_Detail_A` and `VW_Detail_B` to exist") |
| **CTEs** | Name and purpose of each CTE in the view |
| **JOINs** | For each JOIN: target table/view, join type (`LEFT`, `INNER`), join key(s), and notes |
| **Column dictionary** | Every output column: name, source expression, data type, and description (see §10.3) |

**Example CTE documentation:**

| CTE | Purpose |
|-----|---------|
| `RankedRecords` | Deduplicates source rows — keeps only the latest record per `parent_id` using `ROW_NUMBER()` |
| `FilteredBase` | Applies the type filter (`WHERE UPPER(type) = 'INCIDENT'`) and selects relevant columns |
| `PersonLookup` | Joins to the `person` table to resolve `owner_id` to `[Owner Name]` |

**Example JOIN documentation:**

| Target | Type | Key | Notes |
|--------|------|-----|-------|
| `dbo.person` | `LEFT JOIN` | `owner_id = person_id` | Resolves owner display name; NULL if person record missing |
| `dbo.location` | `LEFT JOIN` | `location_id = loc_id` | Resolves site and region; NULL for records with no location |

### 10.3 Column Dictionary Format

Every view should have a column dictionary that maps output columns to source expressions. This is essential for debugging and future modifications.

```markdown
| Column | Source Expression | Data Type | Description |
|--------|-------------------|-----------|-------------|
| [Record ID] | `t.record_id` | `VARCHAR` | Primary key — natural record identifier from source system |
| [Status] | `t.status` | `VARCHAR` | Current workflow status (e.g., OPEN, CLOSED, IN PROGRESS) |
| [Category] | `CASE WHEN t.category = 'LONGNAME' THEN 'SHORT' ... END` | `VARCHAR` | Shortened category — replaces verbose source values |
| [Owner Name] | `p.display_name` | `VARCHAR` | Resolved via LEFT JOIN to `person` table on `owner_id` |
| [Created Date] | `CAST(t.created_date AS DATE)` | `DATE` | Record creation date (time component removed) |
| [Open Count] | `SUM(CASE WHEN status = 'OPEN' THEN 1 ELSE 0 END)` | `INT` | Count of open child records (aggregated views only) |
| [Record PK ID] | `CONCAT(t.record_id, '_', t.record_class)` | `VARCHAR` | Composite primary key for cross-view joins |
| [Fabric Loaded Date] | `t.FABRIC_LOADED_DATE` | `DATETIME2` | ETL load timestamp from the ingestion pipeline |
| [Fabric Loaded By] | `t.FABRIC_LOADED_BY` | `VARCHAR` | ETL process identifier |
```

### 10.4 Validation Report

After completing validation (Section 9), create a formal validation report. This report is your evidence that the views produce correct results and is invaluable for audits, handoffs, and future debugging.

**Report format:**

```markdown
# [Project Name] — Validation Report

> **Date:** YYYY-MM-DD
> **Validated by:** [Your Name]
> **Target:** [Lakehouse Name] SQL Analytics Endpoint
> **Validation script:** `validation/VW_Views_Validation.sql`
> **Result:** ✅ N/N PASS

## Summary Table

| Section | View | Tests | Pass | Fail |
|---------|------|-------|------|------|
| A | VW_Orders | 4 | 4 | 0 |
| B | VW_Order_Details | 6 | 6 | 0 |
| C | Cross-View | 3 | 3 | 0 |
| **Total** | | **13** | **13** | **0** |

## Detailed Results

### Section A: VW_Orders

| # | Test | Expected | Actual | Result |
|---|------|----------|--------|--------|
| A1 | Grain check (no duplicate Order IDs) | 0 rows | 0 rows | ✅ PASS |
| A2 | Row count reconciliation | Equal | 12,450 / 12,450 | ✅ PASS |
| A3 | Filter validation (type = ORDER) | 0 rows | 0 rows | ✅ PASS |
| A4 | Sample data spot-check | Reasonable | Reviewed | ✅ PASS |

### Key Metrics

| Metric | Value |
|--------|-------|
| VW_Orders row count | 12,450 |
| VW_Order_Details row count | 87,215 |
| Distinct statuses | 5 (OPEN, CLOSED, PENDING, CANCELLED, IN PROGRESS) |
```

### 10.5 View Index

Maintain a central index of all views in your project. This serves as a quick-reference table of contents and is especially useful when the project grows to many views.

```markdown
# View Index

| # | View | Grain | Description | Dependencies |
|---|------|-------|-------------|--------------|
| 1 | `[dbo].[VW_Orders]` | 1 row per order | Core orders view — filters to type = ORDER, deduplicates by order_id | None |
| 2 | `[dbo].[VW_Order_Details]` | 1 row per line item | Line item details per order, joined to product catalog | None |
| 3 | `[dbo].[VW_Order_Summary]` | 1 row per order | Aggregated metrics (open/closed counts) per order | None |
| 4 | `[dbo].[VW_Order_Reference]` | 1 row per order × detail | Denormalized reference view combining all above | VW_Orders, VW_Order_Details, VW_Order_Summary |
```

### 10.6 Relationship Diagram

Document how views relate to each other using an ASCII diagram. This makes the dependency chain and join relationships immediately visible.

```
VW_Orders
    │  join on [Order ID] = [Parent Order ID]
    ▼
VW_Order_Details                    (1 row per line item)
    │
    ├──→ VW_Order_Summary           (1:many — aggregated metrics)
    │      join on [Order ID]
    │
    └──→ VW_Order_Reference         (pre-joined denormalized view)
           combines all above
           grain fans out to 1 row per order × detail
```

> **Tip:** If your project has many views, consider generating a visual diagram using a tool like [draw.io](https://draw.io) or Mermaid. For simpler projects, the ASCII diagram is sufficient and lives directly in your Markdown documentation.

### 10.7 Documentation Checklist

- [ ] Technical documentation written for every view (purpose, grain, filters, source mapping)
- [ ] Column dictionary complete for every view (column name, source expression, data type, description)
- [ ] CTE and JOIN tables documented for every view
- [ ] Validation report created with all test results, pass/fail status, and key metrics
- [ ] View index updated with all views, descriptions, and dependencies
- [ ] Relationship diagram documented (ASCII or visual)
- [ ] Deployment order documented (in README or `DEPLOYMENT_ORDER.md`)
- [ ] All `.sql` files stored in the project folder and version-controlled

---

## Appendix A — MCP Command Cheat Sheet

Quick-reference for every MCP tool call used in this playbook, organized by workflow phase.

### Discovery Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `fabric-notebook-mcp` | `list_artifacts` | `workspace`, `artifact_type` (Report, Dataset, Lakehouse) | List reports, semantic models, or lakehouses in a workspace |
| `fabric-notebook-mcp` | `list_fabric_artifact_contents` | `artifact_type: "lakehouse"`, `artifact`, `workspace`, `search_type` | Browse lakehouse tables and files with column metadata |
| `fabric-notebook-mcp` | `preview_lakehouse_table` | `workspace`, `lakehouse_id`, `table_name`, `row_count` | Preview sample rows from a lakehouse table |
| `fabric_mcp` | `onelake_list_workspaces` | (none required) | List all accessible workspaces |
| `fabric_mcp` | `onelake_list_items` | `workspace` | List items in a workspace via OneLake API |

### Connection Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `powerbi-modeling-mcp` | `connection_operations → ConnectFabric` | `workspaceName`, `semanticModelName` | Connect to a Fabric semantic model |
| `powerbi-modeling-mcp` | `connection_operations → ListConnections` | (none) | List active connections |
| `powerbi-modeling-mcp` | `connection_operations → GetConnection` | `connectionName` (optional) | Get current connection details |
| `powerbi-modeling-mcp` | `connection_operations → Disconnect` | `connectionName` | Disconnect from a model |

### Extraction Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `powerbi-modeling-mcp` | `table_operations → List` | (none) | List all tables in the connected model |
| `powerbi-modeling-mcp` | `table_operations → ExportTMDL` | `references: [{ name: "TableName" }]` | Export full TMDL definition for a table |
| `powerbi-modeling-mcp` | `relationship_operations → List` | (none) | List all relationships |
| `powerbi-modeling-mcp` | `measure_operations → List` | (none) | List all measures |
| `powerbi-modeling-mcp` | `measure_operations → Get` | `references: [{ name: "MeasureName" }]` | Get DAX expression for a measure |
| `powerbi-modeling-mcp` | `partition_operations → List` | `filter: { tableName: "TableName" }` | Get source M/SQL expressions |
| `powerbi-modeling-mcp` | `column_operations → List` | `filter: { tableNames: ["TableName"] }` | List columns with data types |

### Analysis & Validation Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `powerbi-modeling-mcp` | `dax_query_operations → Execute` | `query` | Run a DAX query against the model |
| `powerbi-modeling-mcp` | `model_operations → ExportTMDL` | `tmdlExportOptions` | Export entire model to TMDL |
| `powerbi-modeling-mcp` | `model_operations → GetStats` | (none) | Get model statistics |

---

## Appendix B — Power Query M → SQL Translation Guide

Use this reference when converting Power Query M expressions (extracted from partition definitions) into Fabric SQL view logic.

### Data Source Access

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Sql.Database("server", "db")` | `FROM [schema].[table]` | Identifies the source server/database |
| `Source{[Schema="dbo", Item="orders"]}[Data]` | `FROM dbo.orders` | Identifies specific table |
| `Value.NativeQuery(Source, "SELECT ...", null)` | Use the embedded SQL directly | Lift the SQL as-is; inspect for parameters |

### Row Filtering

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Table.SelectRows(t, each [status] = "Active")` | `WHERE status = 'Active'` | Single condition |
| `Table.SelectRows(t, each [status] <> "Deleted" and [type] = "Order")` | `WHERE status <> 'Deleted' AND type = 'Order'` | Multiple conditions |
| `Table.SelectRows(t, each [date] >= #date(2024,1,1))` | `WHERE date >= '2024-01-01'` | Date filter — use ISO 8601 format |
| `Table.SelectRows(t, each [value] <> null)` | `WHERE value IS NOT NULL` | Null check |

### Column Operations

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Table.RenameColumns(t, {{"old_name", "New Name"}})` | `old_name AS [New Name]` | Column rename — use brackets for spaces |
| `Table.SelectColumns(t, {"col1", "col2"})` | `SELECT col1, col2` | Column selection |
| `Table.RemoveColumns(t, {"unwanted"})` | Omit from SELECT list | Column removal |
| `Table.ReorderColumns(t, {"col2", "col1"})` | Order in SELECT list | Column reorder — cosmetic only |

### Computed Columns

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Table.AddColumn(t, "Full Name", each [First] & " " & [Last])` | `CONCAT(First, ' ', Last) AS [Full Name]` | String concatenation |
| `Table.AddColumn(t, "Key", each [id] & "_" & [type])` | `CONCAT(id, '_', type) AS [Key]` | Composite key |
| `Table.AddColumn(t, "Flag", each if [x] > 0 then "Yes" else "No")` | `CASE WHEN x > 0 THEN 'Yes' ELSE 'No' END AS [Flag]` | Conditional logic |
| `Table.AddColumn(t, "Year", each Date.Year([date]))` | `YEAR(date) AS [Year]` | Date extraction |
| `Table.AddColumn(t, "Upper", each Text.Upper([name]))` | `UPPER(name) AS [Upper]` | String transform |
| `Table.AddColumn(t, "Trimmed", each Text.Trim([val]))` | `LTRIM(RTRIM(val)) AS [Trimmed]` | Trim — SQL has no single TRIM in T-SQL |

### Joins

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Table.NestedJoin(t1, "key", t2, "key", "merged", JoinKind.LeftOuter)` | `LEFT JOIN t2 ON t1.key = t2.key` | Left outer join |
| `Table.NestedJoin(..., JoinKind.Inner)` | `INNER JOIN t2 ON ...` | Inner join |
| `Table.NestedJoin(..., JoinKind.FullOuter)` | `FULL OUTER JOIN t2 ON ...` | Full outer join |
| `Table.ExpandTableColumn(t, "merged", {"col1", "col2"})` | Include `t2.col1, t2.col2` in SELECT | Expand joined columns |
| Multi-key: `Table.NestedJoin(t1, {"k1","k2"}, t2, {"k1","k2"}, ...)` | `ON t1.k1 = t2.k1 AND t1.k2 = t2.k2` | Composite key join |

### Aggregation

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Table.Group(t, {"grp"}, {{"cnt", each Table.RowCount(_)}})` | `SELECT grp, COUNT(*) AS cnt FROM t GROUP BY grp` | Count |
| `Table.Group(t, {"grp"}, {{"total", each List.Sum([amount])}})` | `SELECT grp, SUM(amount) AS total FROM t GROUP BY grp` | Sum |
| `Table.Group(t, {"grp"}, {{"avg", each List.Average([val])}})` | `SELECT grp, AVG(val) AS avg FROM t GROUP BY grp` | Average |
| `Table.Group(t, {"grp"}, {{"max", each List.Max([val])}})` | `SELECT grp, MAX(val) AS max FROM t GROUP BY grp` | Max |

### Deduplication

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Table.Distinct(t)` | `SELECT DISTINCT *` | Remove exact duplicates |
| `Table.Distinct(t, {"key"})` | `ROW_NUMBER() OVER (PARTITION BY key ORDER BY ...) = 1` | Keep first per key — wrap in CTE |
| Sort then first-per-group | `ROW_NUMBER() OVER (PARTITION BY grp ORDER BY sort DESC) = 1` | Keep latest per group — use CTE pattern |

### String Functions

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Text.Upper(x)` | `UPPER(x)` | Uppercase |
| `Text.Lower(x)` | `LOWER(x)` | Lowercase |
| `Text.Trim(x)` | `LTRIM(RTRIM(x))` | Trim whitespace |
| `Text.Start(x, n)` | `LEFT(x, n)` | First n characters |
| `Text.End(x, n)` | `RIGHT(x, n)` | Last n characters |
| `Text.Length(x)` | `LEN(x)` | Length |
| `Text.Replace(x, "old", "new")` | `REPLACE(x, 'old', 'new')` | Replace substring |
| `Text.Contains(x, "sub")` | `x LIKE '%sub%'` | Contains check |

### Type Conversions

| M Pattern | SQL Equivalent | Notes |
|---|---|---|
| `Table.TransformColumnTypes(t, {{"col", type text}})` | `CAST(col AS VARCHAR(MAX))` | To string — size as appropriate |
| `Table.TransformColumnTypes(t, {{"col", Int64.Type}})` | `CAST(col AS BIGINT)` | To integer |
| `Table.TransformColumnTypes(t, {{"col", type date}})` | `CAST(col AS DATE)` | To date |

---

## Appendix C — Validation Test Template

Copy this template, fill in the bracketed placeholders, and run each test individually in the Fabric SQL Analytics Endpoint query editor.

```sql
-- ═══════════════════════════════════════════════════════════════════
-- Validation Test Cases — [VIEW NAME(S)]
-- ═══════════════════════════════════════════════════════════════════
-- Target:   [Lakehouse Name] SQL Analytics Endpoint
-- Schema:   [schema_name]
-- Usage:    Run each test individually in Fabric SQL query editor.
--           Tests expecting "0 rows" pass when the result set is empty.
--           Tests marked "informational" return data for review.
--
-- Views Under Test:
--   1. [VW_Name_1]
--   2. [VW_Name_2]
-- ═══════════════════════════════════════════════════════════════════


-- ═══════════════════════════════════════════════════════════════════
-- SECTION A: [VIEW_1_NAME]  (N tests)
-- ═══════════════════════════════════════════════════════════════════

-- TEST A1: Grain — no duplicate primary keys
-- Expected: 0 rows
SELECT [Primary Key Column], COUNT(*) AS cnt
FROM [schema].[VW_Name_1]
GROUP BY [Primary Key Column]
HAVING COUNT(*) > 1;


-- TEST A2: Row count matches source table
-- Expected: Both counts equal
SELECT
    (SELECT COUNT(*) FROM [schema].[VW_Name_1]) AS vw_rows,
    (SELECT COUNT(*) FROM [schema].[source_table] WHERE [filter]) AS source_rows;


-- TEST A3: Filter validation — all rows match expected type
-- Expected: 0 rows
SELECT [Primary Key Column], [Type Column]
FROM [schema].[VW_Name_1]
WHERE UPPER([Type Column]) <> 'EXPECTED_VALUE';


-- TEST A4: Composite key format validation
-- Expected: 0 rows
SELECT [Composite Key Column]
FROM [schema].[VW_Name_1]
WHERE [Composite Key Column] NOT LIKE '%[_]EXPECTED_SUFFIX';


-- TEST A5: Value transformation — no raw values remaining
-- Expected: 0 rows
SELECT [Primary Key Column], [Transformed Column]
FROM [schema].[VW_Name_1]
WHERE [Transformed Column] LIKE '%ORIGINAL_LONG_VALUE%';


-- TEST A6: Sample data — spot-check (informational)
-- Expected: Columns populated with reasonable values
SELECT TOP 10 *
FROM [schema].[VW_Name_1]
ORDER BY [Primary Key Column];


-- ═══════════════════════════════════════════════════════════════════
-- SECTION B: CROSS-VIEW ANALYSIS  (N tests)
-- ═══════════════════════════════════════════════════════════════════

-- TEST B1: Referential integrity — child → parent
-- Expected: 0 rows
SELECT child.[Child ID], child.[Parent FK]
FROM [schema].[VW_Child] child
WHERE NOT EXISTS (
    SELECT 1
    FROM [schema].[VW_Parent] parent
    WHERE parent.[Parent ID] = child.[Parent FK]
);


-- TEST B2: Bidirectional count consistency
-- Expected: Both counts equal
SELECT
    (SELECT COUNT(DISTINCT [Parent FK]) FROM [schema].[VW_Child]) AS parents_from_child,
    (SELECT COUNT(DISTINCT p.[Parent ID])
     FROM [schema].[VW_Parent] p
     WHERE EXISTS (
         SELECT 1 FROM [schema].[VW_Child] c
         WHERE c.[Parent FK] = p.[Parent ID]
     )) AS parents_from_parent;


-- TEST B3: Coverage summary (informational)
-- Expected: Returns overview metrics
SELECT
    (SELECT COUNT(*) FROM [schema].[VW_Parent]) AS total_parents,
    (SELECT COUNT(*) FROM [schema].[VW_Child]) AS total_children,
    (SELECT COUNT(DISTINCT [Parent FK]) FROM [schema].[VW_Child]) AS parents_with_children;


-- ═══════════════════════════════════════════════════════════════════
-- SECTION C: ROW COUNT SUMMARY  (1 test)
-- ═══════════════════════════════════════════════════════════════════

-- TEST C1: Row counts across all views (informational)
-- Expected: All non-zero
SELECT 'VW_Name_1' AS [View], COUNT(*) AS [Rows] FROM [schema].[VW_Name_1]
UNION ALL
SELECT 'VW_Name_2', COUNT(*) FROM [schema].[VW_Name_2];


-- ═══════════════════════════════════════════════════════════════════
-- END OF VALIDATION — N TESTS
-- ═══════════════════════════════════════════════════════════════════
```

---

## Appendix D — Copilot CLI Prompt Templates

Ready-to-use prompts for each phase. Copy, fill in `[PLACEHOLDERS]`, and paste into Copilot Chat.

### Phase 1: Discovery

```
List all reports and datasets in the '[WORKSPACE_NAME]' workspace
```

```
List all lakehouses in the '[WORKSPACE_NAME]' workspace and show me their tables
```

```
Show me all tables and their columns in the '[LAKEHOUSE_NAME]' lakehouse in '[WORKSPACE_NAME]'
```

### Phase 2: Connection

```
Connect to the '[SEMANTIC_MODEL_NAME]' semantic model in the '[WORKSPACE_NAME]' workspace
```

```
Show me the current connection details
```

### Phase 3: Extraction

```
List all tables in this semantic model, filtering out auto-generated date tables
```

```
List all relationships in this model — show me from/to tables, columns, cardinality, and active/inactive status
```

```
List all measures in this model with their DAX expressions
```

```
Show me the partition source queries (M expressions) for the '[TABLE_NAME]' table
```

```
Export the TMDL definition for the '[TABLE_NAME]' table
```

### Phase 4: Analysis

```
Analyze this M expression and tell me:
1. What source table(s) it reads from
2. What filters it applies
3. What columns it renames
4. What computed columns it creates
5. What joins it performs

[PASTE M EXPRESSION HERE]
```

```
Compare this M expression to the columns in [SCHEMA].[TABLE_NAME] in the lakehouse.
Are there any column name mismatches?
```

### Phase 5: Source Mapping

```
Show me the columns in the [SCHEMA].[TABLE_NAME] table in the '[LAKEHOUSE_NAME]' lakehouse.
Compare them to these semantic model column names: [LIST COLUMNS]
```

```
Preview 10 rows from [SCHEMA].[TABLE_NAME] in the '[LAKEHOUSE_NAME]' lakehouse
```

### Phase 6: View Design

```
Based on this M expression, create a Fabric SQL view called [SCHEMA].[VW_NAME].
Use [Friendly Names] for all columns. Follow these conventions:
- Include composite keys using CONCAT(id, '_', type)
- Add [Fabric Loaded Date] and [Fabric Loaded By] audit columns
- Use a deduplication CTE if the source has multiple rows per entity
- Apply UPPER(LTRIM(RTRIM(...))) for string comparisons in WHERE clauses

[PASTE M EXPRESSION HERE]
```

```
Add a LEFT JOIN to [SCHEMA].[LOOKUP_TABLE] to resolve [PERSON_ID] into [Display Name]
```

### Phase 7: Deployment Troubleshooting

```
I got this error deploying my view: '[ERROR MESSAGE]'.
The view reads from [SCHEMA].[TABLE_NAME]. Can you check the actual column names
in that table and suggest corrections?
```

```
My view deploys but returns 0 rows. Here's the SQL — can you help debug why?
[PASTE VIEW DDL]
```

### Phase 8: Validation

```
Create a validation test script for [SCHEMA].[VW_NAME] with tests for:
- Grain check (no duplicate [PRIMARY_KEY])
- Row count vs source table
- Filter validation (all rows should have [TYPE] = '[VALUE]')
- Composite key format
- Sample data spot-check
Also add cross-view tests against [SCHEMA].[VW_PARENT]
```

### Phase 9: Documentation

```
Generate technical documentation for [SCHEMA].[VW_NAME] including:
- Grain description
- Source table and filter
- CTE descriptions
- JOIN documentation
- Full column dictionary with source expressions
```
