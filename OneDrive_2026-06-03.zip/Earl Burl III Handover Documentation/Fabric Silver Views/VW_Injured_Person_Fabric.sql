-- filepath: c:\Users\EBU667\OneDrive - Targa Resources\fabric-semantic-docs\VW_Injured_Person_Fabric.sql
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Injured_Person  –  Fabric-Ready Version (v2 – SME review 2026-05-20)
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Changes: Renamed Ticket→Incident ID, Title→Job Title. Added Ticket UID.
--          Removed 15 blank/redundant columns per SME (Allison Miller).
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Injured_Person]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Injured_Person  –  Incident person bridge/context
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per person per incident (ticketid + plusgincpersonid)
    Sources: PLUSGINCPERSON, TICKET (for ticketuid)
    Serves : ES&H Incident Semantic Model (Injured Person table),
             bridge between Incidents → Injuries → Outcome
    Note  : PII lives here — Person Impacted removed from downstream views.
             Injury detail fields are in VW_Injury_and_Illness_Detail.
    ═══════════════════════════════════════════════════════════════════ */

SELECT
    /* ── Keys / Identifiers ───────────────────────────────────────── */
    p.ticketid                                   AS [Incident ID],              /* renamed from [Ticket] */
    t.ticketuid                                  AS [Ticket UID],               /* added: preferred join key to VW_Incident */
    p.plusgincpersonid                            AS [Incident Person Id],
    p.personid                                   AS [Person ID],
    p.personimpacted                             AS [Person Impacted],

    /* ── Composite join keys (ES&H model compatibility) ───────────── */
    CAST(p.ticketid + '|' + CAST(p.plusgincpersonid AS varchar(20)) AS varchar(200))
                                                 AS [tckt_prsn_joinid],          /* ES&H join key */

    /* ── Person Details ───────────────────────────────────────────── */
    p.title                                      AS [Job Title],                /* renamed from [Title] */
    p.dob                                        AS [Date of Birth],
    p.dateofhire                                 AS [Date of Hire],

    /* ── External Person ──────────────────────────────────────────── */
    p.extperson                                  AS [Is External Person],       /* Y/N per Maximo UI */
    p.extpersonrelationship                      AS [External Person Relationship],

    /* ── Contact Information ──────────────────────────────────────── */
    p.phone                                      AS [Phone],
    p.email                                      AS [Email],

    /* ── Address ──────────────────────────────────────────────────── */
    p.street                                     AS [Street],
    p.city                                       AS [City],
    p.state                                      AS [State],
    p.zip                                        AS [Zip],

    /* ── Follow-up ────────────────────────────────────────────────── */
    p.followupreqd                               AS [Follow Up Required],
    p.followupaction                             AS [Follow Up Action],
    p.ownergroup                                 AS [Owner Group],

    /* ── Scope ────────────────────────────────────────────────────── */
    p.orgid                                      AS [Organization],

    /* ── Sequence / Migration ─────────────────────────────────────── */
    p.tri_sequence                               AS [Sequence],
    p.injdatamigrated                            AS [Injury Data Migrated],
    p.outcomedatamigrated                        AS [Outcome Data Migrated],

    /* ── Audit ────────────────────────────────────────────────────── */
    p.FABRIC_LOADED_DATE                         AS [Fabric Loaded Date],
    p.FABRIC_LOADED_BY                           AS [Fabric Loaded By]

FROM maximo.PLUSGINCPERSON p
LEFT JOIN maximo.TICKET t ON t.ticketid = p.ticketid AND t.class = 'INCIDENT';
