-- ═══════════════════════════════════════════════════════════════════════
-- VW_Fire_Ignition_Attributes  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Grain:  1 row per FIRE/IGNITION event (plusginceventid)
-- Filter: plusgincidentgroup = 'FIRE/IGNITION'
-- Source: PLUSGINCEVENT + PLUSGINCEVENTSPEC + TICKET
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Fire_Ignition_Attributes]
AS
SELECT
    pe.ticketuid                                          AS [Ticket UID],
    LTRIM(RTRIM(t.ticketid))                             AS [Incident ID],
    pe.plusginceventid                                    AS [Event UID],
    MAX(CASE WHEN s.assetattrid = 'FIRE_RESPONSE'  THEN s.alnvalue END)  AS [Fire Response],
    MAX(CASE WHEN s.assetattrid = 'HIPO'           THEN s.alnvalue END)  AS [High Potential]
FROM maximo.PLUSGINCEVENT pe
INNER JOIN maximo.TICKET t
    ON t.ticketuid = pe.ticketuid
LEFT JOIN maximo.PLUSGINCEVENTSPEC s
    ON s.plusginceventid = pe.plusginceventid
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) = 'FIRE/IGNITION'
GROUP BY pe.ticketuid, t.ticketid, pe.plusginceventid
