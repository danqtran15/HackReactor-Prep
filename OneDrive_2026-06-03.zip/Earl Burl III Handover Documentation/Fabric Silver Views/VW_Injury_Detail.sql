SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Injury_Detail  –  SQL Server Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: On-premises / Azure SQL with Maximo schema
-- ═══════════════════════════════════════════════════════════════════════

CREATE VIEW [maximo].[VW_Injury_Detail]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Injury_Detail  –  Injury/illness detail per person per incident
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per injury/illness (ticketid + plusgincpersonid + injorillid)
    Sources: PLUSGINJORILL
    Serves : ES&H Incident Semantic Model (Injuries table),
             OSHA recordable tracking, Injury analytics
    Joins  : → VW_Injured_Person via [tckt_prsn_joinid]
             → VW_Outcome via [tckt_prson_inj_joinid]
    ═══════════════════════════════════════════════════════════════════ */

SELECT
    /* ── Keys / Identifiers ───────────────────────────────────────── */
    j.ticketid                                   AS [Ticket],                    /* was: ticketid */
    j.personid                                   AS [Person Impacted],           /* was: personid */
    j.plusgincpersonid                            AS [Incident Person Id],        /* was: plusgincpersonid */
    j.injorillid                                 AS [Illness or Injury],         /* was: injorillid */
    j.plusginjorillid                             AS [Unique Id],                 /* was: plusginjorillid */

    /* ── Composite join keys (ES&H model compatibility) ───────────── */
    CAST(j.ticketid + N'|' + CAST(j.plusgincpersonid AS nvarchar(20)) AS nvarchar(200))
                                                 AS [tckt_prsn_joinid],          /* FK → Injured Person */
    CAST(j.ticketid + N'|' + CAST(j.plusgincpersonid AS nvarchar(20)) + N'|' + CAST(j.injorillid AS nvarchar(20)) AS nvarchar(300))
                                                 AS [tckt_prson_inj_joinid],     /* PK for Outcome join */

    /* ── Reportable / Classification ──────────────────────────────── */
    CAST(j.rptable AS int)                       AS [Reportable Injury or Illness], /* was: rptable */

    /* ── Timing ───────────────────────────────────────────────────── */
    j.injorilldate                               AS [Injury or Onset of Illness], /* was: injorilldate */
    j.timecannotbd                               AS [Unknown Time],              /* was: timecannotbd */
    j.empbeganwork                               AS [Time Employee Started Work], /* was: empbeganwork */

    /* ── Location ─────────────────────────────────────────────────── */
    j.locationsid                                AS [Location Id],               /* was: locationsid */
    j.location                                   AS [Location],                  /* was: location */

    /* ── Description ──────────────────────────────────────────────── */
    j.justbefore                                 AS [Description of Employee Actions], /* was: justbefore */
    j.injorilldesc                               AS [Details of Injury or Illness],    /* was: injorilldesc */
    j.objsubs                                    AS [Details of Harmful Object or Substance], /* was: objsubs */

    /* ── Injury Type Flags ────────────────────────────────────────── */
    CAST(j.injury AS int)                        AS [Injury],                    /* was: injury */
    CAST(j.skindisorder AS int)                  AS [Skin Disorder],             /* was: skindisorder */
    CAST(j.respiratory AS int)                   AS [Respiratory Condition],      /* was: respiratory */
    CAST(j.poisoning AS int)                     AS [Poisoning],                 /* was: poisoning */
    CAST(j.hearingloss AS int)                   AS [Hearing Loss],              /* was: hearingloss */
    CAST(j.allother AS int)                      AS [Other],                     /* was: allother */

    /* ── Cause & Body Part ────────────────────────────────────────── */
    j.injorilltype                               AS [Injury Cause],              /* was: injorilltype */
    j.injorillbodypart                           AS [Impacted Body Part],        /* was: injorillbodypart */

    /* ── Healthcare Provider ──────────────────────────────────────── */
    j.hcpname                                    AS [Physician/HCP Name],        /* was: hcpname */
    j.hcpphone                                   AS [Physician/HCP Phone],       /* was: hcpphone */
    j.hcpemail                                   AS [Physician/HCP Email],       /* was: hcpemail */
    j.hcpfacility                                AS [HCP Treatment Facility],    /* was: hcpfacility */
    j.hcpfacaddress                              AS [HCP Facility Street Address], /* was: hcpfacaddress */
    j.hcpfaccity                                 AS [HCP Facility City],         /* was: hcpfaccity */
    j.hcpfacstate                                AS [HCP Facility State],        /* was: hcpfacstate */
    j.hcpfaczip                                  AS [HCP Facility Zip],          /* was: hcpfaczip */
    j.hcpfacservices                             AS [HCP Treatment Administered], /* was: hcpfacservices */

    /* ── Scope ────────────────────────────────────────────────────── */
    j.orgid                                      AS [Organization],              /* was: orgid */
    j.siteid                                     AS [Site],                      /* was: siteid */

    /* ── Metadata ─────────────────────────────────────────────────── */
    CAST(j.isprimary AS int)                     AS [Is Primary],                /* was: isprimary */
    CAST(j.frommigration AS int)                 AS [Is data from migration],    /* was: frommigration */
    j.hasld                                      AS [Has Long Description],      /* was: hasld */
    j.langcode                                   AS [Language Code]              /* was: langcode */

FROM maximo.PLUSGINJORILL j;
GO
