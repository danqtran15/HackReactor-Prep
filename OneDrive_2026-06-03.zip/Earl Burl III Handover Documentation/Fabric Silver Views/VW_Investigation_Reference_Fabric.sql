-- ═══════════════════════════════════════════════════════════════════════
-- VW_Investigation_Reference  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Note:   Uses CREATE OR ALTER VIEW (if view doesn't exist yet, it creates it;
--         if it does exist, it replaces it).
--
-- ⚠️  DEPLOY ORDER: This view depends on 3 other views.
--     Deploy in this order:
--       1. VW_Investigation_RCFA_Results
--       2. VW_Investigation_Actions
--       3. VW_Investigation
--       4. VW_Investigation_Reference  (this view)
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Investigation_Reference]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Investigation_Reference  –  Denormalized investigation view
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per investigation × RCFA result combination
            (investigations with no RCFA results still appear once)
    Filter: Inherits from VW_Investigation
            (class = 'INVESTIGATION', origrecordclass = 'INCIDENT')
    Sources: VW_Investigation, VW_Investigation_RCFA_Results,
             VW_Investigation_Actions
    Serves : Incidents & Investigations semantic model
            (replaces "Investigations reference" table in semantic model)

    Replaces Power Query merges:
      1. Investigations merged with Rcfaresults on
         Investigation ID = Ticket (LEFT OUTER)
      2. Investigations merged with INV with ACTIONS on
         Ticket PK ID (LEFT OUTER)

    This pre-joins all three views so the semantic model does not
    need to perform these merges in Power Query.
    ═══════════════════════════════════════════════════════════════════ */

SELECT

    -- ── All columns from VW_Investigation ────────────────────────────
    inv.[TICKETUID],
    inv.[Investigation ID],
    inv.[Class],
    inv.[Originating Record ID],
    inv.[Originating Record Class],
    inv.[Ticket PK ID],
    inv.[Originating Record FK ID],
    inv.[Asset FK ID],
    inv.[Location FK ID],
    inv.[Investigation Status],
    inv.[Status Date],
    inv.[Investigation Type],
    inv.[Investigation Required],
    inv.[RCFA Analysis Type],
    inv.[Class Structure ID],
    inv.[Failure Code],
    inv.[Impact],
    inv.[Urgency],
    inv.[Reported Priority],
    inv.[Internal Priority],
    inv.[Summary],
    inv.[Long Description],
    inv.[Report Date],
    inv.[Actual Start],
    inv.[Actual Finish],
    inv.[Change Date],
    inv.[Target Start],
    inv.[Target Finish],
    inv.[Target Contact Date],
    inv.[Actual Contact Date],
    inv.[Reported By],
    inv.[Reported Email],
    inv.[Reported Phone],
    inv.[Owner],
    inv.[Owner Group],
    inv.[Supervisor],
    inv.[Investigation Lead],
    inv.[Investigation Lead Name],
    inv.[RCFA Lead],
    inv.[RCFA Requested By],
    inv.[RCFA Approved By],
    inv.[RCFA Approved],
    inv.[RCFA Actual Date],
    inv.[RCFA Target Date],
    inv.[Root Cause Identified],
    inv.[Analysis Complete],
    inv.[Action Summary],
    inv.[Site],
    inv.[Organization],
    inv.[Location],
    inv.[Asset],
    inv.[GL Account],
    inv.[Facility ID],
    inv.[Asset Site ID],
    inv.[Asset Org ID],
    inv.[Is Investigation],
    inv.[Is Lessons Learned],
    inv.[Mandatory RCA],
    inv.[Mandatory RCFA],
    inv.[Mandatory HF],
    inv.[Incident Type],
    inv.[Incident Context],
    inv.[High Context],
    inv.[Incident Group],
    inv.[Potential Consequence],
    inv.[Potential Consequence ID],
    inv.[Potential Consequence Severity],
    inv.[Actual Consequence],
    inv.[Actual Consequence ID],
    inv.[Actual Consequence Severity],
    inv.[Strategic],
    inv.[Review Required],
    inv.[Affected Person],
    inv.[Affected Email],
    inv.[Affected Phone],
    inv.[Affected Date],
    inv.[Investigation Per Incident],
    inv.[Row Stamp],
    inv.[Fabric Loaded Date],
    inv.[Fabric Loaded By],

    -- ── Columns from VW_Investigation_RCFA_Results ───────────────────
    rcfa.[Description]                                       AS [RCFA Description],
    rcfa.[Cause],
    rcfa.[Cause Type],
    rcfa.[Sequence],

    -- ── Columns from VW_Investigation_Actions ────────────────────────
    act.[Open Actions],
    act.[Closed Actions]

-- ═══════════════════════════════════════════════════════════════════════
-- JOINs
-- ═══════════════════════════════════════════════════════════════════════
FROM [maximo].[VW_Investigation] inv

    -- RCFA Results: 1-to-many (creates multiple rows per investigation)
    LEFT JOIN [maximo].[VW_Investigation_RCFA_Results] rcfa
        ON inv.[Investigation ID] = rcfa.[Ticket]

    -- Actions: 1-to-1 (pre-aggregated open/closed counts)
    LEFT JOIN [maximo].[VW_Investigation_Actions] act
        ON inv.[Ticket PK ID] = act.[Ticket PK ID];
