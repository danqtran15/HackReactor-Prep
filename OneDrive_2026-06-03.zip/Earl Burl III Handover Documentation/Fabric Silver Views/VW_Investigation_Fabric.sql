-- ═══════════════════════════════════════════════════════════════════════
-- VW_Investigation  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Note:   Uses CREATE OR ALTER VIEW (if view doesn't exist yet, it creates it;
--         if it does exist, it replaces it).
-- Deploy: Can be deployed independently (no view dependencies).
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Investigation]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Investigation  –  Core investigations view
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per investigation (latest investigation per incident)
    Filter: class = 'INVESTIGATION', origrecordclass = 'INCIDENT'
    Sources: TICKET, LONGDESCRIPTION, PERSON
    Serves : Incidents & Investigations semantic model
            (replaces "Investigations" table in semantic model)

    Notes:
      - The inv_sub CTE deduplicates to the LATEST investigation per
        incident using MAX(ticketid), matching the original M query.
      - [Investigation Per Incident] counts how many investigations
        exist for each originating incident.
      - ROOTCAUSEANALYSIS values in Investigation Type are replaced
        with 'RCA' to match the existing Power Query transformation.
      - Investigation Lead name is resolved via PERSON join,
        eliminating the need for the User table merge in Power Query.
      - HTML stripping of long description is handled downstream in
        Power Query (consistent with existing Silver view patterns).

    Source M Query (original):
      WITH inv_sub AS (
          SELECT MAX(ticketid), origrecordid, COUNT(origrecordid)
          FROM dbo.problem
          WHERE origrecordclass IS NOT NULL
          GROUP BY origrecordid
      )
      SELECT *, inv_sub.[Investigation Per Incident]
      FROM dbo.problem
          INNER JOIN inv_sub ON inv_sub.subID = problem.ticketid
          LEFT JOIN dbo.longdescription ON ...
      WHERE origrecordclass = 'INCIDENT' AND class = 'INVESTIGATION'
    ═══════════════════════════════════════════════════════════════════ */

WITH

-- ───────────────────────────────────────────────────────────────────
-- CTE 1: Most-recent long description per ticket
-- ───────────────────────────────────────────────────────────────────
ld_ranked AS (
    SELECT
        ld.ldkey,
        ld.ldtext,
        ROW_NUMBER() OVER (
            PARTITION BY ld.ldkey
            ORDER BY ld.longdescriptionid DESC
        ) AS rn
    FROM maximo.LONGDESCRIPTION ld
    WHERE ld.ldownertable = 'TICKET'
),

-- ───────────────────────────────────────────────────────────────────
-- CTE 2: Latest investigation per incident + count
--   MAX(ticketid) → keeps only the latest investigation per incident
--   COUNT(*)      → counts total investigations per incident
-- ───────────────────────────────────────────────────────────────────
inv_sub AS (
    SELECT
        MAX(ticketid)   AS subID,
        origrecordid,
        COUNT(*)        AS [Investigation Per Incident]
    FROM maximo.TICKET
    WHERE UPPER(LTRIM(RTRIM(class))) = 'INVESTIGATION'
        AND origrecordclass IS NOT NULL
    GROUP BY origrecordid
)

-- ═══════════════════════════════════════════════════════════════════════
-- Main SELECT
-- ═══════════════════════════════════════════════════════════════════════
SELECT

    -- ── Section 1: Primary Keys & Identifiers ────────────────────────
    t.ticketuid                                              AS [TICKETUID],
    LTRIM(RTRIM(t.ticketid))                                 AS [Investigation ID],
    t.class                                                  AS [Class],
    LTRIM(RTRIM(t.origrecordid))                             AS [Originating Record ID],
    t.origrecordclass                                        AS [Originating Record Class],

    -- ── Section 2: Composite Keys ────────────────────────────────────
    CONCAT(t.ticketid, '_', t.class)                         AS [Ticket PK ID],
    CONCAT(t.origrecordid, '_', t.origrecordclass)           AS [Originating Record FK ID],
    CONCAT(t.assetnum, '_', t.siteid)                        AS [Asset FK ID],
    CONCAT(t.location, '_', t.siteid)                        AS [Location FK ID],

    -- ── Section 3: Status & Classification ───────────────────────────
    t.status                                                 AS [Investigation Status],
    t.statusdate                                             AS [Status Date],
    CASE
        WHEN UPPER(LTRIM(RTRIM(t.plusginvesttype))) = 'ROOTCAUSEANALYSIS' THEN 'RCA'
        ELSE t.plusginvesttype
    END                                                      AS [Investigation Type],
    t.plusginvestreqd                                         AS [Investigation Required],
    t.plusgrcfaanystype                                       AS [RCFA Analysis Type],
    t.classstructureid                                       AS [Class Structure ID],
    t.failurecode                                            AS [Failure Code],
    t.impact                                                 AS [Impact],
    t.urgency                                                AS [Urgency],
    t.reportedpriority                                       AS [Reported Priority],
    t.internalpriority                                       AS [Internal Priority],

    -- ── Section 4: Description Fields ────────────────────────────────
    t.description                                            AS [Summary],
    CAST(ld.ldtext AS varchar(max))                          AS [Long Description],

    -- ── Section 5: Date Fields ───────────────────────────────────────
    t.reportdate                                             AS [Report Date],
    t.actualstart                                            AS [Actual Start],
    t.actualfinish                                           AS [Actual Finish],
    t.changedate                                             AS [Change Date],
    t.targetstart                                            AS [Target Start],
    t.targetfinish                                           AS [Target Finish],
    t.targetcontactdate                                      AS [Target Contact Date],
    t.actualcontactdate                                      AS [Actual Contact Date],

    -- ── Section 6: Person Fields ─────────────────────────────────────
    t.reportedby                                             AS [Reported By],
    t.reportedemail                                          AS [Reported Email],
    t.reportedphone                                          AS [Reported Phone],
    t.owner                                                  AS [Owner],
    t.ownergroup                                             AS [Owner Group],
    t.supervisor                                             AS [Supervisor],
    t.plusginvestlead                                         AS [Investigation Lead],
    p_lead.displayname                                       AS [Investigation Lead Name],

    -- ── Section 7: RCFA Fields ───────────────────────────────────────
    t.plusgrcfalead                                           AS [RCFA Lead],
    t.plusgrcfareqby                                          AS [RCFA Requested By],
    t.plusgrcfaappby                                          AS [RCFA Approved By],
    t.plusgrcfaapp                                            AS [RCFA Approved],
    t.plusgrcfaactldate                                       AS [RCFA Actual Date],
    t.plusgrcfatargdate                                       AS [RCFA Target Date],
    t.plusgrootcauseiden                                      AS [Root Cause Identified],
    t.plusganalysiscomp                                       AS [Analysis Complete],
    t.plusgactionsumm                                         AS [Action Summary],

    -- ── Section 8: Location & Asset Fields ───────────────────────────
    t.siteid                                                 AS [Site],
    t.orgid                                                  AS [Organization],
    t.location                                               AS [Location],
    t.assetnum                                               AS [Asset],
    t.glaccount                                              AS [GL Account],
    t.facilityid                                             AS [Facility ID],
    t.assetsiteid                                            AS [Asset Site ID],
    t.assetorgid                                             AS [Asset Org ID],

    -- ── Section 9: Investigation-Specific Attributes ─────────────────
    t.plusgisinvestig                                         AS [Is Investigation],
    t.plusgislesslearned                                      AS [Is Lessons Learned],
    t.plusgmanrca                                             AS [Mandatory RCA],
    t.plusgmanrcfa                                            AS [Mandatory RCFA],
    t.plusgmanhf                                              AS [Mandatory HF],
    t.plusginctype                                            AS [Incident Type],
    t.plusginccontext                                         AS [Incident Context],
    t.plusghighcontext                                        AS [High Context],
    t.plusgincidentgroup                                      AS [Incident Group],
    t.plusgpotenconsq                                         AS [Potential Consequence],
    t.plusgpotenconsqid                                       AS [Potential Consequence ID],
    t.plusgpotenconsqsevr                                     AS [Potential Consequence Severity],
    t.plusgactconsq                                           AS [Actual Consequence],
    t.plusgactconsqid                                         AS [Actual Consequence ID],
    t.plusgactconsqsevr                                       AS [Actual Consequence Severity],
    t.plusgstrategic                                          AS [Strategic],
    t.plusgisreviewreqd                                       AS [Review Required],

    -- ── Section 10: Affected Person ──────────────────────────────────
    t.affectedperson                                         AS [Affected Person],
    t.affectedemail                                          AS [Affected Email],
    t.affectedphone                                          AS [Affected Phone],
    t.affecteddate                                           AS [Affected Date],

    -- ── Section 11: Computed: Investigation Per Incident Count ───────
    isub.[Investigation Per Incident],

    -- ── Section 12: Audit ────────────────────────────────────────────
    t.rowstamp                                               AS [Row Stamp],
    t.FABRIC_LOADED_DATE                                     AS [Fabric Loaded Date],
    t.FABRIC_LOADED_BY                                       AS [Fabric Loaded By]

-- ═══════════════════════════════════════════════════════════════════════
-- JOINs
-- ═══════════════════════════════════════════════════════════════════════
FROM maximo.TICKET t
    INNER JOIN inv_sub isub
        ON isub.subID = t.ticketid
    LEFT JOIN ld_ranked ld
        ON ld.ldkey = t.ticketuid
        AND ld.rn  = 1
    LEFT JOIN maximo.PERSON p_lead
        ON p_lead.personid = t.plusginvestlead

-- ═══════════════════════════════════════════════════════════════════════
-- Filters
-- ═══════════════════════════════════════════════════════════════════════
WHERE UPPER(LTRIM(RTRIM(t.origrecordclass))) = 'INCIDENT'
    AND UPPER(LTRIM(RTRIM(t.class)))         = 'INVESTIGATION';
