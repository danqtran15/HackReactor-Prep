-- ═══════════════════════════════════════════════════════════════════════
-- VW_Physical_Security_Attributes  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Grain:  1 row per PHYSICAL SECURITY event (plusginceventid)
-- Filter: plusgincidentgroup = 'PHYSICAL SECURITY'
-- Source: PLUSGINCEVENT + PLUSGINCEVENTSPEC + TICKET
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Physical_Security_Attributes]
AS
SELECT
    pe.ticketuid                                          AS [Ticket UID],
    LTRIM(RTRIM(t.ticketid))                             AS [Incident ID],
    pe.plusginceventid                                    AS [Event UID],
    MAX(CASE WHEN s.assetattrid = 'SECURITY_TYPE'    THEN s.alnvalue END)      AS [Security Type],
    MAX(CASE WHEN s.assetattrid = 'FINANCIAL_IMPACT' THEN s.numvalue END)      AS [Financial Impact],
    MAX(CASE WHEN s.assetattrid = 'FINANCIAL_IMPACT' THEN s.measureunitid END) AS [Financial Impact UoM],
    MAX(CASE WHEN s.assetattrid = 'PROPERTY_CRIME'   THEN s.alnvalue END)      AS [Property Crime]
FROM maximo.PLUSGINCEVENT pe
INNER JOIN maximo.TICKET t
    ON t.ticketuid = pe.ticketuid
LEFT JOIN maximo.PLUSGINCEVENTSPEC s
    ON s.plusginceventid = pe.plusginceventid
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) = 'PHYSICAL SECURITY'
GROUP BY pe.ticketuid, t.ticketid, pe.plusginceventid
