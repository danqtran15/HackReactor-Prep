-- ═══════════════════════════════════════════════════════════════════════
-- VW_Investigation_Actions  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Note:   Uses CREATE OR ALTER VIEW (if view doesn't exist yet, it creates it;
--         if it does exist, it replaces it).
-- Deploy: Can be deployed independently (no view dependencies).
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Investigation_Actions]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Investigation_Actions  –  Pivoted Open/Closed Action Counts
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per investigation
    Filter: class = 'INVESTIGATION'
            origrecordclass = 'INCIDENT'
            relatedrecclass = 'ACTTRACK'
    Sources: TICKET, RELATEDRECORD, WORKORDER
    Serves : Incidents & Investigations semantic model
            (replaces "INV with ACTIONS" table in semantic model)

    Logic:
      - Joins TICKET → RELATEDRECORD → WORKORDER to find action
        tracking work orders linked to each investigation.
      - Classifies work order status as OPEN or CLOSED:
          CLOSED = status IN ('CAN', 'CLOSE', 'COMP')
          OPEN   = all other statuses
      - Pivots counts into [Open Actions] and [Closed Actions] columns.
      - Outputs composite keys matching the semantic model pattern.
    ═══════════════════════════════════════════════════════════════════ */

SELECT
    -- Composite keys (match semantic model pattern)
    CONCAT(t.ticketid, '_', t.class)                         AS [Ticket PK ID],
    CONCAT(t.origrecordid, '_', t.origrecordclass)           AS [Originating Record FK ID],

    -- Investigation identifier
    t.ticketuid                                              AS [TICKETUID],

    -- Pivoted action counts
    SUM(CASE
        WHEN UPPER(LTRIM(RTRIM(wo.status))) NOT IN ('CAN', 'CLOSE', 'COMP')
        THEN 1 ELSE 0
    END)                                                     AS [Open Actions],

    SUM(CASE
        WHEN UPPER(LTRIM(RTRIM(wo.status))) IN ('CAN', 'CLOSE', 'COMP')
        THEN 1 ELSE 0
    END)                                                     AS [Closed Actions]

FROM maximo.TICKET t
    INNER JOIN maximo.RELATEDRECORD rr
        ON  t.ticketid = rr.recordkey
        AND t.class    = rr.class
    INNER JOIN maximo.WORKORDER wo
        ON  rr.relatedreckey    = wo.wonum
        AND rr.relatedrecclass  = wo.woclass
        AND rr.relatedrecsiteid = wo.siteid
WHERE UPPER(LTRIM(RTRIM(t.origrecordclass))) = 'INCIDENT'
    AND UPPER(LTRIM(RTRIM(t.class)))           = 'INVESTIGATION'
    AND UPPER(LTRIM(RTRIM(rr.relatedrecclass)))= 'ACTTRACK'
GROUP BY
    t.ticketid,
    t.class,
    t.origrecordid,
    t.origrecordclass,
    t.ticketuid;
