# VW_Incident + Attribute Views — Validation Test Summary

Run each test individually in the Fabric SQL query editor against LH_Silver.

---

## VW_Incident Tests

| Test | Name | Why | Pass Criteria |
|------|------|-----|---------------|
| 1 | Grain check | The view is designed as 1 row per incident (ticketuid). Duplicates would cause double-counting in reports and break relationships to attribute views. | 0 rows |
| 2 | Row count vs source | VW_Incident should contain every incident in TICKET ⟕ INCIDENT with no filter. A mismatch means the JOINs or CTEs are dropping or duplicating rows. | Both counts equal |
| 3 | Flags are 0 or 1 | Category flags are consumed as booleans in Power BI. Any value outside 0/1 (e.g., NULL, 2) would break SUM-based category counts in the semantic model. | 0 rows |
| 4 | Every incident has ≥1 flag | Every incident should belong to at least one category. Rows with all-zero flags indicate events with unrecognized `plusgincidentgroup` values (e.g., NEARMISS, which we intentionally don't flag — those are expected). | 0 rows (NEARMISS rows are expected) |
| 5 | Flag → text alignment | If a category flag is 1, the `[Incident Category]` STRING_AGG text must contain that category name. A mismatch means the flag CTE and the STRING_AGG CTE are using different filter values (this is exactly the INJURYILLNESS bug we caught). | 0 rows |
| 6 | Text → flag alignment | The reverse of Test 5. If the STRING_AGG text contains a category name, the corresponding flag must be 1. Catches cases where STRING_AGG picks up a value the flag CTE misses. | 0 rows |
| 7 | Multi-category spot check | Confirms that STRING_AGG correctly concatenates multiple categories with semicolons. This is the core SME requirement — one row per incident showing all categories. | Returns rows with ";" in Incident Category |
| 8 | Column renames | The SME requested `[Actual Finish]` → `[Resolved Date]` and `[Asset Site Combined]` → `[Asset PK]`. This confirms the new names exist and return data. | Returns rows with non-null values |
| 9 | Tri Level Category | This derived column maps tri_level (1, 2, 3) to business labels. Verifies the CASE expression logic matches the documented mapping: 1=Non Reportable, 2/3=Reportable, NULL=Unknown. | 0 rows |
| 10 | Level Description | Similar to Test 9 but for the more detailed label (e.g., "Level 2 - Reportable"). Verifies that CASE expression separately since it has different output values. | 0 rows |
| 11 | Removed columns | The SME removed 60+ columns (specs, OSHA, outcomes, GIS, etc.). Uncomment each SELECT individually — a successful query means the column was NOT removed and the view needs fixing. | Each query should ERROR |

---

## Attribute View Tests

| Test | Name | Why | Pass Criteria |
|------|------|-----|---------------|
| 12 | Attribute grain check | Each attribute view should have 1 row per event (plusginceventid). Duplicates would mean the GROUP BY isn't working or the JOIN to PLUSGINCEVENTSPEC is fanning out. | 0 rows |
| 13 | Row counts | Basic sanity check that all 7 views have data. A zero-row view could mean the WHERE filter value is wrong (e.g., the INJURYILLNESS vs INJURY/ILLNESS bug). | All counts > 0 |
| 14 | Filter correctness | Joins each attribute view back to the source PLUSGINCEVENT table and verifies every row actually belongs to the correct `plusgincidentgroup`. Catches typos in WHERE clauses. | 0 rows |

---

## Cross-View Integrity Tests

| Test | Name | Why | Pass Criteria |
|------|------|-----|---------------|
| 15 | Flag=1 → attr exists | If VW_Incident says an incident is Transportation (flag=1), there should be at least one row in VW_Transportation_Attributes. A missing row means the attribute view is filtering differently than the flag CTE. | 0 rows |
| 16 | No orphan attributes | Every attribute row should have a parent in VW_Incident. Orphans would mean VW_Incident is missing incidents that PLUSGINCEVENT has — likely a JOIN issue in VW_Incident. | 0 rows |
| 17 | Attr count = source count | Compares each attribute view's row count against a direct COUNT from PLUSGINCEVENT for that category. If they don't match, the view is either dropping events (JOIN issue) or creating extras (fan-out). | attr_rows = source_rows |

---

## SME Spot-Check Tests

| Test | Name | Why | Pass Criteria |
|------|------|-----|---------------|
| 18 | Incident 10007 | The SME specifically cited this incident as having two ENVIRONMENTAL events with different release types (VAPOR, ACID GAS and VAPOR, RESIDUE GAS). Confirms the event-grain design handles multi-event incidents correctly. | 2+ rows with different Release Types |
| 19 | Incident 10150 | The SME cited this as a multi-category incident (TRANSPORTATION + INJURY/ILLNESS). Confirms the incident appears in VW_Incident with both categories and has rows in both attribute views. | 3 rows: 1 incident + 1 transport + 1 injury |
| 20 | Distinct group values | Discovery query — shows all `plusgincidentgroup` values actually present in the data. Use this to verify our known list is complete and watch for unexpected or misspelled values. | Shows known categories + counts |
