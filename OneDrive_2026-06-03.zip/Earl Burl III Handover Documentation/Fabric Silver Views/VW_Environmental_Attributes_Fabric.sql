-- ═══════════════════════════════════════════════════════════════════════
-- VW_Environmental_Attributes  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Grain:  1 row per ENVIRONMENTAL event (plusginceventid)
-- Filter: plusgincidentgroup = 'ENVIRONMENTAL'
-- Source: PLUSGINCEVENT + PLUSGINCEVENTSPEC + TICKET
-- Note:   One incident may have multiple ENVIRONMENTAL events
--         (e.g., incident 10007 has two for different release types)
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Environmental_Attributes]
AS
SELECT
    pe.ticketuid                                          AS [Ticket UID],
    LTRIM(RTRIM(t.ticketid))                             AS [Incident ID],
    pe.plusginceventid                                    AS [Event UID],

    -- Spec attributes pivoted per event
    MAX(CASE WHEN s.assetattrid = 'RELEASE_TYPE'    THEN s.alnvalue END)       AS [Release Type],
    MAX(CASE WHEN s.assetattrid = 'RELEASE_QTY'     THEN s.numvalue END)       AS [Release Quantity],
    MAX(CASE WHEN s.assetattrid = 'RELEASE_QTY'     THEN s.measureunitid END)  AS [Release Quantity UoM],
    MAX(CASE WHEN s.assetattrid = 'FLARED_RELEASE'  THEN s.alnvalue END)       AS [Flared Release],
    MAX(CASE WHEN s.assetattrid = 'DURATION'        THEN s.numvalue END)       AS [Duration],
    MAX(CASE WHEN s.assetattrid = 'DURATION'        THEN s.measureunitid END)  AS [Duration UoM],
    MAX(CASE WHEN s.assetattrid = 'PIPELINE_LEAK'   THEN s.alnvalue END)       AS [Pipeline Leak],
    MAX(CASE WHEN s.assetattrid = 'LEAK_NOTICE_SOUR' THEN s.alnvalue END)      AS [Leak Notice Source],
    MAX(CASE WHEN s.assetattrid = 'HIPO'            THEN s.alnvalue END)       AS [High Potential],
    TRY_CAST(MAX(CASE WHEN s.assetattrid = 'RELEASE_STOPTIME' THEN s.alnvalue END) AS datetime2) AS [Release Stop Time]

FROM maximo.PLUSGINCEVENT pe
INNER JOIN maximo.TICKET t
    ON t.ticketuid = pe.ticketuid
LEFT JOIN maximo.PLUSGINCEVENTSPEC s
    ON s.plusginceventid = pe.plusginceventid
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) = 'ENVIRONMENTAL'
GROUP BY
    pe.ticketuid,
    t.ticketid,
    pe.plusginceventid
