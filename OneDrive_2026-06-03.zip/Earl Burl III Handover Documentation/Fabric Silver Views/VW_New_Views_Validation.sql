-- ═══════════════════════════════════════════════════════════════════════
-- Validation Test Cases — VW_Incident + 6 Attribute Views
-- ═══════════════════════════════════════════════════════════════════════
-- Target:   LH_Silver SQL Analytics Endpoint
-- Created:  2026-05-19
-- Usage:    Run each test individually in Fabric SQL query editor.
--           Tests expecting "0 rows" pass when the result set is empty.
--           Tests marked "informational" return data for review.
--
-- Known plusgincidentgroup values (confirmed from data):
--   TRANSPORTATION, INJURY/ILLNESS, ENVIRONMENTAL, DAMAGE,
--   PHYSICAL SECURITY, FIRE/IGNITION, NEARMISS
-- ═══════════════════════════════════════════════════════════════════════


-- ─────────────────────────────────────────────────────────────────────
-- VW_INCIDENT TESTS
-- ─────────────────────────────────────────────────────────────────────

-- TEST 1: Grain — no duplicate ticketuids
-- Expected: 0 rows
SELECT [Ticket UID], COUNT(*) AS cnt
FROM maximo.VW_Incident
GROUP BY [Ticket UID]
HAVING COUNT(*) > 1;


-- TEST 2: Row count matches source (TICKET ⟕ INCIDENT)
-- Expected: Both counts equal
SELECT
    (SELECT COUNT(*) FROM maximo.VW_Incident) AS vw_rows,
    (SELECT COUNT(*)
     FROM maximo.TICKET t
     INNER JOIN maximo.INCIDENT i ON i.ticketuid = t.ticketuid) AS source_rows;


-- TEST 3: Category flags are 0 or 1 only
-- Expected: 0 rows
SELECT [Ticket UID]
FROM maximo.VW_Incident
WHERE [Category Transportation]     NOT IN (0, 1)
   OR [Category Injury Or Illness]   NOT IN (0, 1)
   OR [Category Environmental]       NOT IN (0, 1)
   OR [Category Property Damage]     NOT IN (0, 1)
   OR [Category Physical Security]   NOT IN (0, 1)
   OR [Category Fire Or Ignition]    NOT IN (0, 1);


-- TEST 4: Every incident has at least one category flag = 1
-- Expected: 0 rows
-- NOTE: Rows here could indicate events with NULL/blank/unknown group values
SELECT [Ticket UID], [Incident ID], [Incident Category]
FROM maximo.VW_Incident
WHERE COALESCE([Category Transportation], 0)     = 0
  AND COALESCE([Category Injury Or Illness], 0)   = 0
  AND COALESCE([Category Environmental], 0)       = 0
  AND COALESCE([Category Property Damage], 0)     = 0
  AND COALESCE([Category Physical Security], 0)   = 0
  AND COALESCE([Category Fire Or Ignition], 0)    = 0;


-- TEST 5: [Incident Category] STRING_AGG aligns with boolean flags
-- Expected: 0 rows
SELECT [Ticket UID], [Incident Category],
       [Category Transportation], [Category Injury Or Illness],
       [Category Environmental], [Category Property Damage],
       [Category Physical Security], [Category Fire Or Ignition]
FROM maximo.VW_Incident
WHERE ([Category Transportation]     = 1 AND [Incident Category] NOT LIKE '%TRANSPORTATION%')
   OR ([Category Injury Or Illness]   = 1 AND [Incident Category] NOT LIKE '%INJURY/ILLNESS%')
   OR ([Category Environmental]       = 1 AND [Incident Category] NOT LIKE '%ENVIRONMENTAL%')
   OR ([Category Property Damage]     = 1 AND [Incident Category] NOT LIKE '%DAMAGE%')
   OR ([Category Physical Security]   = 1 AND [Incident Category] NOT LIKE '%PHYSICAL SECURITY%')
   OR ([Category Fire Or Ignition]    = 1 AND [Incident Category] NOT LIKE '%FIRE%');


-- TEST 6: Reverse check — STRING_AGG text implies flag should be 1
-- Expected: 0 rows
SELECT [Ticket UID], [Incident Category],
       [Category Transportation], [Category Injury Or Illness],
       [Category Environmental], [Category Property Damage],
       [Category Physical Security], [Category Fire Or Ignition]
FROM maximo.VW_Incident
WHERE ([Incident Category] LIKE '%TRANSPORTATION%'    AND COALESCE([Category Transportation], 0)   = 0)
   OR ([Incident Category] LIKE '%INJURY/ILLNESS%'    AND COALESCE([Category Injury Or Illness], 0) = 0)
   OR ([Incident Category] LIKE '%ENVIRONMENTAL%'     AND COALESCE([Category Environmental], 0)    = 0)
   OR ([Incident Category] LIKE '%PHYSICAL SECURITY%' AND COALESCE([Category Physical Security], 0) = 0)
   OR ([Incident Category] LIKE '%FIRE%'              AND COALESCE([Category Fire Or Ignition], 0) = 0);


-- TEST 7: Multi-category incidents exist (informational)
-- Expected: Returns rows — verify STRING_AGG shows semicolon-separated values
SELECT TOP 20 [Incident ID], [Incident Category],
       [Category Transportation], [Category Injury Or Illness],
       [Category Environmental], [Category Property Damage],
       [Category Physical Security], [Category Fire Or Ignition]
FROM maximo.VW_Incident
WHERE [Incident Category] LIKE '%;%'
ORDER BY [Incident ID];


-- TEST 8: Column renames exist and have data
-- Expected: Returns rows with non-null values
SELECT TOP 5
    [Resolved Date],    -- renamed from [Actual Finish]
    [Asset PK]          -- renamed from [Asset Site Combined]
FROM maximo.VW_Incident
WHERE [Resolved Date] IS NOT NULL;


-- TEST 9: [Tri Level Category] derivation correctness
-- Expected: 0 rows
SELECT [Ticket UID], [Level], [Tri Level Category]
FROM maximo.VW_Incident
WHERE ([Level] = '1'       AND [Tri Level Category] <> 'Non Reportable')
   OR ([Level] IN ('2','3') AND [Tri Level Category] <> 'Reportable')
   OR ([Level] IS NULL      AND [Tri Level Category] <> 'Unknown');


-- TEST 10: [Incident Level Description] derivation correctness
-- Expected: 0 rows
SELECT [Ticket UID], [Level], [Incident Level Description]
FROM maximo.VW_Incident
WHERE ([Level] = '1' AND [Incident Level Description] <> 'Level 1 - Non Reportable')
   OR ([Level] = '2' AND [Incident Level Description] <> 'Level 2 - Reportable')
   OR ([Level] = '3' AND [Incident Level Description] <> 'Level 3 - Significant')
   OR ([Level] IS NULL AND [Incident Level Description] <> 'Unknown');


-- TEST 11: Removed columns should NOT exist
-- Expected: Each query should FAIL with "Invalid column name" — that means PASS
-- Run individually; if it succeeds, the column was not properly removed.
-- SELECT [Service Request Type]       FROM maximo.VW_Incident;
-- SELECT [Assigned Owner Group]       FROM maximo.VW_Incident;
-- SELECT [Asset Site]                 FROM maximo.VW_Incident;
-- SELECT [Fire Response]              FROM maximo.VW_Incident;
-- SELECT [Has Fatality]               FROM maximo.VW_Incident;
-- SELECT [OSHA Recordable Injuries]   FROM maximo.VW_Incident;
-- SELECT [Class Pipeline]             FROM maximo.VW_Incident;
-- SELECT [Class Near Miss]            FROM maximo.VW_Incident;
-- SELECT [Targa Or Contractor]        FROM maximo.VW_Incident;


-- ─────────────────────────────────────────────────────────────────────
-- ATTRIBUTE VIEW TESTS
-- ─────────────────────────────────────────────────────────────────────

-- TEST 12: Attribute views — grain check (no duplicate Event UIDs)
-- Expected: 0 rows
SELECT 'Environmental'     AS [View], [Event UID], COUNT(*) AS cnt FROM maximo.VW_Environmental_Attributes     GROUP BY [Event UID] HAVING COUNT(*) > 1
UNION ALL
SELECT 'Property Damage',             [Event UID], COUNT(*)        FROM maximo.VW_Property_Damage_Attributes   GROUP BY [Event UID] HAVING COUNT(*) > 1
UNION ALL
SELECT 'Fire Ignition',               [Event UID], COUNT(*)        FROM maximo.VW_Fire_Ignition_Attributes     GROUP BY [Event UID] HAVING COUNT(*) > 1
UNION ALL
SELECT 'Injury Illness',              [Event UID], COUNT(*)        FROM maximo.VW_Injury_Illness_Attributes    GROUP BY [Event UID] HAVING COUNT(*) > 1
UNION ALL
SELECT 'Physical Security',           [Event UID], COUNT(*)        FROM maximo.VW_Physical_Security_Attributes GROUP BY [Event UID] HAVING COUNT(*) > 1
UNION ALL
SELECT 'Transportation',              [Event UID], COUNT(*)        FROM maximo.VW_Transportation_Attributes    GROUP BY [Event UID] HAVING COUNT(*) > 1;


-- TEST 13: Row counts across all views (informational)
-- Expected: All non-zero
SELECT 'VW_Incident'                      AS [View], COUNT(*) AS [Rows] FROM maximo.VW_Incident
UNION ALL SELECT 'VW_Environmental_Attributes',     COUNT(*) FROM maximo.VW_Environmental_Attributes
UNION ALL SELECT 'VW_Property_Damage_Attributes',   COUNT(*) FROM maximo.VW_Property_Damage_Attributes
UNION ALL SELECT 'VW_Fire_Ignition_Attributes',     COUNT(*) FROM maximo.VW_Fire_Ignition_Attributes
UNION ALL SELECT 'VW_Injury_Illness_Attributes',    COUNT(*) FROM maximo.VW_Injury_Illness_Attributes
UNION ALL SELECT 'VW_Physical_Security_Attributes', COUNT(*) FROM maximo.VW_Physical_Security_Attributes
UNION ALL SELECT 'VW_Transportation_Attributes',    COUNT(*) FROM maximo.VW_Transportation_Attributes;


-- TEST 14: Attribute view filter correctness
-- Expected: 0 rows (every event in each view matches its expected group)
SELECT 'Environmental wrong group'     AS issue, a.[Event UID], pe.plusgincidentgroup
FROM maximo.VW_Environmental_Attributes a
INNER JOIN maximo.PLUSGINCEVENT pe ON pe.plusginceventid = a.[Event UID]
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) <> 'ENVIRONMENTAL'
UNION ALL
SELECT 'Property Damage wrong group', a.[Event UID], pe.plusgincidentgroup
FROM maximo.VW_Property_Damage_Attributes a
INNER JOIN maximo.PLUSGINCEVENT pe ON pe.plusginceventid = a.[Event UID]
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) <> 'DAMAGE'
UNION ALL
SELECT 'Fire/Ignition wrong group', a.[Event UID], pe.plusgincidentgroup
FROM maximo.VW_Fire_Ignition_Attributes a
INNER JOIN maximo.PLUSGINCEVENT pe ON pe.plusginceventid = a.[Event UID]
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) NOT LIKE 'FIRE%'
UNION ALL
SELECT 'Injury/Illness wrong group', a.[Event UID], pe.plusgincidentgroup
FROM maximo.VW_Injury_Illness_Attributes a
INNER JOIN maximo.PLUSGINCEVENT pe ON pe.plusginceventid = a.[Event UID]
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) <> 'INJURY/ILLNESS'
UNION ALL
SELECT 'Physical Security wrong group', a.[Event UID], pe.plusgincidentgroup
FROM maximo.VW_Physical_Security_Attributes a
INNER JOIN maximo.PLUSGINCEVENT pe ON pe.plusginceventid = a.[Event UID]
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) <> 'PHYSICAL SECURITY'
UNION ALL
SELECT 'Transportation wrong group', a.[Event UID], pe.plusgincidentgroup
FROM maximo.VW_Transportation_Attributes a
INNER JOIN maximo.PLUSGINCEVENT pe ON pe.plusginceventid = a.[Event UID]
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) <> 'TRANSPORTATION';


-- ─────────────────────────────────────────────────────────────────────
-- CROSS-VIEW INTEGRITY TESTS
-- ─────────────────────────────────────────────────────────────────────

-- TEST 15: Category flag=1 → at least one attribute row exists
-- Expected: 0 rows
SELECT 'Transportation missing'    AS issue, i.[Ticket UID], i.[Incident ID]
FROM maximo.VW_Incident i
WHERE i.[Category Transportation] = 1
  AND NOT EXISTS (SELECT 1 FROM maximo.VW_Transportation_Attributes a WHERE a.[Ticket UID] = i.[Ticket UID])
UNION ALL
SELECT 'Environmental missing', i.[Ticket UID], i.[Incident ID]
FROM maximo.VW_Incident i
WHERE i.[Category Environmental] = 1
  AND NOT EXISTS (SELECT 1 FROM maximo.VW_Environmental_Attributes a WHERE a.[Ticket UID] = i.[Ticket UID])
UNION ALL
SELECT 'Injury/Illness missing', i.[Ticket UID], i.[Incident ID]
FROM maximo.VW_Incident i
WHERE i.[Category Injury Or Illness] = 1
  AND NOT EXISTS (SELECT 1 FROM maximo.VW_Injury_Illness_Attributes a WHERE a.[Ticket UID] = i.[Ticket UID])
UNION ALL
SELECT 'Property Damage missing', i.[Ticket UID], i.[Incident ID]
FROM maximo.VW_Incident i
WHERE i.[Category Property Damage] = 1
  AND NOT EXISTS (SELECT 1 FROM maximo.VW_Property_Damage_Attributes a WHERE a.[Ticket UID] = i.[Ticket UID])
UNION ALL
SELECT 'Physical Security missing', i.[Ticket UID], i.[Incident ID]
FROM maximo.VW_Incident i
WHERE i.[Category Physical Security] = 1
  AND NOT EXISTS (SELECT 1 FROM maximo.VW_Physical_Security_Attributes a WHERE a.[Ticket UID] = i.[Ticket UID])
UNION ALL
SELECT 'Fire/Ignition missing', i.[Ticket UID], i.[Incident ID]
FROM maximo.VW_Incident i
WHERE i.[Category Fire Or Ignition] = 1
  AND NOT EXISTS (SELECT 1 FROM maximo.VW_Fire_Ignition_Attributes a WHERE a.[Ticket UID] = i.[Ticket UID]);


-- TEST 16: No orphan attribute rows (every attribute row has a parent incident)
-- Expected: 0 rows
SELECT 'Transportation orphan'    AS issue, a.[Ticket UID], a.[Incident ID]
FROM maximo.VW_Transportation_Attributes a
WHERE NOT EXISTS (SELECT 1 FROM maximo.VW_Incident i WHERE i.[Ticket UID] = a.[Ticket UID])
UNION ALL
SELECT 'Environmental orphan', a.[Ticket UID], a.[Incident ID]
FROM maximo.VW_Environmental_Attributes a
WHERE NOT EXISTS (SELECT 1 FROM maximo.VW_Incident i WHERE i.[Ticket UID] = a.[Ticket UID])
UNION ALL
SELECT 'Injury/Illness orphan', a.[Ticket UID], a.[Incident ID]
FROM maximo.VW_Injury_Illness_Attributes a
WHERE NOT EXISTS (SELECT 1 FROM maximo.VW_Incident i WHERE i.[Ticket UID] = a.[Ticket UID])
UNION ALL
SELECT 'Property Damage orphan', a.[Ticket UID], a.[Incident ID]
FROM maximo.VW_Property_Damage_Attributes a
WHERE NOT EXISTS (SELECT 1 FROM maximo.VW_Incident i WHERE i.[Ticket UID] = a.[Ticket UID])
UNION ALL
SELECT 'Physical Security orphan', a.[Ticket UID], a.[Incident ID]
FROM maximo.VW_Physical_Security_Attributes a
WHERE NOT EXISTS (SELECT 1 FROM maximo.VW_Incident i WHERE i.[Ticket UID] = a.[Ticket UID])
UNION ALL
SELECT 'Fire/Ignition orphan', a.[Ticket UID], a.[Incident ID]
FROM maximo.VW_Fire_Ignition_Attributes a
WHERE NOT EXISTS (SELECT 1 FROM maximo.VW_Incident i WHERE i.[Ticket UID] = a.[Ticket UID]);


-- TEST 17: Attribute row count ≤ source event count per category
-- Expected: attr_rows = source_rows for each category
SELECT
    'Environmental'     AS category,
    (SELECT COUNT(*) FROM maximo.VW_Environmental_Attributes)     AS attr_rows,
    (SELECT COUNT(*) FROM maximo.PLUSGINCEVENT WHERE UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'ENVIRONMENTAL') AS source_rows
UNION ALL SELECT
    'Property Damage',
    (SELECT COUNT(*) FROM maximo.VW_Property_Damage_Attributes),
    (SELECT COUNT(*) FROM maximo.PLUSGINCEVENT WHERE UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'DAMAGE')
UNION ALL SELECT
    'Fire/Ignition',
    (SELECT COUNT(*) FROM maximo.VW_Fire_Ignition_Attributes),
    (SELECT COUNT(*) FROM maximo.PLUSGINCEVENT WHERE UPPER(LTRIM(RTRIM(plusgincidentgroup))) LIKE 'FIRE%')
UNION ALL SELECT
    'Injury/Illness',
    (SELECT COUNT(*) FROM maximo.VW_Injury_Illness_Attributes),
    (SELECT COUNT(*) FROM maximo.PLUSGINCEVENT WHERE UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'INJURY/ILLNESS')
UNION ALL SELECT
    'Physical Security',
    (SELECT COUNT(*) FROM maximo.VW_Physical_Security_Attributes),
    (SELECT COUNT(*) FROM maximo.PLUSGINCEVENT WHERE UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'PHYSICAL SECURITY')
UNION ALL SELECT
    'Transportation',
    (SELECT COUNT(*) FROM maximo.VW_Transportation_Attributes),
    (SELECT COUNT(*) FROM maximo.PLUSGINCEVENT WHERE UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'TRANSPORTATION');


-- ─────────────────────────────────────────────────────────────────────
-- SME SPOT-CHECK TESTS
-- ─────────────────────────────────────────────────────────────────────

-- TEST 18: Incident 10007 — multi-event environmental (SME example)
-- Expected: 2+ rows with different release types
SELECT [Incident ID], [Event UID], [Release Type], [Release Quantity], [High Potential]
FROM maximo.VW_Environmental_Attributes
WHERE [Incident ID] = '10007'
ORDER BY [Event UID];


-- TEST 19: Incident 10150 — multi-category (SME example)
-- Expected: VW_Incident shows "INJURY/ILLNESS; TRANSPORTATION",
--           rows in both Transportation and Injury/Illness attribute views
SELECT 'VW_Incident'      AS [Source], [Incident Category] AS [Detail], NULL AS [Event UID]
FROM maximo.VW_Incident WHERE [Incident ID] = '10150'
UNION ALL
SELECT 'Transportation',   [MVA Type],                       CAST([Event UID] AS varchar(50))
FROM maximo.VW_Transportation_Attributes WHERE [Incident ID] = '10150'
UNION ALL
SELECT 'Injury/Illness',   [Injury Type],                    CAST([Event UID] AS varchar(50))
FROM maximo.VW_Injury_Illness_Attributes WHERE [Incident ID] = '10150';


-- TEST 20: Distinct plusgincidentgroup values in data (informational)
-- Expected: Confirms known category values; watch for unexpected entries
SELECT plusgincidentgroup, COUNT(*) AS event_count
FROM maximo.PLUSGINCEVENT
GROUP BY plusgincidentgroup
ORDER BY plusgincidentgroup;


-- ═══════════════════════════════════════════════════════════════════════
-- END OF VALIDATION — 20 TESTS
-- ═══════════════════════════════════════════════════════════════════════
