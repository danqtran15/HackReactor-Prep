-- ═══════════════════════════════════════════════════════════════════════
-- VW_Investigation_RCFA_Results  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Note:   Uses CREATE OR ALTER VIEW (if view doesn't exist yet, it creates it;
--         if it does exist, it replaces it).
-- Deploy: Can be deployed independently (no view dependencies).
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Investigation_RCFA_Results]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Investigation_RCFA_Results  –  Root Cause Failure Analysis Results
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per RCFA result entry
    Filter: None — includes all RCFA results
    Source: PLUSGRCFARESULTS
    Serves: Incidents & Investigations semantic model
           (replaces "Rcfaresults" table in semantic model)

    Notes:
      - ROOTCAUSEANALYSIS values in Cause Type are replaced with 'RCA'
        to match the existing Power Query transformation.
      - Joins to VW_Investigation on [Ticket] = [Investigation ID].
    ═══════════════════════════════════════════════════════════════════ */

SELECT
    r.plusgrcfaresultsid                                     AS [Unique ID],
    LTRIM(RTRIM(r.ticketid))                                 AS [Ticket],
    r.cause                                                  AS [Cause],
    r.description                                            AS [Description],
    CASE
        WHEN UPPER(LTRIM(RTRIM(r.causetype))) = 'ROOTCAUSEANALYSIS' THEN 'RCA'
        ELSE r.causetype
    END                                                      AS [Cause Type],
    r.causepriority                                           AS [Priority],
    r.impreqd                                                AS [Improvement Required],
    r.actionreqd                                             AS [Action Required],
    r.causeowner                                              AS [Cause Owner],
    r.remedy                                                  AS [Remedy],
    r.causeagreed                                             AS [Cause Agreed],
    r.causeagreedby                                           AS [Cause Agreed By],
    r.solution                                                AS [Solution],
    r.evidence                                                AS [Evidence],
    r.tri_seq                                                 AS [Sequence],

    -- Audit
    r.FABRIC_LOADED_DATE                                      AS [Fabric Loaded Date],
    r.FABRIC_LOADED_BY                                        AS [Fabric Loaded By]

FROM maximo.PLUSGRCFARESULTS r;
