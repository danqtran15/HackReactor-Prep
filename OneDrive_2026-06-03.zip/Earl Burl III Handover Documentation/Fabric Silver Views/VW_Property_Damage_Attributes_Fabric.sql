-- ═══════════════════════════════════════════════════════════════════════
-- VW_Property_Damage_Attributes  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Grain:  1 row per DAMAGE event (plusginceventid)
-- Filter: plusgincidentgroup = 'DAMAGE'
-- Source: PLUSGINCEVENT + PLUSGINCEVENTSPEC + TICKET
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Property_Damage_Attributes]
AS
SELECT
    pe.ticketuid                                          AS [Ticket UID],
    LTRIM(RTRIM(t.ticketid))                             AS [Incident ID],
    pe.plusginceventid                                    AS [Event UID],
    MAX(CASE WHEN s.assetattrid = 'DAMAGE_AMOUNT'  THEN s.numvalue END)      AS [Damage Amount],
    MAX(CASE WHEN s.assetattrid = 'DAMAGE_AMOUNT'  THEN s.measureunitid END) AS [Damage Amount UoM],
    MAX(CASE WHEN s.assetattrid = 'DAMAGE_TYPE'    THEN s.alnvalue END)      AS [Damage Type],
    MAX(CASE WHEN s.assetattrid = 'CLAIM_NO'       THEN s.alnvalue END)      AS [Claim Number],
    MAX(CASE WHEN s.assetattrid = 'HIPO'           THEN s.alnvalue END)      AS [High Potential]
FROM maximo.PLUSGINCEVENT pe
INNER JOIN maximo.TICKET t
    ON t.ticketuid = pe.ticketuid
LEFT JOIN maximo.PLUSGINCEVENTSPEC s
    ON s.plusginceventid = pe.plusginceventid
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) = 'DAMAGE'
GROUP BY pe.ticketuid, t.ticketid, pe.plusginceventid
