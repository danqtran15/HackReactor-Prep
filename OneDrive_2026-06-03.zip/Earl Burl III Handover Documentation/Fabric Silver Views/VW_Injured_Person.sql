SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Injured_Person  –  SQL Server Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: On-premises / Azure SQL with Maximo schema
-- ═══════════════════════════════════════════════════════════════════════

CREATE VIEW [maximo].[VW_Injured_Person]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Injured_Person  –  Incident person bridge/context
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per person per incident (ticketid + plusgincpersonid)
    Sources: PLUSGINCPERSON
    Serves : ES&H Incident Semantic Model (Injured Person table),
             bridge between Incidents → Injuries → Outcome
    Note  : Exposes person/role/contact columns only.
             Injury detail fields are in VW_Injury_Detail.
    ═══════════════════════════════════════════════════════════════════ */

SELECT
    /* ── Keys / Identifiers ───────────────────────────────────────── */
    p.ticketid                                   AS [Ticket],                    /* was: ticketid */
    p.plusgincpersonid                            AS [Incident Person Id],        /* was: plusgincpersonid */
    p.personid                                   AS [Person ID],                 /* was: personid */
    p.personimpacted                             AS [Person Impacted],           /* was: personimpacted */

    /* ── Composite join keys (ES&H model compatibility) ───────────── */
    CAST(p.ticketid + N'|' + CAST(p.plusgincpersonid AS nvarchar(20)) AS nvarchar(200))
                                                 AS [tckt_prsn_joinid],          /* ES&H join key */

    /* ── Person Details ───────────────────────────────────────────── */
    p.title                                      AS [Title],                     /* was: title */
    p.gender                                     AS [Gender],                    /* was: gender */
    p.dob                                        AS [Date of Birth],             /* was: dob */
    p.dateofhire                                 AS [Date of Hire],              /* was: dateofhire */

    /* ── Role & Relationship ──────────────────────────────────────── */
    p.personrole                                 AS [Person Role],               /* was: personrole */
    p.personroledesc                             AS [Person Role Description],   /* was: personroledesc */

    /* ── External Person ──────────────────────────────────────────── */
    p.extperson                                  AS [Is External Person],        /* was: extperson */
    p.externalperson                             AS [External Person],           /* was: externalperson */
    p.externalpersonrole                         AS [External Person Role],      /* was: externalpersonrole */
    p.extpersonrelationship                      AS [External Person Relationship], /* was: extpersonrelationship */

    /* ── Company ──────────────────────────────────────────────────── */
    p.company                                    AS [Company],                   /* was: company */
    p.companiesid                                AS [Companies ID],              /* was: companiesid */
    p.companyphone                               AS [Company Phone],             /* was: companyphone */
    p.companyext                                 AS [Company Extension],         /* was: companyext */

    /* ── Contact Information ──────────────────────────────────────── */
    p.phone                                      AS [Phone],                     /* was: phone */
    p.email                                      AS [Email],                     /* was: email */
    p.externalphone                              AS [External Phone],            /* was: externalphone */
    p.externalemail                              AS [External Email],            /* was: externalemail */
    p.externalcomment                            AS [External Comment],          /* was: externalcomment */

    /* ── Address ──────────────────────────────────────────────────── */
    p.street                                     AS [Street],                    /* was: street */
    p.city                                       AS [City],                      /* was: city */
    p.state                                      AS [State],                     /* was: state */
    p.zip                                        AS [Zip],                       /* was: zip */

    /* ── Follow-up ────────────────────────────────────────────────── */
    p.followupreqd                               AS [Follow Up Required],        /* was: followupreqd */
    p.followupaction                             AS [Follow Up Action],          /* was: followupaction */
    p.owner                                      AS [Owner],                     /* was: owner */
    p.ownergroup                                 AS [Owner Group],               /* was: ownergroup */

    /* ── Scope ────────────────────────────────────────────────────── */
    p.orgid                                      AS [Organization],              /* was: orgid */
    p.siteid                                     AS [Site],                      /* was: siteid */

    /* ── Sequence / Migration ─────────────────────────────────────── */
    p.tri_sequence                               AS [Sequence],                  /* was: tri_sequence */
    p.injdatamigrated                            AS [Injury Data Migrated],      /* was: injdatamigrated */
    p.outcomedatamigrated                        AS [Outcome Data Migrated]      /* was: outcomedatamigrated */

FROM maximo.PLUSGINCPERSON p;
GO
