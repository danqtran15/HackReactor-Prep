SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Classification  –  SQL Server Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: On-premises / Azure SQL with Maximo schema
-- ═══════════════════════════════════════════════════════════════════════

CREATE VIEW [maximo].[VW_Classification]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Classification  –  Classification hierarchy dimension
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per class structure node (classstructureid)
    Sources: CLASSSTRUCTURE (hierarchy), CLASSIFICATION (descriptions)
    Serves : SM_Maximo Classification dimension, ES&H Incident views
    ═══════════════════════════════════════════════════════════════════ */

WITH class_hierarchy AS (
    /* Recursive CTE: walk from root nodes down to leaves */

    /* Anchor: root nodes (no parent) */
    SELECT
        cs.classstructureid,
        cs.classificationid,
        cs.parent,
        cs.description                          AS node_description,
        cs.orgid,
        cs.siteid,
        cs.type,
        cs.haschildren,
        cs.classstructureuid,
        cs.sortorder,
        cs.tri_blowdownreqd,
        CAST(cs.classificationid AS nvarchar(max))  AS hierarchy_path,
        0                                           AS hierarchy_level
    FROM maximo.CLASSSTRUCTURE cs
    WHERE cs.parent IS NULL
       OR LTRIM(RTRIM(cs.parent)) = ''

    UNION ALL

    /* Recursive: children joined to their parent */
    SELECT
        child.classstructureid,
        child.classificationid,
        child.parent,
        child.description                       AS node_description,
        child.orgid,
        child.siteid,
        child.type,
        child.haschildren,
        child.classstructureuid,
        child.sortorder,
        child.tri_blowdownreqd,
        CAST(h.hierarchy_path + N' / ' + child.classificationid AS nvarchar(max)),
        h.hierarchy_level + 1
    FROM maximo.CLASSSTRUCTURE child
    INNER JOIN class_hierarchy h
        ON child.parent = h.classstructureid
    WHERE child.parent IS NOT NULL
      AND LTRIM(RTRIM(child.parent)) <> ''
),

parent_lookup AS (
    /* Get parent classification ID for denormalization */
    SELECT
        cs.classstructureid,
        cs.classificationid AS parent_classification_id
    FROM maximo.CLASSSTRUCTURE cs
)

/* ═══════════════════════════════════════════════════════════════════════
   FINAL SELECT — 1 row per class structure node
   ═══════════════════════════════════════════════════════════════════════ */
SELECT
    /* ── Identifiers ──────────────────────────────────────────────── */
    h.classstructureid                           AS [Class Structure ID],       /* was: classstructureid */
    h.classificationid                           AS [Classification ID],        /* was: classificationid */
    h.classstructureuid                          AS [Class Structure UID],      /* was: classstructureuid */

    /* ── Descriptions ─────────────────────────────────────────────── */
    h.node_description                           AS [Classification Description],       /* was: description (CLASSSTRUCTURE) */
    c.description                                AS [Classification Description (Long)], /* was: description (CLASSIFICATION) */

    /* ── Hierarchy ────────────────────────────────────────────────── */
    h.parent                                     AS [Parent Class Structure ID], /* was: parent */
    pl.parent_classification_id                  AS [Parent Classification ID],  /* was: derived */
    h.hierarchy_path                             AS [Classification Hierarchy Path], /* was: derived recursive */
    h.hierarchy_level                            AS [Hierarchy Level],           /* was: derived recursive */
    h.haschildren                                AS [Has Children],              /* was: haschildren */

    /* ── Scope ────────────────────────────────────────────────────── */
    h.orgid                                      AS [Org ID],                    /* was: orgid */
    h.siteid                                     AS [Site ID],                   /* was: siteid */
    h.type                                       AS [Type],                      /* was: type */

    /* ── Metadata ─────────────────────────────────────────────────── */
    h.sortorder                                  AS [Sort Order],                /* was: sortorder */
    h.tri_blowdownreqd                           AS [Blowdown Required]          /* was: tri_blowdownreqd */

FROM class_hierarchy h
LEFT JOIN maximo.CLASSIFICATION c
    ON c.classificationid = h.classificationid
LEFT JOIN parent_lookup pl
    ON pl.classstructureid = h.parent;
GO
