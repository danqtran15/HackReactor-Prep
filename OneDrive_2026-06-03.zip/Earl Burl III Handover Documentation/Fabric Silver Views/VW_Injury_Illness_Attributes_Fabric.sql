-- ═══════════════════════════════════════════════════════════════════════
-- VW_Injury_Illness_Attributes  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Grain:  1 row per INJURY/ILLNESS event (plusginceventid)
-- Filter: plusgincidentgroup = 'INJURY/ILLNESS'
-- Source: PLUSGINCEVENT + PLUSGINCEVENTSPEC + TICKET
-- Note:   This view contains non-restricted injury data only.
--         Person-level injury details are in VW_Injury_Detail.
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Injury_Illness_Attributes]
AS
SELECT
    pe.ticketuid                                          AS [Ticket UID],
    LTRIM(RTRIM(t.ticketid))                             AS [Incident ID],
    pe.plusginceventid                                    AS [Event UID],
    MAX(CASE WHEN s.assetattrid = 'REG_INJ'        THEN s.alnvalue END)  AS [Regulated Injury],
    MAX(CASE WHEN s.assetattrid = 'HR_LOCATION'    THEN s.alnvalue END)  AS [HR Location],
    MAX(CASE WHEN s.assetattrid = 'INJ_TYPE'       THEN s.alnvalue END)  AS [Injury Type],
    MAX(CASE WHEN s.assetattrid = 'CLAIM_NO'       THEN s.alnvalue END)  AS [Claim Number],
    MAX(CASE WHEN s.assetattrid = 'HIPO'           THEN s.alnvalue END)  AS [High Potential]
FROM maximo.PLUSGINCEVENT pe
INNER JOIN maximo.TICKET t
    ON t.ticketuid = pe.ticketuid
LEFT JOIN maximo.PLUSGINCEVENTSPEC s
    ON s.plusginceventid = pe.plusginceventid
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) = 'INJURY/ILLNESS'
GROUP BY pe.ticketuid, t.ticketid, pe.plusginceventid
