-- ═══════════════════════════════════════════════════════════════════════
-- VW_Transportation_Attributes  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Grain:  1 row per TRANSPORTATION event (plusginceventid)
-- Filter: plusgincidentgroup = 'TRANSPORTATION'
-- Source: PLUSGINCEVENT + PLUSGINCEVENTSPEC + TICKET
-- Note:   HAZARDOUS_RELEAS attribute excluded pending data verification.
--         Add later if confirmed to exist in PLUSGINCEVENTSPEC.
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Transportation_Attributes]
AS
SELECT
    pe.ticketuid                                          AS [Ticket UID],
    LTRIM(RTRIM(t.ticketid))                             AS [Incident ID],
    pe.plusginceventid                                    AS [Event UID],
    MAX(CASE WHEN s.assetattrid = 'MVA_TYPE'       THEN s.alnvalue END)  AS [MVA Type],
    MAX(CASE WHEN s.assetattrid = 'MVA_DOT_TYPE'   THEN s.alnvalue END)  AS [MVA DOT Type],
    MAX(CASE WHEN s.assetattrid = 'VEHICLE_NO'     THEN s.alnvalue END)  AS [Vehicle Number],
    MAX(CASE WHEN s.assetattrid = 'HIPO'           THEN s.alnvalue END)  AS [High Potential],
    MAX(CASE WHEN s.assetattrid = 'MVA_SOS'        THEN s.alnvalue END)  AS [MVA SOS],
    MAX(CASE WHEN s.assetattrid = 'MVA_CAT'        THEN s.alnvalue END)  AS [MVA Category],
    MAX(CASE WHEN s.assetattrid = 'TRI_DRIVER'     THEN s.alnvalue END)  AS [Driver]
FROM maximo.PLUSGINCEVENT pe
INNER JOIN maximo.TICKET t
    ON t.ticketuid = pe.ticketuid
LEFT JOIN maximo.PLUSGINCEVENTSPEC s
    ON s.plusginceventid = pe.plusginceventid
WHERE UPPER(LTRIM(RTRIM(pe.plusgincidentgroup))) = 'TRANSPORTATION'
GROUP BY pe.ticketuid, t.ticketid, pe.plusginceventid
