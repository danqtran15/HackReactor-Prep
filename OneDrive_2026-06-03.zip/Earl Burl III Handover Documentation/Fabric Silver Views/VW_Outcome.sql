SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Outcome  –  SQL Server Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: On-premises / Azure SQL with Maximo schema
-- ═══════════════════════════════════════════════════════════════════════

CREATE VIEW [maximo].[VW_Outcome]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Outcome  –  Injury/illness outcome tracking
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per outcome per injury per person per incident
    Sources: PLUSGOUTCOME
    Serves : ES&H Incident Semantic Model (Outcome table),
             OSHA days-away/restricted/transfer tracking
    Joins  : → VW_Injury_Detail via [tckt_prson_inj_joinid]
             → VW_Injured_Person via [tckt_prsn_joinid]
    ═══════════════════════════════════════════════════════════════════ */

WITH outcome_ranked AS (
    /*  Rank outcomes per injury by severity for "most serious" derivation.
        Ranking: FATALITY > LOSTTIME > RESTRICTED > FIRSTAID > OTHER
        Also rank per incident for incident-level "worst outcome".  */
    SELECT
        o.*,

        /* Outcome severity rank within the SAME injury */
        ROW_NUMBER() OVER (
            PARTITION BY o.ticketid, o.plusgincpersonid, o.injorillid
            ORDER BY
                CASE UPPER(LTRIM(RTRIM(o.outcome)))
                    WHEN 'FATALITY'   THEN 1
                    WHEN 'LOSTTIME'   THEN 2
                    WHEN 'RESTRICTED' THEN 3
                    WHEN 'MEDICAL'    THEN 4
                    WHEN 'FIRSTAID'   THEN 5
                    ELSE 6
                END ASC,
                o.outcomebegin DESC
        ) AS outcome_rank,

        /* Worst outcome rank across entire incident (all persons, all injuries) */
        ROW_NUMBER() OVER (
            PARTITION BY o.ticketid
            ORDER BY
                CASE UPPER(LTRIM(RTRIM(o.outcome)))
                    WHEN 'FATALITY'   THEN 1
                    WHEN 'LOSTTIME'   THEN 2
                    WHEN 'RESTRICTED' THEN 3
                    WHEN 'MEDICAL'    THEN 4
                    WHEN 'FIRSTAID'   THEN 5
                    ELSE 6
                END ASC,
                o.outcomebegin DESC
        ) AS incident_rank

    FROM maximo.PLUSGOUTCOME o
)

/* ═══════════════════════════════════════════════════════════════════════
   FINAL SELECT — 1 row per outcome record
   ═══════════════════════════════════════════════════════════════════════ */
SELECT
    /* ── Keys / Identifiers ───────────────────────────────────────── */
    r.ticketid                                   AS [Ticket],                    /* was: ticketid */
    r.personid                                   AS [Person Impacted],           /* was: personid */
    r.plusgincpersonid                            AS [Incident Person Id],        /* was: plusgincpersonid */
    r.injorillid                                 AS [Illness or Injury],         /* was: injorillid */
    r.plusgoutcomeid                              AS [Unique Id],                 /* was: plusgoutcomeid */

    /* ── Composite join keys (ES&H model compatibility) ───────────── */
    CAST(r.ticketid + N'|' + CAST(r.plusgincpersonid AS nvarchar(20)) AS nvarchar(200))
                                                 AS [tckt_prsn_joinid],          /* FK → Injured Person */
    CAST(r.ticketid + N'|' + CAST(r.plusgincpersonid AS nvarchar(20)) + N'|' + CAST(r.injorillid AS nvarchar(20)) AS nvarchar(300))
                                                 AS [tckt_prson_inj_joinid],     /* FK → Injury Detail */

    /* ── Outcome Details ──────────────────────────────────────────── */
    r.outcome                                    AS [Outcome],                   /* was: outcome */
    r.dod                                        AS [Date of Death],             /* was: dod */
    r.outcomebegin                               AS [Start Date],                /* was: outcomebegin */
    r.outcomeend                                 AS [End Date],                  /* was: outcomeend */
    r.injorilldays                               AS [Days Absent/Transferred/Restricted], /* was: injorilldays */
    r.trnsrestrctdetails                         AS [Transfer/Restriction Details], /* was: trnsrestrctdetails */
    CAST(r.mostserious AS int)                   AS [Most Serious Outcome],      /* was: mostserious */

    /* ── Rankings ─────────────────────────────────────────────────── */
    r.outcome_rank                               AS [Outcome Rank],              /* derived: severity within injury */
    r.incident_rank                              AS [Incident Rank],             /* derived: severity within incident */

    /* ── Scope ────────────────────────────────────────────────────── */
    r.orgid                                      AS [Organization],              /* was: orgid */
    r.siteid                                     AS [Site],                      /* was: siteid */

    /* ── Metadata ─────────────────────────────────────────────────── */
    CAST(r.frommigration AS int)                 AS [Is data from migration],    /* was: frommigration */
    r.hasld                                      AS [Has Long Description]       /* was: hasld */

FROM outcome_ranked r;
GO
