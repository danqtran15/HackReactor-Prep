-- ═══════════════════════════════════════════════════════════════════════
-- VW_Incident  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Note:   Uses CREATE OR ALTER VIEW (if view doesn't exist yet, it creates it;
--         if it does exist, it replaces it).
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Incident]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Incident  –  Unified incident view (all categories)
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per incident (ticketuid)
    Filter: NONE — includes all incidents regardless of category
    Sources: TICKET, INCIDENT, LONGDESCRIPTION, PLUSGINCEVENT
    Serves : ES&H Incident Semantic Model (unified fact table)
    
    Replaces: VW_Safety_Incident (which filtered to non-environmental only)
    
    NOTE: Category-specific attributes (specs) are NOT included here.
          They live in separate attribute views:
          - VW_Environmental_Attributes
          - VW_Property_Damage_Attributes
          - VW_Fire_Ignition_Attributes
          - VW_Injury_Illness_Attributes
          - VW_Physical_Security_Attributes
          - VW_Transportation_Attributes
    ═══════════════════════════════════════════════════════════════════ */

WITH

-- ───────────────────────────────────────────────────────────────────
-- CTE 1: Most-recent long description per ticket
-- ───────────────────────────────────────────────────────────────────
ld_ranked AS (
    SELECT
        ld.ldkey,
        ld.ldtext,
        ROW_NUMBER() OVER (PARTITION BY ld.ldkey ORDER BY ld.longdescriptionid DESC) AS rn
    FROM maximo.LONGDESCRIPTION ld
    WHERE ld.ldownertable = 'TICKET'
),

-- ───────────────────────────────────────────────────────────────────
-- CTE 2: Pick primary event for event-level fields
-- ───────────────────────────────────────────────────────────────────
primary_event AS (
    SELECT *,
        ROW_NUMBER() OVER (PARTITION BY ticketuid ORDER BY isprimary DESC, plusginceventid ASC) AS rn
    FROM maximo.PLUSGINCEVENT
),

-- ───────────────────────────────────────────────────────────────────
-- CTE 3: STRING_AGG of distinct event groups per incident
-- ───────────────────────────────────────────────────────────────────
incident_category AS (
    SELECT
        ticketuid,
        STRING_AGG(plusgincidentgroup, '; ') WITHIN GROUP (ORDER BY plusgincidentgroup) AS incident_category_list
    FROM (
        SELECT DISTINCT ticketuid, plusgincidentgroup
        FROM maximo.PLUSGINCEVENT
    ) sub
    GROUP BY ticketuid
),

-- ───────────────────────────────────────────────────────────────────
-- CTE 4: Boolean flags derived from event incident group
-- ───────────────────────────────────────────────────────────────────
category_flags AS (
    SELECT
        ticketuid,
        MAX(CASE WHEN UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'TRANSPORTATION'    THEN 1 ELSE 0 END) AS cat_transportation,
        MAX(CASE WHEN UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'INJURY/ILLNESS'     THEN 1 ELSE 0 END) AS cat_injury_illness,
        MAX(CASE WHEN UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'ENVIRONMENTAL'      THEN 1 ELSE 0 END) AS cat_environmental,
        MAX(CASE WHEN UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'DAMAGE'             THEN 1 ELSE 0 END) AS cat_property_damage,
        MAX(CASE WHEN UPPER(LTRIM(RTRIM(plusgincidentgroup))) = 'PHYSICAL SECURITY'  THEN 1 ELSE 0 END) AS cat_physical_security,
        MAX(CASE WHEN UPPER(LTRIM(RTRIM(plusgincidentgroup))) LIKE 'FIRE%'           THEN 1 ELSE 0 END) AS cat_fire_ignition
    FROM maximo.PLUSGINCEVENT
    GROUP BY ticketuid
)

-- ═══════════════════════════════════════════════════════════════════════
-- Main SELECT
-- ═══════════════════════════════════════════════════════════════════════
SELECT

    -- Section 1: Base columns
    t.ticketuid                                     AS [Ticket UID],
    LTRIM(RTRIM(t.ticketid))                        AS [Incident ID],
    t.class                                         AS [Ticket Class],
    t.status                                        AS [Status],
    t.statusdate                                    AS [Status Date],
    t.tri_level                                     AS [Level],
    CASE
        WHEN t.tri_level IS NULL OR LTRIM(RTRIM(t.tri_level)) = '' THEN 'Unknown'
        WHEN t.tri_level = '1' THEN 'Non Reportable'
        WHEN t.tri_level IN ('2','3') THEN 'Reportable'
        ELSE 'Unknown'
    END                                             AS [Tri Level Category],
    t.reportdate                                    AS [Reported Date],
    t.tri_incstart                                  AS [Incident Start Time],
    t.actualfinish                                  AS [Resolved Date],
    t.changedate                                    AS [Change Date],
    t.reportedby                                    AS [Reported By],
    t.owner                                         AS [Owner],
    t.supervisor                                    AS [Supervisor],
    t.plusginvestlead                                AS [Investigation Lead],
    t.tri_respparty                                 AS [Responsible Party],
    t.vendor                                        AS [Vendor],
    t.assetnum                                      AS [Asset],
    t.siteid                                        AS [Site],
    t.orgid                                         AS [Organization],
    t.location                                      AS [Location],
    CONCAT(t.assetnum, '_', t.siteid)               AS [Asset PK],
    t.description                                   AS [Summary],
    CAST(ld.ldtext AS varchar(max))                 AS [Long Summary],
    t.tri_3rdparty                                  AS [3rd Party Impacts],
    t.tri_offsite                                   AS [Offsite Impacts],
    t.tri_psm                                       AS [PSM/RMP],
    CONCAT(
        'https://maximo.targaresources.com/maximo/ui/maximo.jsp?event=loadapp&value=plusginc&uniqueid=',
        CAST(t.ticketuid AS varchar(50))
    )                                               AS [URL],
    t.rowstamp                                      AS [Row Stamp],
    t.FABRIC_LOADED_DATE                            AS [Fabric Loaded Date],
    t.FABRIC_LOADED_BY                              AS [Fabric Loaded By],

    -- Section 2: Incident Category (from CTEs)
    ic.incident_category_list                       AS [Incident Category],

    -- Section 3: Event fields (from primary event)
    pe.classstructureid                             AS [Event Class Structure],
    pe.description                                  AS [Event Description],
    CONCAT(
        CAST(pe.plusginceventid AS varchar(100)),
        '^',
        COALESCE(CAST(pe.classstructureid AS varchar(100)), '')
    )                                               AS [Event Custom],

    -- Section 4: Category boolean flags
    cf.cat_transportation                           AS [Category Transportation],
    cf.cat_injury_illness                           AS [Category Injury Or Illness],
    cf.cat_environmental                            AS [Category Environmental],
    cf.cat_property_damage                          AS [Category Property Damage],
    cf.cat_physical_security                        AS [Category Physical Security],
    cf.cat_fire_ignition                            AS [Category Fire Or Ignition],

    -- Section 5: Incident Level Description
    CASE
        WHEN t.tri_level IS NULL OR LTRIM(RTRIM(t.tri_level)) = '' THEN 'Unknown'
        WHEN t.tri_level = '1' THEN 'Level 1 - Non Reportable'
        WHEN t.tri_level = '2' THEN 'Level 2 - Reportable'
        WHEN t.tri_level = '3' THEN 'Level 3 - Significant'
        ELSE 'Unknown'
    END                                             AS [Incident Level Description]

-- ═══════════════════════════════════════════════════════════════════════
-- JOINs
-- ═══════════════════════════════════════════════════════════════════════
FROM maximo.TICKET t
    INNER JOIN maximo.INCIDENT i        ON i.ticketuid  = t.ticketuid
    LEFT  JOIN primary_event pe         ON pe.ticketuid = t.ticketuid AND pe.rn = 1
    LEFT  JOIN ld_ranked ld             ON ld.ldkey     = t.ticketuid AND ld.rn = 1
    LEFT  JOIN incident_category ic     ON ic.ticketuid = t.ticketuid
    LEFT  JOIN category_flags cf        ON cf.ticketuid = t.ticketuid;
