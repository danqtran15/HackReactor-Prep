-- filepath: c:\Users\EBU667\OneDrive - Targa Resources\fabric-semantic-docs\VW_Injury_and_Illness_Detail_Fabric.sql
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Injury_and_Illness_Detail  –  Fabric-Ready Version (v2 – SME review 2026-05-20)
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Changes: Renamed view VW_Injury_Detail → VW_Injury_and_Illness_Detail.
--          Renamed Ticket→Incident ID, Injury Cause→Injury Mode. Added Ticket UID.
--          Fixed 3 blank description fields via LONGDESCRIPTION join.
--          Removed Person Impacted (PII), Location, Org, Site, HCP Administered.
-- Prior:  To drop the old view name, run:
--           DROP VIEW IF EXISTS [maximo].[VW_Injury_Detail];
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Injury_and_Illness_Detail]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Injury_and_Illness_Detail  –  Injury/illness detail per person
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per injury/illness (ticketid + plusgincpersonid + injorillid)
    Sources: PLUSGINJORILL, TICKET (for ticketuid),
             LONGDESCRIPTION (for description text fields)
    Serves : ES&H Incident Semantic Model (Injuries table),
             OSHA recordable tracking, Injury analytics
    Joins  : → VW_Injured_Person via [tckt_prsn_joinid]
             → VW_Outcome via [tckt_prson_inj_joinid]
    Note  : Person Impacted removed — get PII from VW_Injured_Person only.
    ═══════════════════════════════════════════════════════════════════ */

WITH ld_injury AS (
    /* Most-recent long description per injury record per field.
       LONGDESCRIPTION stores rich-text for 3 PLUSGINJORILL columns:
         JUSTBEFORE    → Description of Employee Actions
         INJORILLDESC  → Details of Injury or Illness
         OBJSUBS       → Details of Harmful Object or Substance
       Base columns on PLUSGINJORILL are NULL; actual text is here. */
    SELECT
        ld.ldkey,
        ld.ldownercol,
        CAST(ld.ldtext AS varchar(max)) AS ldtext,
        ROW_NUMBER() OVER (
            PARTITION BY ld.ldkey, ld.ldownercol
            ORDER BY ld.longdescriptionid DESC
        ) AS rn
    FROM maximo.LONGDESCRIPTION ld
    WHERE ld.ldownertable = 'PLUSGINJORILL'
      AND ld.ldownercol IN ('JUSTBEFORE', 'INJORILLDESC', 'OBJSUBS')
)

/* ═══════════════════════════════════════════════════════════════════════
   FINAL SELECT — 1 row per injury/illness record
   ═══════════════════════════════════════════════════════════════════════ */
SELECT
    /* ── Keys / Identifiers ───────────────────────────────────────── */
    j.ticketid                                   AS [Incident ID],              /* renamed from [Ticket] */
    t.ticketuid                                  AS [Ticket UID],               /* added: preferred join key */
    j.plusgincpersonid                            AS [Incident Person Id],
    j.injorillid                                 AS [Illness or Injury],
    j.plusginjorillid                             AS [Unique Id],

    /* ── Composite join keys (ES&H model compatibility) ───────────── */
    CAST(j.ticketid + '|' + CAST(j.plusgincpersonid AS varchar(20)) AS varchar(200))
                                                 AS [tckt_prsn_joinid],          /* FK → Injured Person */
    CAST(j.ticketid + '|' + CAST(j.plusgincpersonid AS varchar(20)) + '|' + CAST(j.injorillid AS varchar(20)) AS varchar(300))
                                                 AS [tckt_prson_inj_joinid],     /* PK for Outcome join */

    /* ── Reportable / Classification ──────────────────────────────── */
    CAST(j.rptable AS int)                       AS [Reportable Injury or Illness],

    /* ── Timing ───────────────────────────────────────────────────── */
    j.injorilldate                               AS [Injury or Onset of Illness],
    j.timecannotbd                               AS [Unknown Time],
    j.empbeganwork                               AS [Time Employee Started Work],

    /* ── Description (from LONGDESCRIPTION; may contain HTML) ─────── */
    ld_jb.ldtext                                 AS [Description of Employee Actions],
    ld_desc.ldtext                               AS [Details of Injury or Illness],
    ld_obj.ldtext                                AS [Details of Harmful Object or Substance],

    /* ── Injury Type Flags ────────────────────────────────────────── */
    CAST(j.injury AS int)                        AS [Injury],
    CAST(j.skindisorder AS int)                  AS [Skin Disorder],
    CAST(j.respiratory AS int)                   AS [Respiratory Condition],
    CAST(j.poisoning AS int)                     AS [Poisoning],
    CAST(j.hearingloss AS int)                   AS [Hearing Loss],
    CAST(j.allother AS int)                      AS [Other],

    /* ── Cause & Body Part ────────────────────────────────────────── */
    j.injorilltype                               AS [Injury Mode],              /* renamed from [Injury Cause] per Maximo UI */
    j.injorillbodypart                           AS [Impacted Body Part],

    /* ── Healthcare Provider ──────────────────────────────────────── */
    j.hcpname                                    AS [Physician/HCP Name],
    j.hcpphone                                   AS [Physician/HCP Phone],
    j.hcpemail                                   AS [Physician/HCP Email],
    j.hcpfacility                                AS [HCP Treatment Facility],
    j.hcpfacaddress                              AS [HCP Facility Street Address],
    j.hcpfaccity                                 AS [HCP Facility City],
    j.hcpfacstate                                AS [HCP Facility State],
    j.hcpfaczip                                  AS [HCP Facility Zip],

    /* ── Metadata ─────────────────────────────────────────────────── */
    CAST(j.isprimary AS int)                     AS [Is Primary],
    CAST(j.frommigration AS int)                 AS [Is data from migration],
    j.hasld                                      AS [Has Long Description],
    j.langcode                                   AS [Language Code],

    /* ── Audit ────────────────────────────────────────────────────── */
    j.FABRIC_LOADED_DATE                         AS [Fabric Loaded Date],
    j.FABRIC_LOADED_BY                           AS [Fabric Loaded By]

FROM maximo.PLUSGINJORILL j
LEFT JOIN maximo.TICKET t        ON t.ticketid = j.ticketid AND t.class = 'INCIDENT'
LEFT JOIN ld_injury ld_jb    ON ld_jb.ldkey   = j.plusginjorillid AND ld_jb.ldownercol   = 'JUSTBEFORE'    AND ld_jb.rn   = 1
LEFT JOIN ld_injury ld_desc      ON ld_desc.ldkey  = j.plusginjorillid AND ld_desc.ldownercol  = 'INJORILLDESC' AND ld_desc.rn  = 1
LEFT JOIN ld_injury ld_obj       ON ld_obj.ldkey   = j.plusginjorillid AND ld_obj.ldownercol   = 'OBJSUBS'      AND ld_obj.rn   = 1;
