-- filepath: c:\Users\EBU667\OneDrive - Targa Resources\fabric-semantic-docs\VW_Classification_Fabric.sql
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Classification  –  Fabric-Ready Version
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Classification]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Classification  –  Classification hierarchy dimension
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per class structure node (classstructureid)
    Sources: CLASSSTRUCTURE (hierarchy), CLASSIFICATION (descriptions)
    Serves : SM_Maximo Classification dimension, ES&H Incident views

    Note  : Fabric SQL Analytics Endpoint does not support recursive CTEs.
            Hierarchy is walked via iterative self-joins (supports up to
            5 levels deep, which covers all known Maximo classification
            trees like INCIDENT / SAFETY / MVA).
    ═══════════════════════════════════════════════════════════════════ */

/* ═══════════════════════════════════════════════════════════════════════
   FINAL SELECT — 1 row per class structure node
   Uses iterative LEFT JOINs to walk up the parent chain and build
   the hierarchy path by concatenating ancestor classificationids.
   ═══════════════════════════════════════════════════════════════════ */
SELECT
    /* ── Identifiers ──────────────────────────────────────────────── */
    cs.classstructureid                          AS [Class Structure ID],       /* was: classstructureid */
    cs.classificationid                          AS [Classification ID],        /* was: classificationid */
    cs.classstructureuid                         AS [Class Structure UID],      /* was: classstructureuid */

    /* ── Descriptions ─────────────────────────────────────────────── */
    cs.description                               AS [Classification Description],       /* was: description (CLASSSTRUCTURE) */
    cl.description                               AS [Classification Description (Long)], /* was: description (CLASSIFICATION) */

    /* ── Hierarchy ────────────────────────────────────────────────── */
    cs.parent                                    AS [Parent Class Structure ID], /* was: parent */
    p1.classificationid                          AS [Parent Classification ID],  /* was: derived */

    /* Build path: walk up ancestors and concatenate (root / … / leaf) */
    CASE
        WHEN p5.classificationid IS NOT NULL
            THEN p5.classificationid + ' / ' + p4.classificationid + ' / ' + p3.classificationid + ' / ' + p2.classificationid + ' / ' + p1.classificationid + ' / ' + cs.classificationid
        WHEN p4.classificationid IS NOT NULL
            THEN p4.classificationid + ' / ' + p3.classificationid + ' / ' + p2.classificationid + ' / ' + p1.classificationid + ' / ' + cs.classificationid
        WHEN p3.classificationid IS NOT NULL
            THEN p3.classificationid + ' / ' + p2.classificationid + ' / ' + p1.classificationid + ' / ' + cs.classificationid
        WHEN p2.classificationid IS NOT NULL
            THEN p2.classificationid + ' / ' + p1.classificationid + ' / ' + cs.classificationid
        WHEN p1.classificationid IS NOT NULL
            THEN p1.classificationid + ' / ' + cs.classificationid
        ELSE cs.classificationid
    END                                          AS [Classification Hierarchy Path], /* was: derived iterative */

    /* Hierarchy depth: count non-null ancestors */
    CASE
        WHEN p5.classificationid IS NOT NULL THEN 5
        WHEN p4.classificationid IS NOT NULL THEN 4
        WHEN p3.classificationid IS NOT NULL THEN 3
        WHEN p2.classificationid IS NOT NULL THEN 2
        WHEN p1.classificationid IS NOT NULL THEN 1
        ELSE 0
    END                                          AS [Hierarchy Level],           /* was: derived iterative */

    cs.haschildren                               AS [Has Children],              /* was: haschildren */

    /* ── Scope ────────────────────────────────────────────────────── */
    cs.orgid                                     AS [Org ID],                    /* was: orgid */
    cs.siteid                                    AS [Site ID],                   /* was: siteid */
    cs.type                                      AS [Type],                      /* was: type */

    /* ── Metadata ─────────────────────────────────────────────────── */
    cs.sortorder                                 AS [Sort Order],                /* was: sortorder */
    cs.tri_blowdownreqd                          AS [Blowdown Required],         /* was: tri_blowdownreqd */

    /* ── Audit ────────────────────────────────────────────────────── */
    cs.FABRIC_LOADED_DATE                        AS [Fabric Loaded Date],        /* was: FABRIC_LOADED_DATE */
    cs.FABRIC_LOADED_BY                          AS [Fabric Loaded By]           /* was: FABRIC_LOADED_BY */

FROM maximo.CLASSSTRUCTURE cs

/* Walk up parent chain — up to 5 levels */
LEFT JOIN maximo.CLASSSTRUCTURE p1
    ON p1.classstructureid = cs.parent
   AND cs.parent IS NOT NULL
   AND LTRIM(RTRIM(cs.parent)) <> ''
LEFT JOIN maximo.CLASSSTRUCTURE p2
    ON p2.classstructureid = p1.parent
   AND p1.parent IS NOT NULL
   AND LTRIM(RTRIM(p1.parent)) <> ''
LEFT JOIN maximo.CLASSSTRUCTURE p3
    ON p3.classstructureid = p2.parent
   AND p2.parent IS NOT NULL
   AND LTRIM(RTRIM(p2.parent)) <> ''
LEFT JOIN maximo.CLASSSTRUCTURE p4
    ON p4.classstructureid = p3.parent
   AND p3.parent IS NOT NULL
   AND LTRIM(RTRIM(p3.parent)) <> ''
LEFT JOIN maximo.CLASSSTRUCTURE p5
    ON p5.classstructureid = p4.parent
   AND p4.parent IS NOT NULL
   AND LTRIM(RTRIM(p4.parent)) <> ''

/* Classification long description */
LEFT JOIN maximo.CLASSIFICATION cl
    ON cl.classificationid = cs.classificationid;
