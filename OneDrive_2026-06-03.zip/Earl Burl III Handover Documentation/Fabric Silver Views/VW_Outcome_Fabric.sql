-- filepath: c:\Users\EBU667\OneDrive - Targa Resources\fabric-semantic-docs\VW_Outcome_Fabric.sql
-- ═══════════════════════════════════════════════════════════════════════
-- VW_Outcome  –  Fabric-Ready Version (v2 – SME review 2026-05-20)
-- ═══════════════════════════════════════════════════════════════════════
-- Target: DEV - Fabric Data → LH_Silver SQL Analytics Endpoint
-- Usage:  Paste this entire script into the Fabric SQL query editor
-- Changes: Renamed Ticket→Incident ID. Added Ticket UID.
--          Fixed blank Transfer/Restriction Details via LONGDESCRIPTION join.
--          Removed Person Impacted (PII), Organization, Site.
-- ═══════════════════════════════════════════════════════════════════════

CREATE OR ALTER VIEW [maximo].[VW_Outcome]
AS
/*  ═══════════════════════════════════════════════════════════════════
    VW_Outcome  –  Injury/illness outcome tracking
    ─────────────────────────────────────────────────────────────────
    Grain : 1 row per outcome per injury per person per incident
    Sources: PLUSGOUTCOME, TICKET (for ticketuid),
             LONGDESCRIPTION (for transfer/restriction details text)
    Serves : ES&H Incident Semantic Model (Outcome table),
             OSHA days-away/restricted/transfer tracking
    Joins  : → VW_Injury_and_Illness_Detail via [tckt_prson_inj_joinid]
             → VW_Injured_Person via [tckt_prsn_joinid]
    Note  : Person Impacted removed — get PII from VW_Injured_Person only.
    ═══════════════════════════════════════════════════════════════════ */

WITH ld_outcome AS (
    /* Most-recent long description for transfer/restriction details.
       Base column on PLUSGOUTCOME is NULL; actual text is here. */
    SELECT
        ld.ldkey,
        CAST(ld.ldtext AS varchar(max)) AS ldtext,
        ROW_NUMBER() OVER (
            PARTITION BY ld.ldkey
            ORDER BY ld.longdescriptionid DESC
        ) AS rn
    FROM maximo.LONGDESCRIPTION ld
    WHERE ld.ldownertable = 'PLUSGOUTCOME'
      AND ld.ldownercol = 'TRNSRESTRCTDETAILS'
),

outcome_ranked AS (
    /*  Rank outcomes per injury by severity for "most serious" derivation.
        Ranking: FATALITY > LOSTTIME > RESTRICTED > MEDICAL > FIRSTAID > OTHER
        Also rank per incident for incident-level "worst outcome".  */
    SELECT
        o.*,

        /* Outcome severity rank within the SAME injury */
        ROW_NUMBER() OVER (
            PARTITION BY o.ticketid, o.plusgincpersonid, o.injorillid
            ORDER BY
                CASE UPPER(LTRIM(RTRIM(o.outcome)))
                    WHEN 'FATALITY'   THEN 1
                    WHEN 'LOSTTIME'   THEN 2
                    WHEN 'RESTRICTED' THEN 3
                    WHEN 'MEDICAL'    THEN 4
                    WHEN 'FIRSTAID'   THEN 5
                    ELSE 6
                END ASC,
                o.outcomebegin DESC
        ) AS outcome_rank,

        /* Worst outcome rank across entire incident (all persons, all injuries) */
        ROW_NUMBER() OVER (
            PARTITION BY o.ticketid
            ORDER BY
                CASE UPPER(LTRIM(RTRIM(o.outcome)))
                    WHEN 'FATALITY'   THEN 1
                    WHEN 'LOSTTIME'   THEN 2
                    WHEN 'RESTRICTED' THEN 3
                    WHEN 'MEDICAL'    THEN 4
                    WHEN 'FIRSTAID'   THEN 5
                    ELSE 6
                END ASC,
                o.outcomebegin DESC
        ) AS incident_rank

    FROM maximo.PLUSGOUTCOME o
)

/* ═══════════════════════════════════════════════════════════════════════
   FINAL SELECT — 1 row per outcome record
   ═══════════════════════════════════════════════════════════════════════ */
SELECT
    /* ── Keys / Identifiers ───────────────────────────────────────── */
    r.ticketid                                   AS [Incident ID],              /* renamed from [Ticket] */
    t.ticketuid                                  AS [Ticket UID],               /* added: preferred join key */
    r.plusgincpersonid                            AS [Incident Person Id],
    r.injorillid                                 AS [Illness or Injury],
    r.plusgoutcomeid                              AS [Unique Id],

    /* ── Composite join keys (ES&H model compatibility) ───────────── */
    CAST(r.ticketid + '|' + CAST(r.plusgincpersonid AS varchar(20)) AS varchar(200))
                                                 AS [tckt_prsn_joinid],          /* FK → Injured Person */
    CAST(r.ticketid + '|' + CAST(r.plusgincpersonid AS varchar(20)) + '|' + CAST(r.injorillid AS varchar(20)) AS varchar(300))
                                                 AS [tckt_prson_inj_joinid],     /* FK → Injury Detail */

    /* ── Outcome Details ──────────────────────────────────────────── */
    r.outcome                                    AS [Outcome],
    r.dod                                        AS [Date of Death],
    r.outcomebegin                               AS [Start Date],
    r.outcomeend                                 AS [End Date],
    r.injorilldays                               AS [Days Absent/Transferred/Restricted],
    ld.ldtext                                    AS [Transfer/Restriction Details], /* from LONGDESCRIPTION; may contain HTML */
    CAST(r.mostserious AS int)                   AS [Most Serious Outcome],

    /* ── Rankings ─────────────────────────────────────────────────── */
    r.outcome_rank                               AS [Outcome Rank],              /* derived: severity within injury */
    r.incident_rank                              AS [Incident Rank],             /* derived: severity within incident */

    /* ── Metadata ─────────────────────────────────────────────────── */
    CAST(r.frommigration AS int)                 AS [Is data from migration],
    r.hasld                                      AS [Has Long Description],

    /* ── Audit ────────────────────────────────────────────────────── */
    r.FABRIC_LOADED_DATE                         AS [Fabric Loaded Date],
    r.FABRIC_LOADED_BY                           AS [Fabric Loaded By]

FROM outcome_ranked r
LEFT JOIN maximo.TICKET t        ON t.ticketid = r.ticketid AND t.class = 'INCIDENT'
LEFT JOIN ld_outcome ld          ON ld.ldkey   = r.plusgoutcomeid AND ld.rn = 1;
