# VW_Environmental_Incident — Entity Relationship Diagram

## Mermaid ERD

```mermaid
erDiagram
    TICKET {
        bigint ticketuid PK
        varchar ticketid
        varchar class
        varchar status
        datetime statusdate
        varchar tri_level
        varchar tri_sr_type
        datetime reportdate
        datetime tri_incstart
        datetime actualfinish
        datetime changedate
        varchar reportedby
        varchar assignedownergroup
        varchar owner
        varchar supervisor
        varchar plusginvestlead
        varchar tri_respparty
        varchar vendor
        varchar assetnum
        varchar assetsiteid
        varchar assetorgid
        varchar siteid
        varchar orgid
        varchar location
        varchar description
        bit tri_3rdparty
        bit tri_offsite
        bit tri_psm
        bigint rowstamp
        datetime FABRIC_LOADED_DATE
        varchar FABRIC_LOADED_BY
    }

    INCIDENT {
        bigint ticketuid PK,FK
    }

    LONGDESCRIPTION {
        bigint longdescriptionid PK
        bigint ldkey FK
        varchar ldownertable
        varchar ldtext
    }

    PLUSGINCEVENT {
        bigint plusginceventid PK
        bigint ticketuid FK
        varchar plusgincidentgroup
        varchar plusginctype
        varchar plusgsftyobstype
        bit isprimary
        bit reportable
        datetime affecteddate
        varchar affectedperson
        varchar potenconsq
        varchar potenconsqsevr
        varchar actconsq
        varchar actconsqsevr
        varchar inceventid
        varchar classstructureid
        varchar description
    }

    PLUSGINCEVENTSPEC {
        bigint plusginceventspecid PK
        bigint plusginceventid FK
        varchar assetattrid
        varchar alnvalue
        decimal numvalue
        varchar measureunitid
    }

    PLUSGINCPERSON {
        bigint plusgincpersonid PK
        varchar ticketid FK
        varchar personid
        bit extperson
    }

    PLUSGOUTCOME {
        bigint plusgoutcomeid PK
        varchar ticketid FK
        varchar personid
        bigint plusgincpersonid
        int injorillid
        varchar outcome
        datetime dod
        datetime outcomebegin
        datetime outcomeend
        decimal injorilldays
        bit mostserious
    }

    %% ─── Relationships ───

    TICKET ||--|| INCIDENT : "ticketuid"
    TICKET ||--o{ PLUSGINCEVENT : "ticketuid"
    TICKET ||--o| LONGDESCRIPTION : "ticketuid = ldkey"
    PLUSGINCEVENT ||--o{ PLUSGINCEVENTSPEC : "plusginceventid"
    TICKET ||--o{ PLUSGINCPERSON : "ticketid"
    TICKET ||--o{ PLUSGOUTCOME : "ticketid"
```

## Data Flow Diagram

```mermaid
flowchart TB
    subgraph Sources ["📦 Source Tables (maximo schema)"]
        T[TICKET<br/>─────────<br/>ticketuid PK<br/>ticketid<br/>status, class, dates<br/>asset, location, org]
        I[INCIDENT<br/>─────────<br/>ticketuid FK<br/>incident metadata]
        LD[LONGDESCRIPTION<br/>─────────<br/>ldkey → ticketuid<br/>ldtext narrative<br/>ldownertable = TICKET]
        PE[PLUSGINCEVENT<br/>─────────<br/>plusginceventid PK<br/>ticketuid FK<br/>plusgincidentgroup<br/>isprimary, reportable]
        PS[PLUSGINCEVENTSPEC<br/>─────────<br/>plusginceventspecid PK<br/>plusginceventid FK<br/>assetattrid, alnvalue<br/>numvalue, measureunitid]
        PP[PLUSGINCPERSON<br/>─────────<br/>plusgincpersonid PK<br/>ticketid FK<br/>extperson flag]
        PO[PLUSGOUTCOME<br/>─────────<br/>plusgoutcomeid PK<br/>ticketid FK<br/>outcome severity<br/>injorilldays]
    end

    subgraph CTEs ["⚙️ CTE Transformations"]
        CTE1[ld_ranked<br/>─────────<br/>ROW_NUMBER by ldkey<br/>Most recent description]
        CTE2[env_event<br/>─────────<br/>Filter: ENVIRONMENTAL<br/>ROW_NUMBER: prefer primary<br/>1 event per incident]
        CTE3[spec_pivot<br/>─────────<br/>MAX CASE pivot<br/>~50 assetattrid → columns<br/>STRING_AGG for RELEASE_TYPE<br/>All events per incident]
        CTE4[release_parsed<br/>─────────<br/>Comma-split RELEASE_TYPE<br/>12 has_* material flags<br/>Environmental events only]
        CTE5[targa_contractor<br/>─────────<br/>MAX extperson per ticket<br/>Targa vs Contractor label]
        CTE6[outcome_agg<br/>─────────<br/>MIN severity rank<br/>has_* outcome flags<br/>max_injury_illness_days]
    end

    subgraph Output ["📊 VW_Environmental_Incident"]
        VIEW[1 row per incident<br/>═══════════════<br/>S1: Base — TICKET + INCIDENT<br/>S2: Event — env_event<br/>S3: Specs — 50+ pivoted attributes<br/>S4: Person — Targa/Contractor<br/>S5: Outcome — severity flags<br/>S6: OSHA/Classification flags<br/>S7: Release has_* flags]
    end

    %% Source → CTE flows
    LD --> CTE1
    PE --> CTE2
    PE --> CTE3
    PS --> CTE3
    PE --> CTE4
    PS --> CTE4
    PP --> CTE5
    PO --> CTE6

    %% CTE → Final SELECT joins
    T -- "INNER JOIN ticketuid" --> VIEW
    I -- "INNER JOIN ticketuid" --> VIEW
    CTE2 -- "INNER JOIN ticketuid, rn=1" --> VIEW
    CTE1 -- "LEFT JOIN ldkey=ticketuid, rn=1" --> VIEW
    CTE3 -- "LEFT JOIN ticketuid" --> VIEW
    CTE5 -- "LEFT JOIN ticketid" --> VIEW
    CTE6 -- "LEFT JOIN ticketid" --> VIEW
    CTE4 -- "LEFT JOIN ticketuid" --> VIEW

    style T fill:#4A90D9,color:#fff
    style I fill:#4A90D9,color:#fff
    style LD fill:#7B68EE,color:#fff
    style PE fill:#E67E22,color:#fff
    style PS fill:#E67E22,color:#fff
    style PP fill:#2ECC71,color:#fff
    style PO fill:#E74C3C,color:#fff
    style VIEW fill:#1ABC9C,color:#fff
```

## Join Summary

| CTE / Source | Join Type | Join Key | Grain | Purpose |
|---|---|---|---|---|
| **TICKET** | Base table | — | 1/ticket | Core incident record |
| **INCIDENT** | `INNER JOIN` | `ticketuid` | 1:1 | Confirms ticket is an incident |
| **env_event** (PLUSGINCEVENT) | `INNER JOIN` | `ticketuid`, `rn=1` | 1:1 | Best environmental event; **filters to ENV only** |
| **ld_ranked** (LONGDESCRIPTION) | `LEFT JOIN` | `ldkey = ticketuid`, `rn=1` | 0..1 | Most recent narrative text |
| **spec_pivot** (PLUSGINCEVENT × PLUSGINCEVENTSPEC) | `LEFT JOIN` | `ticketuid` | 0..1 | ~50 pivoted spec attributes across **all** events |
| **targa_contractor** (PLUSGINCPERSON) | `LEFT JOIN` | `ticketid` | 0..1 | Targa vs Contractor classification |
| **outcome_agg** (PLUSGOUTCOME) | `LEFT JOIN` | `ticketid` | 0..1 | Aggregated outcome severity flags |
| **release_parsed** (PLUSGINCEVENT × PLUSGINCEVENTSPEC) | `LEFT JOIN` | `ticketuid` | 0..1 | 12 `has_*` release material flags |

## Key Observations

1. **Grain preservation**: Every CTE aggregates or ranks to 1 row per incident → no fan-out
2. **INNER JOIN on env_event** is the environmental filter — only incidents with `plusgincidentgroup = 'ENVIRONMENTAL'` appear
3. **spec_pivot aggregates across ALL events** (not just environmental) to capture cross-type specs
4. **release_parsed is scoped to ENVIRONMENTAL** events only, parsing `RELEASE_TYPE` comma-delimited values
5. **Two different join keys**: `ticketuid` (bigint PK) for event tables, `ticketid` (varchar) for person/outcome tables
