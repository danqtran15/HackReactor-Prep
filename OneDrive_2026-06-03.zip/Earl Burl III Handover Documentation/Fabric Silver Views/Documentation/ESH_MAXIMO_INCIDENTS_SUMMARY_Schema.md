# ESH_MAXIMO_INCIDENTS_SUMMARY — Schema Reference

**Location:** `maximo.ESH_MAXIMO_INCIDENTS_SUMMARY`  
**Grain:** Multiple rows per incident (person-event level, up to ~110 per incident)  
**Distinct Incidents:** 17,757  
**Total Rows:** 175,878  

---

## ⚠️ Known Gotchas

1. **Date column is `affected_date`, NOT `report_date`.** The view (`VW_Incident_Silver_Expanded`) uses `report_date`. Do not assume column names match between the two.
2. **No `report_date` column exists** in this table.
3. **Fans out per incident** — always dedup with `ROW_NUMBER() OVER (PARTITION BY incident_id ...)` before comparing to the 1:1 incident view.
4. **`class_pipeline` is mostly NULL** (17,743 of 17,757) — do not treat NULL as 0 when comparing.
5. **`targa_or_contractor` is populated even when no `PLUSGINCPERSON` rows exist** — summary defaults to a value; the view returns NULL.

---

## Column Listing

| Column | Notes |
|--------|-------|
| `incident_id` | Join key to view's `incident_id` |
| `affected_date` | ⚠️ Date field — NOT called `report_date` |
| `maximo_site_id` | |
| `site_name` | |
| `location` | |
| `location_description` | |
| `asset_description` | |
| `asset_number` | |
| `class_transportation` | Flag (1/NULL) |
| `class_injury_or_illness` | Flag (1/NULL) |
| `class_environmental` | Flag (1/NULL) |
| `repfire_tri` | Flag (1/NULL) |
| `inc_offsiteimpacts` | Flag (1/NULL) |
| `typeprocsaf_tri` | Flag (1/NULL) |
| `class_property_damage` | Flag (1/NULL) |
| `targa_or_contractor` | Text: Targa / Contractor |
| `incident_description` | |
| `description_long` | HTML content |
| `status` | |
| `status_date` | |
| `osha_cat_fatality` | Flag (1/NULL) |
| `osha_cat_lost_time_injuries` | Flag (1/NULL) |
| `osha_cat_restricted_job_transfer_injuries` | Flag (1/NULL) |
| `osha_cat_medical_treatment_or_other_injuries` | Flag (1/NULL) |
| `osha_cat_first_aid_injuries` | Flag (1/NULL) |
| `osha_cat_osha_recordable_injuries` | Flag (1/NULL) |
| `osha_cat_total_motor_vehicle_accidents` | Flag (1/NULL) |
| `osha_cat_animal_strikes` | Flag (1/NULL) |
| `osha_cat_other_non_preventable_mvas` | Flag (1/NULL) |
| `osha_cat_preventable_mvas` | Flag (1/NULL) |
| `osha_cat_total_non_preventable_mvas` | Flag (1/NULL) |
| `damage_amount` | |
| `osha_cat_preventable_mvas_greater_than_1500` | Flag (1/NULL) |
| `reportable_reportable_releases` | |
| `incident_level` | |
| `incident_level_description` | |
| `envnonreportable_tri` | Flag (1/NULL) |
| `reportableenv_tri` | Flag (1/NULL) |
| `environmental_reportable_type` | |
| `duration_in_hours` | |
| `entered_duration_uom` | |
| `release_liq` | |
| `release_gas` | |
| `release_other` | |
| `material_acid_gas` | |
| `amount_acid_scf` | |
| `entered_acid_uom` | |
| `material_field_inlet_gas` | |
| `amount_field_scf` | |
| `entered_field_uom` | |
| `material_residue_gas` | |
| `amount_residue_scf` | |
| `entered_residue_uom` | |
| `material_other_gas` | |
| `amount_other_scf` | |
| `entered_other_uom` | |
| `material_condensate` | |
| `amount_condensate_bbl` | |
| `entered_condensate_uom` | |
| `material_crude` | |
| `amount_crude_bbl` | |
| `entered_crude_uom` | |
| `material_other_liquid` | |
| `amount_otherliquid_bbl` | |
| `entered_otherliquid_uom` | |
| `material_produced_water` | |
| `amount_producedwater_bbl` | |
| `entered_producedwater_uom` | |
| `material_ngl` | |
| `entered_ngl_uom` | |
| `flared_release` | |
| `class_pipeline` | Flag (1/NULL) — ⚠️ mostly NULL |
| `preliminary_cause` | |
| `reported_by_id` | |
| `reported_by_name` | |
| `reported_by_email` | |
| `reported_by_phone` | |
| `reported_date` | ⚠️ This is the ticket reported date, NOT the primary date field |
| `ticket_uid` | |
| `assetattrid` | Spec attribute ID (causes fan-out) |
| `refobjectid` | |
| `alnvalue` | Spec string value |
| `refobjectname` | |
| `numvalue` | Spec numeric value |
| `measureunitid` | |
| `event_id` | |
| `FABRIC_LOADED_DATE` | |
| `FABRIC_LOADED_BY` | |
| `FABRIC_MODIFIED_DATE` | |
| `FABRIC_MODIFIED_BY` | |
| `amount_ngl (scf)` | ⚠️ Has space and parens in name — requires brackets |

---

## Column Name Mapping: Summary ↔ View

| Concept | Summary Column | View Column |
|---------|---------------|-------------|
| Primary date | `affected_date` | `report_date` |
| Incident key | `incident_id` | `incident_id` |
| Description | `incident_description` | `summary` |
| Long description | `description_long` | `long_summary` |
| Site | `maximo_site_id` | `site_id` |
| Ticket UID | `ticket_uid` | `ticket_uid` |
| Reported date | `reported_date` | `report_date` |
