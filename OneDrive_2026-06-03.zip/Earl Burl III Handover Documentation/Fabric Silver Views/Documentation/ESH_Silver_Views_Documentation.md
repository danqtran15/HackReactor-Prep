# ES&H Maximo Silver-Layer Views — Technical Documentation

> **Generated:** 2025-01-27  
> **Updated:** 2026-05-20 (SME Round 2 — Person/Injury/Outcome views)  
> **Prior update:** 2025-05-14 (SME Restructure)  
> **Target:** LH_Silver SQL Analytics Endpoint (`maximo` schema)  
> **Source System:** IBM Maximo via Fabric Lakehouse mirroring  
> **Deployment:** `CREATE OR ALTER VIEW` scripts pasted into Fabric SQL query editor

---

## View Index

| # | View | Description |
|---|------|-------------|
| 1 | `VW_Outcome` | Incident outcomes/results **(v2 updated)** |
| 2 | `VW_Classification` | Incident classification/categorization |
| 3 | `VW_Injured_Person` | Person-level injury records **(v2 updated)** |
| 4 | ~~`VW_Injury_Detail`~~ | **Superseded** — renamed to `VW_Injury_and_Illness_Detail` |
| 4b | **`VW_Injury_and_Illness_Detail`** | **Detailed injury attributes (v2 — renamed from VW_Injury_Detail)** |
| 5 | `VW_Incident_Silver_Validation` | Validation/QA view for silver layer |
| 6 | **`VW_Incident`** | **Unified incident view — ALL categories (NEW)** |
| 7 | **`VW_Environmental_Attributes`** | **Environmental event specs (NEW)** |
| 8 | **`VW_Property_Damage_Attributes`** | **Property damage event specs (NEW)** |
| 9 | **`VW_Fire_Ignition_Attributes`** | **Fire/ignition event specs (NEW)** |
| 10 | **`VW_Injury_Illness_Attributes`** | **Injury/illness event specs (NEW)** |
| 11 | **`VW_Physical_Security_Attributes`** | **Physical security event specs (NEW)** |
| 12 | **`VW_Transportation_Attributes`** | **Transportation event specs (NEW)** |
| 13 | **`VW_Investigation`** | **Core investigation view (1 row per investigation)** |
| 14 | **`VW_Investigation_Actions`** | **Open/Closed action counts per investigation** |
| 15 | **`VW_Investigation_RCFA_Results`** | **Root cause failure analysis results** |
| 16 | **`VW_Investigation_Reference`** | **Denormalized investigation + RCFA + actions (pre-joined)** |

> Each view has two variants: **Standard SQL** (`.sql`) and **Fabric** (`_Fabric.sql`). The Fabric versions are canonical.

---

## 1. Overview

This project defines SQL views that form the Silver layer of the ES&H (Environment, Safety & Health) Incident Semantic Model on Microsoft Fabric. The views transform raw Maximo incident data — stored as normalized, EAV-structured tables — into analytics-ready, columnar output suitable for Power BI semantic modeling.

### Key characteristics

| Property | Value |
|----------|-------|
| **Schema** | `maximo` |
| **Endpoint** | LH_Silver SQL Analytics Endpoint (Fabric Lakehouse) |
| **Source system** | IBM Maximo (Targa instance) |
| **Deployment method** | Paste `CREATE OR ALTER VIEW` DDL into Fabric SQL query editor |
| **View pairs** | Each view has a SQL Server variant (`.sql`) and a Fabric variant (`_Fabric.sql`); the **Fabric versions are canonical** |
| **Column naming** | Fabric views use `[Friendly Names]`; original view uses `snake_case` |
| **HTML stripping** | `[Long Summary]` contains raw HTML — stripping is handled downstream in Power Query, not in the views |

### Consumers

- ES&H Incident Semantic Model (Power BI)
- OSHA Milestone Tracker
- ES&H 10-Pack Archive
- Injury & MVA Counts dashboards

---

## 2. Architecture

### 2.1 Source Tables

All source tables reside in the `maximo` schema, mirrored from IBM Maximo via Fabric Lakehouse:

| Source Table | Description |
|-------------|-------------|
| `TICKET` | Core incident record — every incident starts here |
| `INCIDENT` | 1:1 extension of TICKET confirming the record is an incident |
| `LONGDESCRIPTION` | Multi-row narrative/rich-text linked by `ldkey`. **Not just for tickets** — stores text for PLUSGINJORILL, PLUSGOUTCOME, and others (see §8.7) |
| `PLUSGINCEVENT` | Event records — one incident can have multiple events of different types |
| `PLUSGINCEVENTSPEC` | EAV (Entity-Attribute-Value) spec attributes per event |
| `PLUSGINCPERSON` | Person records per incident (impacted persons, witnesses) |
| `PLUSGOUTCOME` | Outcome records per injury per person per incident |
| `PLUSGINJORILL` | Injury/illness detail per person per incident |
| `CLASSSTRUCTURE` | Classification hierarchy (self-referencing parent-child) |
| `CLASSIFICATION` | Classification descriptions |

### 2.2 Star-Schema Approach

The views form a **star schema**:

- **Fact view** (incident-grain): `VW_Incident` (unified — all categories)
- **Attribute views** (event-grain): `VW_Environmental_Attributes`, `VW_Property_Damage_Attributes`, `VW_Fire_Ignition_Attributes`, `VW_Injury_Illness_Attributes`, `VW_Physical_Security_Attributes`, `VW_Transportation_Attributes`
- **Dimension/detail views**: `VW_Outcome` (v2), `VW_Classification`, `VW_Injured_Person` (v2), `VW_Injury_and_Illness_Detail` (v2, renamed from `VW_Injury_Detail`)
- **Validation view**: `VW_Incident_Silver_Validation` (QA script, not a persisted view)

### 2.3 Dual-Event Incidents

An incident can have **multiple events** of different types (e.g., both `ENVIRONMENTAL` and `INJURY/ILLNESS`). In the new architecture, `VW_Incident` includes ALL incidents regardless of category, and the attribute views provide event-grain details. An incident with two event types will have rows in two separate attribute views.

### 2.4 The `ld_ranked` CTE Pattern

Long descriptions in Maximo can have multiple revisions per ticket. The `ld_ranked` CTE selects the **most recent** description using:

```sql
ROW_NUMBER() OVER (
    PARTITION BY ld.ldkey
    ORDER BY ld.longdescriptionid DESC
) AS rn
-- Filter: rn = 1 in the JOIN
```

### 2.5 The `spec_pivot` Pattern (EAV → Columnar)

Maximo stores event attributes as rows in `PLUSGINCEVENTSPEC` (Entity-Attribute-Value pattern). The attribute views pivot these into columns using `MAX(CASE WHEN ...)`:

```sql
SELECT
    pe.plusginceventid,
    MAX(CASE WHEN s.assetattrid = 'FIRE_RESPONSE' THEN s.alnvalue END) AS [Fire Response],
    MAX(CASE WHEN s.assetattrid = 'MVA_TYPE'      THEN s.alnvalue END) AS [MVA Type],
    MAX(CASE WHEN s.assetattrid = 'DAMAGE_AMOUNT' THEN s.numvalue END) AS [Damage Amount],
    -- ... category-specific attributes
FROM maximo.PLUSGINCEVENT pe
INNER JOIN maximo.PLUSGINCEVENTSPEC s ON s.plusginceventid = pe.plusginceventid
WHERE pe.plusgincidentgroup = '<CATEGORY>'
GROUP BY pe.plusginceventid
```

**Key difference from legacy approach:**
- Legacy approach: `spec_pivot` at incident grain (`GROUP BY ticketuid`) — mixes specs from different event types
- New attribute views: `spec_pivot` at event grain (`GROUP BY plusginceventid`) — category-specific, no cross-contamination

---

## 3. Legacy View Catalog

> For full documentation of views 3.1–3.9, see the detailed technical documentation in `Fabric Silver Views/Documentation/ESH_Silver_Views_Documentation.md`.

| View | Grain | Filter | Notes |
|------|-------|--------|-------|
| `VW_Outcome` | 1 row per outcome | All outcomes | **v2 updated** (2026-05-20) — see §8 |
| `VW_Classification` | 1 row per classification node | All classifications | Active |
| `VW_Injured_Person` | 1 row per person per incident | All persons | **v2 updated** (2026-05-20) — see §8 |
| `VW_Injury_Detail` | 1 row per injury per person | All injuries | **Superseded** — renamed to `VW_Injury_and_Illness_Detail` (see §8). Run `DROP VIEW IF EXISTS [maximo].[VW_Injury_Detail]` after deploying v2. |
| `VW_Incident_Silver_Validation` | N/A | QA script | Not a persisted view |

---

## 4. New Architecture — SME Restructure (2025-05)

> **Rationale:** Based on SME feedback, the architecture was restructured to separate the unified incident header from category-specific spec attributes. This eliminates the 50+ spec columns from the incident view, moves them into purpose-built attribute views at event grain, and derives category flags directly from `plusgincidentgroup` instead of inferring from spec attribute existence.

### 4.1 `maximo.VW_Incident`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per incident (`ticketuid`) |
| **Filter** | NONE — includes ALL incidents regardless of category |
| **File** | `VW_Incident_Fabric.sql` |
| **Replaces** | Legacy `VW_Safety_Incident` and `VW_Environmental_Incident` (both deleted) |

#### CTEs

| CTE | Purpose |
|-----|---------|
| `ld_ranked` | Most-recent long description per ticket (ROW_NUMBER by `longdescriptionid DESC`) |
| `primary_event` | Primary event per incident — uses `ROW_NUMBER() OVER (... ORDER BY isprimary DESC, plusginceventid ASC)` with `rn = 1`. Falls back to lowest event ID if no event has `isprimary = 1`. |
| `incident_category` | STRING_AGG of DISTINCT `plusgincidentgroup` values per incident |
| `category_flags` | Boolean category flags derived from `plusgincidentgroup` directly |

#### Key Design Choices

1. **No event-type filter** — unlike the deleted legacy views (`VW_Safety_Incident`, `VW_Environmental_Incident`), this view includes ALL incidents. Category-specific filtering is done by consumers using the category flag columns.
2. **Category flags from `plusgincidentgroup`** — more accurate than the old spec-inference approach (see [Design Decisions](#45-design-decisions)).
3. **`[Incident Category]` uses STRING_AGG** — shows all event groups for an incident (e.g., `"TRANSPORTATION; INJURY/ILLNESS"`).
4. **No spec_pivot attributes** — all spec attributes are moved to the six attribute views.
5. **No outcome/OSHA flags** — these remain in `VW_Outcome` where they belong.

#### Join Strategy

| Source | Join Type | Key | Reason |
|--------|-----------|-----|--------|
| `TICKET` | Base table | — | Core incident record |
| `INCIDENT` | `INNER JOIN` | `ticketuid` | Confirms record is an incident |
| `ld_ranked` | `LEFT JOIN` | `ldkey = ticketuid, rn = 1` | Not all tickets have long descriptions |
| `primary_event` | `LEFT JOIN` | `ticketuid` | Some incidents may lack a primary event |
| `incident_category` | `LEFT JOIN` | `ticketuid` | Aggregated category string |
| `category_flags` | `LEFT JOIN` | `ticketuid` | Boolean flags per category |

#### Output Columns (42 columns)

**Keys**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Ticket UID] | `t.ticketuid` | Unique ticket identifier (bigint PK) |
| [Incident ID] | `LTRIM(RTRIM(t.ticketid))` | Human-readable incident ID (trimmed) |

**Status & Classification**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Ticket Class] | `t.class` | Ticket class (e.g., INCIDENT) |
| [Status] | `t.status` | Current status (DRAFT, REVIEW, CLOSED, etc.) |
| [Status Date] | `t.statusdate` | Date of last status change |
| [Level] | `t.tri_level` | Targa incident level (1, 2, 3) |
| [Tri Level Category] | Computed | `CASE`: 1 → "Non Reportable", 2/3 → "Reportable", else "Unknown" |

**Dates**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Reported Date] | `t.reportdate` | Date incident was reported |
| [Incident Start Time] | `t.tri_incstart` | Actual start date/time of incident |
| [Resolved Date] | `t.actualfinish` | Resolved date (renamed from Actual Finish) |
| [Change Date] | `t.changedate` | Last modification date |

**Responsibility**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Reported By] | `t.reportedby` | Person who reported the incident |
| [Owner] | `t.owner` | Incident owner |
| [Supervisor] | `t.supervisor` | Supervisor |
| [Investigation Lead] | `t.plusginvestlead` | Investigation lead |
| [Responsible Party] | `t.tri_respparty` | Responsible party |
| [Vendor] | `t.vendor` | Vendor |

**Asset / Location**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Asset] | `t.assetnum` | Asset number |
| [Site] | `t.siteid` | Site ID |
| [Organization] | `t.orgid` | Organization ID |
| [Location] | `t.location` | Location |
| [Asset PK] | `CONCAT(t.assetnum, '_', t.siteid)` | Composite key (renamed from Asset Site Combined) |

**Narrative**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Summary] | `t.description` | Short description / title |
| [Long Summary] | `CAST(ld.ldtext AS varchar(max))` | Full narrative (HTML; stripping done in Power Query) |

**Ticket Flags**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [3rd Party Impacts] | `t.tri_3rdparty` | Third-party impacts flag |
| [Offsite Impacts] | `t.tri_offsite` | Offsite impacts flag |
| [PSM/RMP] | `t.tri_psm` | PSM/RMP flag |

**Utility**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [URL] | Computed | Deep link to Maximo incident record |
| [Row Stamp] | `t.rowstamp` | Maximo row version |
| [Fabric Loaded Date] | `t.FABRIC_LOADED_DATE` | Fabric load timestamp |
| [Fabric Loaded By] | `t.FABRIC_LOADED_BY` | Fabric load identity |

**Category (Aggregated)**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Incident Category] | `incident_category` CTE | STRING_AGG of DISTINCT event groups (e.g., `"TRANSPORTATION; INJURY/ILLNESS"`) |

**Event Classification (from primary event)**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Event Class Structure] | `pe.classstructureid` | Primary event class structure |
| [Event Description] | `pe.description` | Primary event description |
| [Event Custom] | `CONCAT(pe.plusginceventid, '^', COALESCE(pe.classstructureid, ''))` | Computed event+class key for Power BI |

**Category Flags (from `category_flags` CTE)**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Category Transportation] | `category_flags` | 1 if any event has `plusgincidentgroup = 'TRANSPORTATION'` |
| [Category Injury Or Illness] | `category_flags` | 1 if any event has `plusgincidentgroup = 'INJURY/ILLNESS'` |
| [Category Environmental] | `category_flags` | 1 if any event has `plusgincidentgroup = 'ENVIRONMENTAL'` |
| [Category Property Damage] | `category_flags` | 1 if any event has `plusgincidentgroup = 'DAMAGE'` |
| [Category Physical Security] | `category_flags` | 1 if any event has `plusgincidentgroup = 'PHYSICAL SECURITY'` |
| [Category Fire Or Ignition] | `category_flags` | 1 if any event has `plusgincidentgroup LIKE 'FIRE%'` (matches FIRE/IGNITION and variants) |

**Derived**

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Incident Level Description] | Computed | "Level 1 - Non Reportable", "Level 2 - Reportable", "Level 3 - Significant", "Unknown" |

#### Source Tables

| Table | Role |
|-------|------|
| `TICKET` | Core incident record |
| `INCIDENT` | Confirms record is incident (INNER JOIN filter) |
| `LONGDESCRIPTION` | Narrative text |
| `PLUSGINCEVENT` | Event records — used for primary event, category aggregation, and category flags |

---

### 4.2 Attribute Views — Shared Pattern

All six attribute views follow the same structural pattern:

| Property | Value |
|----------|-------|
| **Grain** | 1 row per event (`plusginceventid`) |
| **Join path** | `PLUSGINCEVENT` → `TICKET` → `PLUSGINCEVENTSPEC` |
| **Filter** | `WHERE pe.plusgincidentgroup = '<GROUP>'` |
| **Pivot** | `MAX(CASE WHEN s.assetattrid = '...' THEN s.alnvalue/numvalue END)` grouped by `plusginceventid` |

#### Common Columns (in ALL attribute views)

| Column Name | Source | Description |
|-------------|--------|-------------|
| [Ticket UID] | `t.ticketuid` | FK to `VW_Incident` |
| [Incident ID] | `LTRIM(RTRIM(t.ticketid))` | Human-readable incident ID |
| [Event UID] | `pe.plusginceventid` | PK of the event record |

---

### 4.3 `maximo.VW_Environmental_Attributes`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per event (`plusginceventid`) |
| **Filter** | `plusgincidentgroup = 'ENVIRONMENTAL'` |
| **File** | `VW_Environmental_Attributes_Fabric.sql` |

#### Category-Specific Columns

| Column Name | Source Attribute | Value Column | Description |
|-------------|-----------------|-------------|-------------|
| [Release Type] | `RELEASE_TYPE` | alnvalue | Type of release |
| [Release Quantity] | `RELEASE_QTY` | numvalue | Quantity released |
| [Release Quantity UoM] | `RELEASE_QTY` | measureunitid | Unit of measure for release qty |
| [Flared Release] | `FLARED_RELEASE` | alnvalue | Whether release was flared |
| [Duration] | `DURATION` | numvalue | Duration of event |
| [Duration UoM] | `DURATION` | measureunitid | Unit of measure for duration |
| [Pipeline Leak] | `PIPELINE_LEAK` | alnvalue | Pipeline leak flag |
| [Leak Notice Source] | `LEAK_NOTICE_SOUR` | alnvalue | How leak was noticed |
| [High Potential] | `HIPO` | alnvalue | High-potential incident flag |
| [Release Stop Time] | `RELEASE_STOPTIME` | datetime2 | When the release was stopped |

---

### 4.4 `maximo.VW_Property_Damage_Attributes`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per event (`plusginceventid`) |
| **Filter** | `plusgincidentgroup = 'DAMAGE'` |
| **File** | `VW_Property_Damage_Attributes_Fabric.sql` |

#### Category-Specific Columns

| Column Name | Source Attribute | Value Column | Description |
|-------------|-----------------|-------------|-------------|
| [Damage Amount] | `DAMAGE_AMOUNT` | numvalue | Dollar amount of damage |
| [Damage Amount UoM] | `DAMAGE_AMOUNT` | measureunitid | Currency/unit for damage amount |
| [Damage Type] | `DAMAGE_TYPE` | alnvalue | Type of property damage |
| [Claim Number] | `CLAIM_NO` | alnvalue | Insurance claim number |
| [High Potential] | `HIPO` | alnvalue | High-potential incident flag |

---

### 4.5 `maximo.VW_Fire_Ignition_Attributes`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per event (`plusginceventid`) |
| **Filter** | `plusgincidentgroup = 'FIRE/IGNITION'` |
| **File** | `VW_Fire_Ignition_Attributes_Fabric.sql` |

#### Category-Specific Columns

| Column Name | Source Attribute | Value Column | Description |
|-------------|-----------------|-------------|-------------|
| [Fire Response] | `FIRE_RESPONSE` | alnvalue | Fire response type |
| [High Potential] | `HIPO` | alnvalue | High-potential incident flag |

---

### 4.6 `maximo.VW_Injury_Illness_Attributes`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per event (`plusginceventid`) |
| **Filter** | `plusgincidentgroup = 'INJURY/ILLNESS'` |
| **File** | `VW_Injury_Illness_Attributes_Fabric.sql` |

#### Category-Specific Columns

| Column Name | Source Attribute | Value Column | Description |
|-------------|-----------------|-------------|-------------|
| [Regulated Injury] | `REG_INJ` | alnvalue | Whether injury is regulated |
| [HR Location] | `HR_LOCATION` | alnvalue | HR location code |
| [Injury Type] | `INJ_TYPE` | alnvalue | Type of injury/illness |
| [Claim Number] | `CLAIM_NO` | alnvalue | Workers' comp claim number |
| [High Potential] | `HIPO` | alnvalue | High-potential incident flag |

---

### 4.7 `maximo.VW_Physical_Security_Attributes`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per event (`plusginceventid`) |
| **Filter** | `plusgincidentgroup = 'PHYSICAL SECURITY'` |
| **File** | `VW_Physical_Security_Attributes_Fabric.sql` |

#### Category-Specific Columns

| Column Name | Source Attribute | Value Column | Description |
|-------------|-----------------|-------------|-------------|
| [Security Type] | `SECURITY_TYPE` | alnvalue | Type of security event |
| [Financial Impact] | `FINANCIAL_IMPACT` | numvalue | Financial impact amount |
| [Financial Impact UoM] | `FINANCIAL_IMPACT` | measureunitid | Currency/unit for financial impact |
| [Property Crime] | `PROPERTY_CRIME` | alnvalue | Property crime flag |

---

### 4.8 `maximo.VW_Transportation_Attributes`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per event (`plusginceventid`) |
| **Filter** | `plusgincidentgroup = 'TRANSPORTATION'` |
| **File** | `VW_Transportation_Attributes_Fabric.sql` |

#### Category-Specific Columns

| Column Name | Source Attribute | Value Column | Description |
|-------------|-----------------|-------------|-------------|
| [MVA Type] | `MVA_TYPE` | alnvalue | Motor vehicle accident type |
| [MVA DOT Type] | `MVA_DOT_TYPE` | alnvalue | DOT classification of MVA |
| [Vehicle Number] | `VEHICLE_NO` | alnvalue | Vehicle number involved |
| [High Potential] | `HIPO` | alnvalue | High-potential incident flag |
| [MVA SOS] | `MVA_SOS` | alnvalue | SOS classification |
| [MVA Category] | `MVA_CAT` | alnvalue | MVA category (PREVENTABLE, etc.) |
| [Driver] | `TRI_DRIVER` | alnvalue | Driver identifier |

> **Note:** `HAZARDOUS_RELEAS` spec attribute excluded from this view pending data verification.

---

### 4.9 Design Decisions

| # | Decision | Rationale |
|---|----------|-----------|
| 1 | **Category flags derived from `plusgincidentgroup` directly** | The old approach inferred categories from spec attribute existence (e.g., `[Class Transportation]` used `spec_mva_type IS NOT NULL`). This was inaccurate — transportation events without MVA specs were missed. Deriving from `plusgincidentgroup` is the authoritative source. |
| 2 | **Legacy incident views deleted** | `VW_Safety_Incident`, `VW_Environmental_Incident`, and `VW_Environmental_Release` have been dropped. `VW_Incident` replaces both incident views with category flags for filtering. Environmental release/spill data is now in `VW_Environmental_Attributes`. |
| 3 | **Attribute views at event grain (not incident grain)** | An incident can have multiple events of the same category. Event-grain (1 row per `plusginceventid`) preserves this detail without double-counting. Consumers join to `VW_Incident` via `[Ticket UID]`. |
| 4 | **No outcome/OSHA flags in VW_Incident** | Outcome classification and OSHA recordability remain in `VW_Outcome`. This separates concerns and avoids duplicating complex outcome logic in the unified incident view. |
| 5 | **STRING_AGG for Incident Category** | An incident with events in multiple groups (e.g., a vehicle accident that also injures someone) shows all groups semicolon-delimited. Consumers can filter using category flag columns instead for report-level filtering. |
| 6 | **[Resolved Date] renamed from [Actual Finish]** | SME feedback: "Resolved Date" is more meaningful to business users than the Maximo-native "Actual Finish" terminology. |
| 7 | **[Asset PK] renamed from [Asset Site Combined]** | Clarifies this is a composite primary key used for joining to asset dimensions. |

---

## 5. Relationship Model

```
┌─────────────────────────────────────┐
│         VW_Incident                 │
│   Grain: 1 row per ticketuid       │
│   ALL incidents, no filter          │
│   42 columns + category flags       │
└──────────────┬──────────────────────┘
               │ [Ticket UID]
               │
    ┌──────────┼──────────────────────────────────────────────┐
    │          │          │          │          │              │
    ▼          ▼          ▼          ▼          ▼              ▼
┌────────┐┌────────┐┌────────┐┌────────┐┌────────┐  ┌──────────────┐
│Environ.││Prop.   ││Fire/   ││Injury/ ││Physical│  │Transportation│
│Attribs ││Damage  ││Ignition││Illness ││Security│  │  Attributes  │
│        ││Attribs ││Attribs ││Attribs ││Attribs │  │              │
└────────┘└────────┘└────────┘└────────┘└────────┘  └──────────────┘
  Event-grain: 1 row per plusginceventid (join via Ticket UID)

               │ [Ticket UID] / [Incident ID]
               │
               ▼
┌─────────────────────────────────────┐
│       VW_Injured_Person (v2)        │
│  Grain: 1 row per person per       │
│         incident                    │
│  Key: [tckt_prsn_joinid]           │
│  PII lives HERE (Person Impacted,  │
│  DOB, contact info)                 │
└──────────────┬──────────────────────┘
               │ [tckt_prsn_joinid]
               │  = ticketid|plusgincpersonid
               ▼
┌─────────────────────────────────────┐
│  VW_Injury_and_Illness_Detail (v2)  │
│  Grain: 1 row per injury per       │
│         person per incident         │
│  Key: [tckt_prson_inj_joinid]      │
│  Injury type flags, body part,      │
│  descriptions from LONGDESCRIPTION  │
└──────────────┬──────────────────────┘
               │ [tckt_prson_inj_joinid]
               │  = ticketid|plusgincpersonid|injorillid
               ▼
┌─────────────────────────────────────┐
│         VW_Outcome (v2)             │
│  Grain: 1 row per outcome per      │
│         injury per person           │
│  Severity ranking, OSHA days,       │
│  transfer/restriction details       │
│  from LONGDESCRIPTION               │
└─────────────────────────────────────┘
```

---

## 6. File Inventory (New Views)

| File | Purpose |
|------|---------|
| `VW_Incident_Fabric.sql` | **Fabric** — Unified incident view (all categories, no filter) |
| `VW_Environmental_Attributes_Fabric.sql` | **Fabric** — Environmental event-grain specs |
| `VW_Property_Damage_Attributes_Fabric.sql` | **Fabric** — Property damage event-grain specs |
| `VW_Fire_Ignition_Attributes_Fabric.sql` | **Fabric** — Fire/ignition event-grain specs |
| `VW_Injury_Illness_Attributes_Fabric.sql` | **Fabric** — Injury/illness event-grain specs |
| `VW_Physical_Security_Attributes_Fabric.sql` | **Fabric** — Physical security event-grain specs |
| `VW_Transportation_Attributes_Fabric.sql` | **Fabric** — Transportation event-grain specs |
| `VW_Injured_Person_Fabric.sql` | **Fabric** — Person bridge (v2 — SME round 2) |
| `VW_Injury_and_Illness_Detail_Fabric.sql` | **Fabric** — Injury detail (v2 — renamed from VW_Injury_Detail) |
| `VW_Outcome_Fabric.sql` | **Fabric** — Outcome tracking (v2 — SME round 2) |

---

## 7. Migration Guide

| Old Approach | New Approach |
|-------------|-------------|
| Use `VW_Safety_Incident` for non-environmental incidents | **View deleted.** Use `VW_Incident` with `[Category Environmental] = 0` or other flag filters |
| Use `spec_mva_type IS NOT NULL` to identify transportation incidents | Use `[Category Transportation] = 1` in `VW_Incident` |
| Use `spec_release_type IS NOT NULL` to identify environmental incidents | Use `[Category Environmental] = 1` in `VW_Incident` |
| Read MVA attributes from `VW_Safety_Incident.spec_mva_type` | **View deleted.** JOIN `VW_Transportation_Attributes` via `[Ticket UID]` |
| Read environmental specs from `VW_Environmental_Incident.spec_*` | **View deleted.** JOIN `VW_Environmental_Attributes` via `[Ticket UID]` |
| Read release/spill details from `VW_Environmental_Release` | **View deleted.** Release data available in `VW_Environmental_Attributes` |
| Infer category from spec column presence | Read category flag columns directly from `VW_Incident` |
| Use `VW_Injury_Detail` for injury records | Use `VW_Injury_and_Illness_Detail` (renamed). Drop old view: `DROP VIEW IF EXISTS [maximo].[VW_Injury_Detail]` |
| Read injury descriptions from base columns (`justbefore`, `injorilldesc`, `objsubs`) | These are always NULL — descriptions come from `LONGDESCRIPTION` table via CTE join (see §8.5) |
| Read transfer/restriction details from `PLUSGOUTCOME.trnsrestrctdetails` | Always NULL — text comes from `LONGDESCRIPTION` table via CTE join (see §8.5) |
| Get Person Impacted from `VW_Injury_Detail` or `VW_Outcome` | PII consolidated to `VW_Injured_Person` only — join via `[tckt_prsn_joinid]` |

---

## 8. Person / Injury / Outcome Views — SME Round 2 (2026-05-20)

> **SME Reviewer:** Allison Miller  
> **Author:** Data Engineering  
> **Validated:** 2026-05-20 (16 tests, all passing)

### 8.1 Overview

Three existing Silver-layer views were updated based on SME feedback:

| View | File | What Changed |
|------|------|-------------|
| `VW_Injured_Person` | `VW_Injured_Person_Fabric.sql` | Renamed columns, added Ticket UID, removed 15 blank/redundant columns |
| `VW_Injury_and_Illness_Detail` | `VW_Injury_and_Illness_Detail_Fabric.sql` | **Renamed** from `VW_Injury_Detail`. Fixed 3 blank text fields via LONGDESCRIPTION. Removed PII. |
| `VW_Outcome` | `VW_Outcome_Fabric.sql` | Fixed blank Transfer/Restriction Details via LONGDESCRIPTION. Removed PII. |

These three views form a **person → injury → outcome** chain below `VW_Incident`:

```
VW_Incident
    │  join on [Ticket UID] or [Incident ID]
    ▼
VW_Injured_Person          (1 row per person per incident)
    │  join on [tckt_prsn_joinid]
    ▼
VW_Injury_and_Illness_Detail  (1 row per injury per person per incident)
    │  join on [tckt_prson_inj_joinid]
    ▼
VW_Outcome                 (1 row per outcome per injury per person per incident)
```

### 8.2 Summary of Changes

#### Column Renames (all 3 views)

| Old Name | New Name | Reason |
|----------|----------|--------|
| `[Ticket]` | `[Incident ID]` | Align with business terminology across all views |
| `[Title]` | `[Job Title]` | Clarify that this is the person's job title (VW_Injured_Person only) |
| `[Injury Cause]` | `[Injury Mode]` | Match Maximo UI label (VW_Injury_and_Illness_Detail only) |

#### Columns Added (all 3 views)

| Column | Source | Why |
|--------|--------|-----|
| `[Ticket UID]` | `TICKET.ticketuid` | Preferred join key to `VW_Incident` (bigint, unique) vs `[Incident ID]` (varchar, NOT unique — see §8.6) |

#### Columns Removed

**VW_Injured_Person** — 15 columns removed (all were blank/unused or redundant):

| Removed Column | Reason |
|----------------|--------|
| `[Gender]` | Always blank in source |
| `[Person Role]` | Always blank in source |
| `[External Company]` | Always blank in source |
| `[External Company Type]` | Always blank in source |
| `[External Job Title]` | Always blank in source |
| `[External Location]` | Always blank in source |
| `[External Email]` | Always blank in source |
| `[External Phone]` | Always blank in source |
| `[External City]` | Always blank in source |
| `[External State]` | Always blank in source |
| `[External Zip]` | Always blank in source |
| `[Owner]` | Duplicated from VW_Incident |
| `[Site]` | Duplicated from VW_Incident |
| `[Has Long Description]` | Not meaningful for person records |
| `[Language Code]` | Not meaningful for person records |

**VW_Injury_and_Illness_Detail** — 6 columns removed:

| Removed Column | Reason |
|----------------|--------|
| `[Person Impacted]` | PII consolidated to VW_Injured_Person |
| `[Location]` | Available from VW_Incident |
| `[Location Id]` | Available from VW_Incident |
| `[Organization]` | Available from VW_Incident |
| `[Site]` | Available from VW_Incident |
| `[HCP Treatment Administered]` | Always blank in source |

**VW_Outcome** — 3 columns removed:

| Removed Column | Reason |
|----------------|--------|
| `[Person Impacted]` | PII consolidated to VW_Injured_Person |
| `[Organization]` | Available from VW_Incident |
| `[Site]` | Available from VW_Incident |

#### Data Fixes (blank fields now populated)

| View | Column | Problem | Fix |
|------|--------|---------|-----|
| VW_Injury_and_Illness_Detail | `[Description of Employee Actions]` | Base column `justbefore` always NULL | Join to `LONGDESCRIPTION` where `ldownercol = 'JUSTBEFORE'` |
| VW_Injury_and_Illness_Detail | `[Details of Injury or Illness]` | Base column `injorilldesc` always NULL | Join to `LONGDESCRIPTION` where `ldownercol = 'INJORILLDESC'` |
| VW_Injury_and_Illness_Detail | `[Details of Harmful Object or Substance]` | Base column `objsubs` always NULL | Join to `LONGDESCRIPTION` where `ldownercol = 'OBJSUBS'` |
| VW_Outcome | `[Transfer/Restriction Details]` | Base column `trnsrestrctdetails` always NULL | Join to `LONGDESCRIPTION` where `ldownercol = 'TRNSRESTRCTDETAILS'` |

> **Important:** These text fields may contain raw HTML (e.g., `<!-- RICH TEXT -->`, `<div>` tags). HTML stripping is handled downstream in Power Query, not in the SQL views.

---

### 8.3 `maximo.VW_Injured_Person` (v2)

| Property | Value |
|----------|-------|
| **Grain** | 1 row per person per incident (`ticketid` + `plusgincpersonid`) |
| **Source table** | `PLUSGINCPERSON` |
| **File** | `VW_Injured_Person_Fabric.sql` |
| **Row count** | 609 (as of 2026-05-20) |
| **PII** | Yes — this is the **only** view with Person Impacted, DOB, and contact details |

#### Join Strategy

| Source | Join Type | Key | Filter | Reason |
|--------|-----------|-----|--------|--------|
| `PLUSGINCPERSON` | Base table | — | — | Core person record |
| `TICKET` | `LEFT JOIN` | `ticketid` | `class = 'INCIDENT'` | Get `ticketuid` for downstream joins (see §8.6 for class filter explanation) |

#### Output Columns (26 columns)

**Keys / Identifiers**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Incident ID]` | `p.ticketid` | varchar | Human-readable incident number |
| `[Ticket UID]` | `t.ticketuid` | bigint | Unique ticket identifier — preferred FK to VW_Incident |
| `[Incident Person Id]` | `p.plusgincpersonid` | bigint | Person record PK within this incident |
| `[Person ID]` | `p.personid` | varchar | Maximo person identifier |
| `[Person Impacted]` | `p.personimpacted` | varchar | **PII** — person's display name |
| `[tckt_prsn_joinid]` | Computed | varchar(200) | Composite key: `ticketid\|plusgincpersonid` — FK for downstream views |

**Person Details**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Job Title]` | `p.title` | varchar | Person's job title (renamed from `[Title]`) |
| `[Date of Birth]` | `p.dob` | datetime2 | **PII** |
| `[Date of Hire]` | `p.dateofhire` | datetime2 | Hire date |
| `[Is External Person]` | `p.extperson` | varchar | Y/N — whether person is a contractor/visitor |
| `[External Person Relationship]` | `p.extpersonrelationship` | varchar | Contractor, visitor, etc. |

**Contact / Address**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Phone]` | `p.phone` | varchar | **PII** |
| `[Email]` | `p.email` | varchar | **PII** |
| `[Street]` | `p.street` | varchar | **PII** |
| `[City]` | `p.city` | varchar | |
| `[State]` | `p.state` | varchar | |
| `[Zip]` | `p.zip` | varchar | |

**Follow-up / Scope**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Follow Up Required]` | `p.followupreqd` | varchar | Whether follow-up is needed |
| `[Follow Up Action]` | `p.followupaction` | varchar | Description of follow-up action |
| `[Owner Group]` | `p.ownergroup` | varchar | Responsible group |
| `[Organization]` | `p.orgid` | varchar | Organization code |

**Sequence / Migration**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Sequence]` | `p.tri_sequence` | int | Display order within incident |
| `[Injury Data Migrated]` | `p.injdatamigrated` | bit | Whether injury data was migrated from legacy |
| `[Outcome Data Migrated]` | `p.outcomedatamigrated` | bit | Whether outcome data was migrated from legacy |

**Audit**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Fabric Loaded Date]` | `p.FABRIC_LOADED_DATE` | datetime2 | When record was loaded into Fabric |
| `[Fabric Loaded By]` | `p.FABRIC_LOADED_BY` | varchar | Identity that loaded the record |

---

### 8.4 `maximo.VW_Injury_and_Illness_Detail` (v2)

| Property | Value |
|----------|-------|
| **Grain** | 1 row per injury/illness (`ticketid` + `plusgincpersonid` + `injorillid`) |
| **Source table** | `PLUSGINJORILL` |
| **File** | `VW_Injury_and_Illness_Detail_Fabric.sql` |
| **Row count** | 572 (as of 2026-05-20) |
| **Renamed from** | `VW_Injury_Detail` — run `DROP VIEW IF EXISTS [maximo].[VW_Injury_Detail]` after deploying |
| **PII** | No — Person Impacted removed; get PII from VW_Injured_Person |

#### CTEs

| CTE | Purpose |
|-----|---------|
| `ld_injury` | Most-recent LONGDESCRIPTION text per injury record per field. Retrieves 3 text fields (`JUSTBEFORE`, `INJORILLDESC`, `OBJSUBS`) that are always NULL on the base table. Uses `ROW_NUMBER() OVER (PARTITION BY ldkey, ldownercol ORDER BY longdescriptionid DESC)` to get the latest revision. |

#### Join Strategy

| Source | Join Type | Key | Filter | Reason |
|--------|-----------|-----|--------|--------|
| `PLUSGINJORILL` | Base table | — | — | Core injury/illness record |
| `TICKET` | `LEFT JOIN` | `ticketid` | `class = 'INCIDENT'` | Get `ticketuid` (see §8.6) |
| `ld_injury` (×3) | `LEFT JOIN` | `ldkey = plusginjorillid` | `ldownercol = 'JUSTBEFORE'`, `rn = 1` | Employee actions text |
| `ld_injury` (×3) | `LEFT JOIN` | `ldkey = plusginjorillid` | `ldownercol = 'INJORILLDESC'`, `rn = 1` | Injury description text |
| `ld_injury` (×3) | `LEFT JOIN` | `ldkey = plusginjorillid` | `ldownercol = 'OBJSUBS'`, `rn = 1` | Harmful object text |

#### Output Columns (33 columns)

**Keys / Identifiers**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Incident ID]` | `j.ticketid` | varchar | Human-readable incident number |
| `[Ticket UID]` | `t.ticketuid` | bigint | FK to VW_Incident |
| `[Incident Person Id]` | `j.plusgincpersonid` | bigint | FK to VW_Injured_Person (with ticketid) |
| `[Illness or Injury]` | `j.injorillid` | int | Injury sequence number within person |
| `[Unique Id]` | `j.plusginjorillid` | bigint | Row PK (also used as `ldkey` for LONGDESCRIPTION) |
| `[tckt_prsn_joinid]` | Computed | varchar(200) | `ticketid\|plusgincpersonid` — FK → VW_Injured_Person |
| `[tckt_prson_inj_joinid]` | Computed | varchar(300) | `ticketid\|plusgincpersonid\|injorillid` — PK for VW_Outcome join |

**Classification**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Reportable Injury or Illness]` | `CAST(j.rptable AS int)` | int | 1 = OSHA reportable, 0 = not |

**Timing**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Injury or Onset of Illness]` | `j.injorilldate` | datetime2 | When injury occurred or illness onset |
| `[Unknown Time]` | `j.timecannotbd` | varchar | Whether exact time is unknown |
| `[Time Employee Started Work]` | `j.empbeganwork` | datetime2 | When the employee began their shift |

**Descriptions (from LONGDESCRIPTION — may contain HTML)**

| Column | Source | LONGDESCRIPTION ldownercol | Description |
|--------|--------|---------------------------|-------------|
| `[Description of Employee Actions]` | `ld_jb.ldtext` | `JUSTBEFORE` | What the employee was doing before the incident |
| `[Details of Injury or Illness]` | `ld_desc.ldtext` | `INJORILLDESC` | Detailed description of the injury or illness |
| `[Details of Harmful Object or Substance]` | `ld_obj.ldtext` | `OBJSUBS` | Object/substance that caused harm |

**Injury Type Flags (OSHA checkboxes — 1 or 0)**

| Column | Source | Description |
|--------|--------|-------------|
| `[Injury]` | `CAST(j.injury AS int)` | General injury |
| `[Skin Disorder]` | `CAST(j.skindisorder AS int)` | Skin disorder |
| `[Respiratory Condition]` | `CAST(j.respiratory AS int)` | Respiratory condition |
| `[Poisoning]` | `CAST(j.poisoning AS int)` | Poisoning |
| `[Hearing Loss]` | `CAST(j.hearingloss AS int)` | Hearing loss |
| `[Other]` | `CAST(j.allother AS int)` | Other illness type |

**Cause & Body Part**

| Column | Source | Description |
|--------|--------|-------------|
| `[Injury Mode]` | `j.injorilltype` | How the injury occurred (renamed from `[Injury Cause]` to match Maximo UI) |
| `[Impacted Body Part]` | `j.injorillbodypart` | Body part affected |

**Healthcare Provider**

| Column | Source | Description |
|--------|--------|-------------|
| `[Physician/HCP Name]` | `j.hcpname` | Treating physician name |
| `[Physician/HCP Phone]` | `j.hcpphone` | Treating physician phone |
| `[Physician/HCP Email]` | `j.hcpemail` | Treating physician email |
| `[HCP Treatment Facility]` | `j.hcpfacility` | Name of treatment facility |
| `[HCP Facility Street Address]` | `j.hcpfacaddress` | Facility address |
| `[HCP Facility City]` | `j.hcpfaccity` | Facility city |
| `[HCP Facility State]` | `j.hcpfacstate` | Facility state |
| `[HCP Facility Zip]` | `j.hcpfaczip` | Facility zip |

**Metadata / Audit**

| Column | Source | Description |
|--------|--------|-------------|
| `[Is Primary]` | `CAST(j.isprimary AS int)` | Whether this is the primary injury for the person |
| `[Is data from migration]` | `CAST(j.frommigration AS int)` | Whether record was migrated from legacy |
| `[Has Long Description]` | `j.hasld` | Maximo flag (note: does not reflect LONGDESCRIPTION CTE results) |
| `[Language Code]` | `j.langcode` | Language code |
| `[Fabric Loaded Date]` | `j.FABRIC_LOADED_DATE` | When loaded into Fabric |
| `[Fabric Loaded By]` | `j.FABRIC_LOADED_BY` | Identity that loaded record |

---

### 8.5 `maximo.VW_Outcome` (v2)

| Property | Value |
|----------|-------|
| **Grain** | 1 row per outcome per injury per person per incident |
| **Source table** | `PLUSGOUTCOME` |
| **File** | `VW_Outcome_Fabric.sql` |
| **Row count** | 534 (as of 2026-05-20) |
| **PII** | No — Person Impacted removed; get PII from VW_Injured_Person |

#### CTEs

| CTE | Purpose |
|-----|---------|
| `ld_outcome` | Most-recent LONGDESCRIPTION text for transfer/restriction details. Filters `ldownertable = 'PLUSGOUTCOME'` and `ldownercol = 'TRNSRESTRCTDETAILS'`. Uses `ROW_NUMBER` by `longdescriptionid DESC`, takes `rn = 1`. |
| `outcome_ranked` | Ranks outcomes by severity. Two rankings: (1) `outcome_rank` — within the same injury (partition by `ticketid, plusgincpersonid, injorillid`); (2) `incident_rank` — across all persons/injuries for the whole incident (partition by `ticketid`). Severity order: FATALITY(1) > LOSTTIME(2) > RESTRICTED(3) > MEDICAL(4) > FIRSTAID(5) > OTHER(6). Ties broken by most recent `outcomebegin`. |

#### Join Strategy

| Source | Join Type | Key | Filter | Reason |
|--------|-----------|-----|--------|--------|
| `outcome_ranked` | Base (CTE) | — | — | All outcomes with severity ranks |
| `TICKET` | `LEFT JOIN` | `ticketid` | `class = 'INCIDENT'` | Get `ticketuid` (see §8.6) |
| `ld_outcome` | `LEFT JOIN` | `ldkey = plusgoutcomeid` | `rn = 1` | Transfer/restriction details text |

#### Output Columns (20 columns)

**Keys / Identifiers**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Incident ID]` | `r.ticketid` | varchar | Human-readable incident number |
| `[Ticket UID]` | `t.ticketuid` | bigint | FK to VW_Incident |
| `[Incident Person Id]` | `r.plusgincpersonid` | bigint | Person record ID |
| `[Illness or Injury]` | `r.injorillid` | int | Injury sequence number |
| `[Unique Id]` | `r.plusgoutcomeid` | bigint | Outcome record PK |
| `[tckt_prsn_joinid]` | Computed | varchar(200) | FK → VW_Injured_Person |
| `[tckt_prson_inj_joinid]` | Computed | varchar(300) | FK → VW_Injury_and_Illness_Detail |

**Outcome Details**

| Column | Source | Type | Description |
|--------|--------|------|-------------|
| `[Outcome]` | `r.outcome` | varchar | Outcome type: FATALITY, LOSTTIME, RESTRICTED, MEDICAL, FIRSTAID, or OTHER |
| `[Date of Death]` | `r.dod` | datetime2 | If outcome is FATALITY |
| `[Start Date]` | `r.outcomebegin` | datetime2 | When outcome period began |
| `[End Date]` | `r.outcomeend` | datetime2 | When outcome period ended |
| `[Days Absent/Transferred/Restricted]` | `r.injorilldays` | int | OSHA days-away / restricted / transferred count |
| `[Transfer/Restriction Details]` | `ld.ldtext` | varchar(max) | From LONGDESCRIPTION — may contain HTML |
| `[Most Serious Outcome]` | `CAST(r.mostserious AS int)` | int | Maximo flag: 1 = most serious for this injury |

**Rankings (derived)**

| Column | Source | Description |
|--------|--------|-------------|
| `[Outcome Rank]` | `outcome_rank` | Severity rank within the same injury (1 = worst). Use `WHERE [Outcome Rank] = 1` to get the most severe outcome per injury. |
| `[Incident Rank]` | `incident_rank` | Severity rank across the entire incident (1 = worst). Use `WHERE [Incident Rank] = 1` to get the single worst outcome for the incident. |

**Metadata / Audit**

| Column | Source | Description |
|--------|--------|-------------|
| `[Is data from migration]` | `CAST(r.frommigration AS int)` | Whether record was migrated from legacy |
| `[Has Long Description]` | `r.hasld` | Maximo flag |
| `[Fabric Loaded Date]` | `r.FABRIC_LOADED_DATE` | When loaded into Fabric |
| `[Fabric Loaded By]` | `r.FABRIC_LOADED_BY` | Identity that loaded record |

---

### 8.6 Critical: The TICKET `class` Filter

**Problem:** The `maximo.TICKET` table contains rows for multiple classes — `INCIDENT`, `SR` (Service Request), `INVESTIGATION`, and potentially others. The `ticketid` column is **NOT unique** across classes. For example, ticketid `19118` has both a class=`INCIDENT` row (ticketuid `62014`) and a class=`SR` row (ticketuid `62204`).

**Impact:** If you join to TICKET on `ticketid` alone (without a class filter), every person/injury/outcome row for that incident will **fan out** — producing 2× rows (one per class). This was caught during validation as 17 duplicate incident-person pairs.

**Fix:** All three views use:

```sql
LEFT JOIN maximo.TICKET t ON t.ticketid = <alias>.ticketid AND t.class = 'INCIDENT'
```

**Why `VW_Incident` doesn't need this filter:** VW_Incident joins TICKET via `ticketuid` to `INCIDENT` table (`INNER JOIN maximo.INCIDENT i ON i.ticketuid = t.ticketuid`). Since only INCIDENT-class tickets exist in the `INCIDENT` table, the INNER JOIN naturally filters to the correct class.

**Edge case:** Ticketid `1131` has class `INVESTIGATION` (not INCIDENT or SR). Its 2 person records and 2 injury records will have `[Ticket UID] = NULL` because no INCIDENT-class row exists. This is correct behavior — those are investigation records, not incident records.

> **⚠️ If you create new views that join to TICKET on `ticketid`, always include `AND t.class = 'INCIDENT'` in the join condition.**

---

### 8.7 The LONGDESCRIPTION Pattern

Maximo stores rich-text field values in a central `maximo.LONGDESCRIPTION` table rather than in base table columns. This is a platform-wide pattern — whenever you see a NULL text column on a Maximo table that should have data, check LONGDESCRIPTION.

#### How it works

| LONGDESCRIPTION Column | Purpose |
|------------------------|---------|
| `ldownertable` | Which source table (e.g., `PLUSGINJORILL`, `PLUSGOUTCOME`, `TICKET`) |
| `ldownercol` | Which field on that table (e.g., `JUSTBEFORE`, `INJORILLDESC`, `TRNSRESTRCTDETAILS`) |
| `ldkey` | FK back to the source table's PK (e.g., `plusginjorillid`, `plusgoutcomeid`, `ticketuid`) |
| `ldtext` | The actual text content (may contain HTML) |
| `longdescriptionid` | Auto-increment PK — higher = more recent revision |

#### Known mappings used in these views

| Owner Table | Owner Column | ldkey maps to | Used in View |
|-------------|-------------|---------------|-------------|
| `PLUSGINJORILL` | `JUSTBEFORE` | `plusginjorillid` | VW_Injury_and_Illness_Detail |
| `PLUSGINJORILL` | `INJORILLDESC` | `plusginjorillid` | VW_Injury_and_Illness_Detail |
| `PLUSGINJORILL` | `OBJSUBS` | `plusginjorillid` | VW_Injury_and_Illness_Detail |
| `PLUSGOUTCOME` | `TRNSRESTRCTDETAILS` | `plusgoutcomeid` | VW_Outcome |
| `TICKET` | *(description)* | `ticketuid` | VW_Incident (Long Summary) |

#### The CTE pattern for retrieving LONGDESCRIPTION text

```sql
WITH ld_<name> AS (
    SELECT
        ld.ldkey,
        ld.ldownercol,                          -- include if multiple fields
        CAST(ld.ldtext AS varchar(max)) AS ldtext,
        ROW_NUMBER() OVER (
            PARTITION BY ld.ldkey, ld.ldownercol -- partition by both if multiple fields
            ORDER BY ld.longdescriptionid DESC   -- latest revision first
        ) AS rn
    FROM maximo.LONGDESCRIPTION ld
    WHERE ld.ldownertable = '<TABLE_NAME>'
      AND ld.ldownercol IN ('<FIELD1>', '<FIELD2>')  -- or = '<FIELD>' for single
)
-- Then join:
LEFT JOIN ld_<name> ON ld_<name>.ldkey = <source>.PK
                    AND ld_<name>.ldownercol = '<FIELD>'
                    AND ld_<name>.rn = 1
```

> **Why `varchar(max)` instead of `nvarchar(max)`?** Fabric distributed SQL mode does not support `nvarchar(max)` in all contexts. Use `varchar(max)` for compatibility.

---

### 8.8 Composite Join Keys

The three person/injury/outcome views use pipe-delimited composite keys for Power BI relationships. This is required because Power BI semantic models need single-column relationship keys.

| Key Name | Pattern | Used By | Joins To |
|----------|---------|---------|----------|
| `[tckt_prsn_joinid]` | `ticketid\|plusgincpersonid` | VW_Injury_and_Illness_Detail, VW_Outcome | VW_Injured_Person |
| `[tckt_prson_inj_joinid]` | `ticketid\|plusgincpersonid\|injorillid` | VW_Outcome | VW_Injury_and_Illness_Detail |

These are computed in each view using:

```sql
CAST(ticketid + '|' + CAST(plusgincpersonid AS varchar(20)) AS varchar(200))
```

> **Note:** These keys use `ticketid` (not `ticketuid`) because the person/injury/outcome source tables (`PLUSGINCPERSON`, `PLUSGINJORILL`, `PLUSGOUTCOME`) only have `ticketid` columns. The `ticketuid` is obtained via the TICKET join and used for connecting up to VW_Incident.

---

### 8.9 PII Consolidation

As of v2, **Person Impacted** (`personimpacted` / `personid`) and personal contact details exist **only** in `VW_Injured_Person`. They were removed from `VW_Injury_and_Illness_Detail` and `VW_Outcome` to:

1. Minimize PII exposure in downstream reports
2. Ensure a single authoritative source for person data
3. Reduce redundancy across views

To get person details for an injury or outcome record, join via `[tckt_prsn_joinid]`:

```sql
SELECT o.*, p.[Person Impacted], p.[Job Title]
FROM maximo.VW_Outcome o
JOIN maximo.VW_Injured_Person p ON p.tckt_prsn_joinid = o.tckt_prsn_joinid
```

---

### 8.10 Validation Results (2026-05-20)

| Test | Description | Result |
|------|-------------|--------|
| P1 | VW_Injured_Person: no duplicate rows | ✅ PASS |
| P2 | VW_Injured_Person: Ticket UID not null | ⚠️ 2 NULLs — ticketid `1131` is class INVESTIGATION (expected) |
| P3 | VW_Injured_Person: old column names removed | ✅ PASS |
| P4 | VW_Injured_Person: new column names exist | ✅ PASS |
| D1 | VW_Injury_and_Illness_Detail: no duplicate rows | ✅ PASS |
| D2 | VW_Injury_and_Illness_Detail: Ticket UID not null | ⚠️ 2 NULLs — same INVESTIGATION ticket (expected) |
| D3 | VW_Injury_and_Illness_Detail: LONGDESCRIPTION fields populated | ✅ PASS |
| D4 | VW_Injury_and_Illness_Detail: old column names removed | ✅ PASS |
| D5 | VW_Injury_and_Illness_Detail: new column names exist | ✅ PASS |
| D6 | VW_Injury_and_Illness_Detail: join keys match VW_Injured_Person | ✅ PASS |
| O1 | VW_Outcome: no duplicate rows | ✅ PASS |
| O2 | VW_Outcome: Ticket UID not null | ⚠️ Same INVESTIGATION ticket (expected) |
| O3 | VW_Outcome: Transfer/Restriction Details populated | ✅ PASS |
| O4 | VW_Outcome: old column names removed | ✅ PASS |
| O5 | VW_Outcome: join keys match VW_Injury_and_Illness_Detail | ✅ PASS |
| O6 | VW_Outcome: severity ranking valid | ✅ PASS |
| X1 | Row counts: Person=609, Detail=572, Outcome=534 | ✅ Reasonable |

---

### 8.11 Fabric SQL Constraints

These views are deployed to a **Fabric Lakehouse SQL Analytics Endpoint** which runs in distributed SQL mode. Key constraints that affect view development:

| Feature | Supported? | Workaround |
|---------|-----------|------------|
| `XML .value()` | ❌ No | Cannot use XML parsing for HTML stripping |
| `STRING_SPLIT` with 3 args | ❌ No | Use 2-arg version only |
| Recursive CTEs | ❌ No | Flatten hierarchies manually |
| `nvarchar(max)` | ⚠️ Limited | Use `varchar(max)` instead |
| `CREATE OR ALTER VIEW` | ✅ Yes | Standard deployment method |
| `ROW_NUMBER()` | ✅ Yes | Used extensively for latest-revision logic |
| `STRING_AGG()` | ✅ Yes | Used in VW_Incident for category concatenation |
| `CROSS APPLY` | ✅ Yes | Available but not used in these views |
| `TRY_CAST()` | ✅ Yes | Available for safe type conversion |

---

### 8.12 Deployment Checklist

When deploying or re-deploying these views:

1. **Open** the Fabric SQL query editor for the **LH_Silver SQL Analytics Endpoint**
2. **Paste** the entire `*_Fabric.sql` file content and execute
3. After deploying `VW_Injury_and_Illness_Detail`, run:
   ```sql
   DROP VIEW IF EXISTS [maximo].[VW_Injury_Detail];
   ```
4. **Verify** by running the validation tests in §8.10
5. All SQL files live in `Fabric Silver Views\` with documentation in `Fabric Silver Views\Documentation\`

---

## 9. Investigation Views

The investigation views support the **Incidents & Investigations** semantic model. They surface investigation records (class = `INVESTIGATION`) that originate from incidents (origrecordclass = `INCIDENT`) in the Maximo TICKET table.

### 9.1 Relationship Diagram

```
VW_Incident
    │  join on [Originating Record ID] = [Incident ID]
    │          (or [Originating Record FK ID] = composite key)
    ▼
VW_Investigation                     (1 row per investigation — latest per incident)
    │
    ├──→ VW_Investigation_Actions    (1:1 — open/closed action counts)
    │      join on [Ticket PK ID]
    │
    ├──→ VW_Investigation_RCFA_Results  (1:many — root cause entries)
    │      join on [Investigation ID] = [Ticket]
    │
    └──→ VW_Investigation_Reference  (pre-joined denormalized view)
           combines all 3 above; grain fans out to 1 row per RCFA result
```

### 9.2 Deployment Order

⚠️ `VW_Investigation_Reference` depends on the other 3 views. Deploy in this order:

```
1. VW_Investigation_RCFA_Results   (no dependencies)
2. VW_Investigation_Actions        (no dependencies)
3. VW_Investigation                (no dependencies)
4. VW_Investigation_Reference      (depends on 1, 2, 3)
```

---

### 9.3 `maximo.VW_Investigation`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per investigation (latest investigation per originating incident) |
| **Filter** | `class = 'INVESTIGATION' AND origrecordclass = 'INCIDENT'` |
| **File** | `VW_Investigation_Fabric.sql` |
| **Replaces** | "Investigations" table in the semantic model (previously built via Power Query from `dbo.problem`) |

#### CTEs

| CTE | Purpose |
|-----|---------|
| `ld_ranked` | Most-recent long description per ticket (`ROW_NUMBER` by `longdescriptionid DESC`, partitioned by `ldkey`) |
| `inv_sub` | Deduplicates to the **latest** investigation per originating incident via `MAX(ticketid)`. Also computes `[Investigation Per Incident]` count. |

#### Key Design Choices

1. **Latest investigation per incident** — `inv_sub` uses `MAX(ticketid)` grouped by `origrecordid` to keep only the most recent investigation, matching the original M query logic.
2. **Investigation Lead name resolution** — `LEFT JOIN maximo.PERSON` on `plusginvestlead` to get `displayname`, eliminating the Power Query "User" table merge.
3. **ROOTCAUSEANALYSIS → RCA** — `CASE` expression replaces verbose `plusginvesttype` value with `'RCA'` to match existing PQ transformation.
4. **HTML in Long Description** — raw HTML preserved in Silver; stripping handled downstream in Power Query (consistent pattern).

#### JOINs

| Target | Type | Key | Notes |
|--------|------|-----|-------|
| `inv_sub` | `INNER JOIN` | `subID = t.ticketid` | Deduplication — only latest investigation survives |
| `ld_ranked` | `LEFT JOIN` | `ldkey = t.ticketuid`, `rn = 1` | Most-recent long description |
| `maximo.PERSON` | `LEFT JOIN` | `personid = t.plusginvestlead` | Resolve lead name |

#### Column Dictionary

| Column | Source | Description |
|--------|--------|-------------|
| **Keys / Identifiers** | | |
| [TICKETUID] | `t.ticketuid` | Unique investigation ID (integer PK) |
| [Investigation ID] | `t.ticketid` | Investigation ticket ID (e.g., `INV1234`) |
| [Class] | `t.class` | Always `INVESTIGATION` |
| [Originating Record ID] | `t.origrecordid` | Parent incident's ticketid |
| [Originating Record Class] | `t.origrecordclass` | Always `INCIDENT` |
| **Composite Keys** | | |
| [Ticket PK ID] | Computed | `ticketid_class` — PK for joining to Actions |
| [Originating Record FK ID] | Computed | `origrecordid_origrecordclass` — FK to VW_Incident |
| [Asset FK ID] | Computed | `assetnum_siteid` — FK to asset dimensions |
| [Location FK ID] | Computed | `location_siteid` — FK to location dimensions |
| **Status & Classification** | | |
| [Investigation Status] | `t.status` | Current status |
| [Status Date] | `t.statusdate` | Last status change |
| [Investigation Type] | `t.plusginvesttype` | Type (with `ROOTCAUSEANALYSIS` → `RCA`) |
| [Investigation Required] | `t.plusginvestreqd` | Whether investigation was required |
| [RCFA Analysis Type] | `t.plusgrcfaanystype` | Type of RCFA analysis |
| [Class Structure ID] | `t.classstructureid` | Classification structure |
| [Failure Code] | `t.failurecode` | Failure classification code |
| [Impact] | `t.impact` | Impact level |
| [Urgency] | `t.urgency` | Urgency level |
| [Reported Priority] | `t.reportedpriority` | Reporter-assigned priority |
| [Internal Priority] | `t.internalpriority` | Internal priority assignment |
| **Description** | | |
| [Summary] | `t.description` | Short description |
| [Long Description] | `ld_ranked.ldtext` | Full description (may contain HTML) |
| **Dates** | | |
| [Report Date] | `t.reportdate` | When investigation was reported |
| [Actual Start] | `t.actualstart` | When work actually started |
| [Actual Finish] | `t.actualfinish` | When investigation completed |
| [Change Date] | `t.changedate` | Last modification date |
| [Target Start] | `t.targetstart` | Planned start |
| [Target Finish] | `t.targetfinish` | Planned finish |
| [Target Contact Date] | `t.targetcontactdate` | Target contact date |
| [Actual Contact Date] | `t.actualcontactdate` | Actual contact date |
| **People** | | |
| [Reported By] | `t.reportedby` | Reporter person ID |
| [Reported Email] | `t.reportedemail` | Reporter email |
| [Reported Phone] | `t.reportedphone` | Reporter phone |
| [Owner] | `t.owner` | Record owner |
| [Owner Group] | `t.ownergroup` | Owner group |
| [Supervisor] | `t.supervisor` | Supervisor |
| [Investigation Lead] | `t.plusginvestlead` | Lead person ID |
| [Investigation Lead Name] | `p_lead.displayname` | Lead display name (resolved via PERSON join) |
| **RCFA Fields** | | |
| [RCFA Lead] | `t.plusgrcfalead` | RCFA lead person |
| [RCFA Requested By] | `t.plusgrcfareqby` | Who requested the RCFA |
| [RCFA Approved By] | `t.plusgrcfaappby` | Who approved the RCFA |
| [RCFA Approved] | `t.plusgrcfaapp` | Approval status |
| [RCFA Actual Date] | `t.plusgrcfaactldate` | Actual RCFA completion date |
| [RCFA Target Date] | `t.plusgrcfatargdate` | Target RCFA date |
| [Root Cause Identified] | `t.plusgrootcauseiden` | Whether root cause was found |
| [Analysis Complete] | `t.plusganalysiscomp` | Whether analysis is complete |
| [Action Summary] | `t.plusgactionsumm` | Summary of actions taken |
| **Location & Asset** | | |
| [Site] | `t.siteid` | Site ID |
| [Organization] | `t.orgid` | Organization |
| [Location] | `t.location` | Location code |
| [Asset] | `t.assetnum` | Asset number |
| [GL Account] | `t.glaccount` | GL account |
| [Facility ID] | `t.facilityid` | Facility identifier |
| [Asset Site ID] | `t.assetsiteid` | Asset site |
| [Asset Org ID] | `t.assetorgid` | Asset organization |
| **Investigation Attributes** | | |
| [Is Investigation] | `t.plusgisinvestig` | Investigation flag |
| [Is Lessons Learned] | `t.plusgislesslearned` | Lessons learned flag |
| [Mandatory RCA] | `t.plusgmanrca` | RCA mandatory flag |
| [Mandatory RCFA] | `t.plusgmanrcfa` | RCFA mandatory flag |
| [Mandatory HF] | `t.plusgmanhf` | Human Factors mandatory flag |
| [Incident Type] | `t.plusginctype` | Incident type classification |
| [Incident Context] | `t.plusginccontext` | Incident context |
| [High Context] | `t.plusghighcontext` | High context flag |
| [Incident Group] | `t.plusgincidentgroup` | Incident group |
| [Potential Consequence] | `t.plusgpotenconsq` | Potential consequence |
| [Potential Consequence ID] | `t.plusgpotenconsqid` | Potential consequence ID |
| [Potential Consequence Severity] | `t.plusgpotenconsqsevr` | Potential consequence severity |
| [Actual Consequence] | `t.plusgactconsq` | Actual consequence |
| [Actual Consequence ID] | `t.plusgactconsqid` | Actual consequence ID |
| [Actual Consequence Severity] | `t.plusgactconsqsevr` | Actual consequence severity |
| [Strategic] | `t.plusgstrategic` | Strategic flag |
| [Review Required] | `t.plusgisreviewreqd` | Review required flag |
| **Affected Person** | | |
| [Affected Person] | `t.affectedperson` | Affected person ID |
| [Affected Email] | `t.affectedemail` | Affected person email |
| [Affected Phone] | `t.affectedphone` | Affected person phone |
| [Affected Date] | `t.affecteddate` | Affected date |
| **Computed** | | |
| [Investigation Per Incident] | `inv_sub` CTE | Count of investigations for the originating incident |
| **Audit** | | |
| [Row Stamp] | `t.rowstamp` | Maximo row version |
| [Fabric Loaded Date] | `t.FABRIC_LOADED_DATE` | ETL load timestamp |
| [Fabric Loaded By] | `t.FABRIC_LOADED_BY` | ETL agent |

---

### 9.4 `maximo.VW_Investigation_Actions`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per investigation |
| **Filter** | `class = 'INVESTIGATION' AND origrecordclass = 'INCIDENT' AND relatedrecclass = 'ACTTRACK'` |
| **File** | `VW_Investigation_Actions_Fabric.sql` |
| **Replaces** | "INV with ACTIONS" table in the semantic model |

#### Logic

Joins `TICKET → RELATEDRECORD → WORKORDER` to find action-tracking work orders linked to each investigation, then pivots status into open/closed counts:

- **CLOSED** = `status IN ('CAN', 'CLOSE', 'COMP')`
- **OPEN** = all other statuses

#### JOINs

| Target | Type | Key | Notes |
|--------|------|-----|-------|
| `maximo.RELATEDRECORD` | `INNER JOIN` | `t.ticketid = rr.recordkey AND t.class = rr.class` | Related records |
| `maximo.WORKORDER` | `INNER JOIN` | `rr.relatedreckey = wo.wonum AND rr.relatedrecclass = wo.woclass AND rr.relatedrecsiteid = wo.siteid` | Actual work orders |

#### Column Dictionary

| Column | Source | Description |
|--------|--------|-------------|
| [Ticket PK ID] | Computed | `ticketid_class` — join key to VW_Investigation |
| [Originating Record FK ID] | Computed | `origrecordid_origrecordclass` |
| [TICKETUID] | `t.ticketuid` | Investigation unique ID |
| [Open Actions] | `SUM(CASE...)` | Count of work orders NOT in CAN/CLOSE/COMP |
| [Closed Actions] | `SUM(CASE...)` | Count of work orders in CAN/CLOSE/COMP |

---

### 9.5 `maximo.VW_Investigation_RCFA_Results`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per RCFA result entry |
| **Filter** | None — includes all RCFA results |
| **File** | `VW_Investigation_RCFA_Results_Fabric.sql` |
| **Source Table** | `maximo.PLUSGRCFARESULTS` |
| **Replaces** | "Rcfaresults" table in the semantic model |
| **Join to parent** | `[Ticket]` = `VW_Investigation.[Investigation ID]` |

#### Column Dictionary

| Column | Source | Description |
|--------|--------|-------------|
| [Unique ID] | `r.plusgrcfaresultsid` | RCFA result PK |
| [Ticket] | `r.ticketid` | Investigation ticket ID (FK → VW_Investigation) |
| [Cause] | `r.cause` | Root cause description |
| [Description] | `r.description` | Detailed description |
| [Cause Type] | `r.causetype` | Type (with `ROOTCAUSEANALYSIS` → `RCA`) |
| [Priority] | `r.causepriority` | Cause priority |
| [Improvement Required] | `r.impreqd` | Improvement needed flag |
| [Action Required] | `r.actionreqd` | Action needed flag |
| [Cause Owner] | `r.causeowner` | Person responsible for cause |
| [Remedy] | `r.remedy` | Proposed remedy |
| [Cause Agreed] | `r.causeagreed` | Agreement flag |
| [Cause Agreed By] | `r.causeagreedby` | Who agreed |
| [Solution] | `r.solution` | Solution description |
| [Evidence] | `r.evidence` | Supporting evidence |
| [Sequence] | `r.tri_seq` | Display order |
| [Fabric Loaded Date] | `r.FABRIC_LOADED_DATE` | ETL load timestamp |
| [Fabric Loaded By] | `r.FABRIC_LOADED_BY` | ETL agent |

---

### 9.6 `maximo.VW_Investigation_Reference`

| Property | Value |
|----------|-------|
| **Grain** | 1 row per investigation × RCFA result (investigations without RCFA results appear once with NULLs) |
| **Filter** | Inherited from VW_Investigation |
| **File** | `VW_Investigation_Reference_Fabric.sql` |
| **Replaces** | "Investigations reference" table in the semantic model (previously built via Power Query merges) |
| **Dependencies** | VW_Investigation, VW_Investigation_RCFA_Results, VW_Investigation_Actions |

#### Purpose

Pre-joins all 3 investigation views so the semantic model does not need to perform these merges in Power Query. This is a **convenience/performance view** — it replicates the Power Query merge logic:

1. `VW_Investigation` LEFT JOIN `VW_Investigation_RCFA_Results` ON `[Investigation ID] = [Ticket]`
2. Result LEFT JOIN `VW_Investigation_Actions` ON `[Ticket PK ID]`

#### Columns (superset)

All columns from `VW_Investigation` (see §9.3), plus:

| Column | Source | Description |
|--------|--------|-------------|
| [RCFA Description] | `rcfa.[Description]` | RCFA result description |
| [Cause] | `rcfa.[Cause]` | Root cause |
| [Cause Type] | `rcfa.[Cause Type]` | Cause type (RCA-transformed) |
| [Sequence] | `rcfa.[Sequence]` | RCFA result order |
| [Open Actions] | `act.[Open Actions]` | Open action count |
| [Closed Actions] | `act.[Closed Actions]` | Closed action count |

#### ⚠️ Grain Warning

Because `VW_Investigation_RCFA_Results` is 1:many, this view **fans out** — an investigation with 3 RCFA results produces 3 rows. Consumers must account for this when aggregating (use DISTINCT or filter to avoid double-counting investigation-level metrics).

---

### 9.7 Source Tables

| Table | Purpose | Key |
|-------|---------|-----|
| `maximo.TICKET` | All ticket types (INCIDENT, INVESTIGATION, SR) | `ticketuid` (PK), `ticketid` (natural key) |
| `maximo.LONGDESCRIPTION` | Rich-text storage for all ticket types | `ldkey` → `ticketuid`, `ldownertable = 'TICKET'` |
| `maximo.PERSON` | Person master | `personid` |
| `maximo.RELATEDRECORD` | Links between tickets and other records | `recordkey + class` → `relatedreckey + relatedrecclass` |
| `maximo.WORKORDER` | Work orders (includes action tracking) | `wonum + woclass + siteid` |
| `maximo.PLUSGRCFARESULTS` | RCFA results table | `plusgrcfaresultsid` (PK), `ticketid` (FK to investigation) |

### 9.8 Connecting Investigations to Incidents

To join investigations back to their originating incidents:

```sql
-- From VW_Incident to VW_Investigation
SELECT
    inc.[Incident ID],
    inv.[Investigation ID],
    inv.[Investigation Status],
    inv.[Investigation Lead Name]
FROM [maximo].[VW_Incident] inc
INNER JOIN [maximo].[VW_Investigation] inv
    ON inv.[Originating Record ID] = inc.[Incident ID]
```

Or using composite keys in the semantic model:
- `VW_Investigation.[Originating Record FK ID]` joins to a computed column `CONCAT([Incident ID], '_INCIDENT')` on VW_Incident.
