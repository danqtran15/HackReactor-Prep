# Reverse-Engineering Power BI Semantic Models into SQL Views

> **A Step-by-Step Playbook for Data Analysts & Data Engineers**
>
> Build Silver-layer SQL views in Microsoft Fabric by reverse-engineering Power BI reports and semantic models — using GitHub Copilot CLI in VS Code with MCP tooling.

---

## Table of Contents

1. [Prerequisites & Setup](#1-prerequisites--setup)
2. [Phase 1 — Workspace Discovery](#2-phase-1--workspace-discovery)
3. [Phase 2 — Connect to the Semantic Model](#3-phase-2--connect-to-the-semantic-model)
4. [Phase 3 — Extract Metadata](#4-phase-3--extract-metadata)
5. [Phase 4 — Analyze Transformation Logic](#5-phase-4--analyze-transformation-logic)
6. [Phase 5 — Map Source Tables](#6-phase-5--map-source-tables)
7. [Phase 6 — Design SQL Views](#7-phase-6--design-sql-views)
8. [Phase 7 — Build, Deploy & Iterate](#8-phase-7--build-deploy--iterate)
9. [Phase 8 — Validation](#9-phase-8--validation)
10. [Phase 9 — Documentation](#10-phase-9--documentation)
- [Appendix A — MCP Command Cheat Sheet](#appendix-a--mcp-command-cheat-sheet)
- [Appendix B — Power Query M → SQL Translation Guide](#appendix-b--power-query-m--sql-translation-guide)
- [Appendix C — Validation Test Template](#appendix-c--validation-test-template)
- [Appendix D — Copilot CLI Prompt Templates](#appendix-d--copilot-cli-prompt-templates)

---

## 1. Prerequisites & Setup

### 1.1 VS Code Extensions

Install the following extensions before starting:

| Extension | ID | Purpose |
|---|---|---|
| **Microsoft Fabric Data Engineering** | `synapsevscode.synapse` | Fabric notebook support, lakehouse browsing, and the **Fabric Notebook MCP server** |
| **GitHub Copilot** | `github.copilot` | Inline code suggestions and completions |
| **GitHub Copilot Chat** | `github.copilot-chat` | Chat-based agent capabilities and MCP tool integration |

### 1.2 MCP Servers

**MCP (Model Context Protocol)** servers are tool servers that give Copilot CLI the ability to call live Power BI and Fabric APIs directly from the chat session. Instead of manually navigating the Fabric portal or writing REST API calls, you describe what you need in natural language and Copilot translates that into the correct MCP tool call.

Three MCP servers are used in this workflow:

| MCP Server | What It Does | Key Capabilities |
|---|---|---|
| **Power BI Modeling MCP** (`powerbi-modeling-mcp`) | Connects to Power BI Desktop or Fabric semantic models and exposes read/write modeling operations | Connect to models, list tables/columns/measures/relationships, export TMDL, execute DAX queries, inspect partitions (M source queries) |
| **Fabric MCP** (`fabric_mcp`) | Interfaces with OneLake data plane and Fabric item management | List workspaces, list items (lakehouses/notebooks/reports), browse OneLake files and tables, upload/download files, create items |
| **Fabric Notebook MCP** (`fabric-notebook-mcp`) | Provides notebook, lakehouse, and environment operations in Fabric | List artifacts in workspaces, browse lakehouse tables/files with schema detail, preview table data, get connection code snippets |

> **Note:** MCP servers are configured in VS Code settings or `.vscode/mcp.json`. The Fabric Data Engineering extension auto-registers the Fabric Notebook MCP. The Power BI Modeling MCP and Fabric MCP may need separate configuration — check your organization's setup guide.

### 1.3 Copilot CLI

GitHub Copilot CLI provides a terminal-based agent that can call MCP tools, read/write files, and execute commands:

- **Launch:** Run `copilot` in your terminal, or use VS Code Copilot Chat with MCP tools enabled
- **Verify tools:** Use `/mcp` to manage MCP servers, `/env` to verify loaded tools
- **Key commands:** `/help` for full command list, `/skills` to browse available skills

### 1.4 Project Folder Structure

Organize your project with a consistent folder structure:

```
project-root/
├── .vscode/
│   ├── settings.json          # MCP server config, skill locations
│   └── extensions.json        # Recommended extensions
├── .github/
│   └── instructions/          # Copilot instruction files
├── Views/
│   ├── VW_MyView_Fabric.sql   # View DDL scripts (Fabric variant)
│   └── VW_MyView_Validation.sql  # Validation test scripts
├── Documentation/
│   ├── Silver_Views_Documentation.md  # Technical view docs
│   └── Validation_Report.md           # Test results
└── README.md
```

### 1.5 Authentication & Permissions

| Requirement | Details |
|---|---|
| **Copilot CLI** | Authenticates via your VS Code GitHub login |
| **MCP servers** | Authenticate to Fabric/Power BI via your Azure AD / Entra ID credentials (same as VS Code Fabric extension login) |
| **Read access** | At least **Viewer** role on the Power BI workspace to read semantic model metadata |
| **Write access** | **Contributor** or higher on the Fabric Lakehouse workspace to deploy views |

---

## 2. Phase 1 — Workspace Discovery

### 2.1 Why Start Here

Before you can reverse-engineer transformation logic, you need to identify:
- Which **workspace** contains the report
- Which **semantic model** (dataset) powers it
- Whether other reports share the same semantic model (to understand full impact)
- Which **Lakehouse** contains the raw source tables

### 2.2 Scanning for Reports and Semantic Models

Ask Copilot to list artifacts in the target workspace:

```
Copilot prompt: "List all reports and datasets in the 'My Workspace' workspace"
```

Behind the scenes, Copilot calls:
- `fabric-notebook-mcp → list_artifacts` with `workspace: "My Workspace"` and optionally `artifact_type: "Report"` or `artifact_type: "Dataset"`

**What to look for:**
- Match the report name to your target
- Note the semantic model (dataset) **ID** — you'll need it in Phase 2
- Look for other reports that reference the same dataset — these are "related reports" that share the same transformation logic

### 2.3 Finding the Lakehouse

Locate the Lakehouse that contains the raw source tables:

```
Copilot prompt: "List all lakehouses in the 'Data Platform' workspace"
```

Behind the scenes:
- `fabric-notebook-mcp → list_artifacts` with `artifact_type: "Lakehouse"`
- Then `fabric-notebook-mcp → list_fabric_artifact_contents` with `artifact_type: "lakehouse"` and `search_type: "tables"` to see what tables exist

### 2.4 Browsing Lakehouse Tables

Inspect what raw tables are available and their structure:

```
Copilot prompt: "Show me all tables in the 'LH_Silver' lakehouse with their columns"
```

Behind the scenes:
- `list_fabric_artifact_contents` returns table names, column names, data types
- `preview_lakehouse_table` returns sample rows for quick inspection

### 2.5 Decision Checkpoint

Before proceeding, confirm:

- [ ] Target report identified (name + ID)
- [ ] Semantic model identified (name + ID)
- [ ] Related reports cataloged (any other reports using the same model?)
- [ ] Source Lakehouse identified (name + ID + workspace)
- [ ] Source tables confirmed to exist in the Lakehouse

---

## 3. Phase 2 — Connect to the Semantic Model

### 3.1 Why Connect

Connecting to the semantic model gives Copilot CLI **read access to all model metadata**: tables, columns, relationships, measures, partitions (source queries), and DAX expressions. This is the foundation for reverse-engineering.

### 3.2 Connecting via Power BI Modeling MCP

```
Copilot prompt: "Connect to the 'Sales Analytics' semantic model
in the 'My Workspace' workspace"
```

Behind the scenes, Copilot calls:
- `powerbi-modeling-mcp → connection_operations` with `operation: "ConnectFabric"`, `workspaceName: "My Workspace"`, `semanticModelName: "Sales Analytics"`

The connection returns a **connection name** (auto-generated) that subsequent commands use automatically.

### 3.3 Verifying the Connection

```
Copilot prompt: "Show me the current connection details"
```

Behind the scenes:
- `connection_operations` with `operation: "GetConnection"` or `"ListConnections"`

A successful connection shows: connection name, data source URL, and database name.

**Smoke test** — run a quick DAX query to confirm:
```
Copilot prompt: "Run this DAX query: EVALUATE ROW('Test', 1)"
```

### 3.4 Troubleshooting

| Issue | Cause | Fix |
|---|---|---|
| "Cannot find semantic model" | Name doesn't match exactly (case-sensitive) | Use `list_artifacts` to get the exact name |
| Authentication error | Azure AD token expired | Re-authenticate in VS Code (`F1` → `Azure: Sign In`) |
| Connection timeout | Model is in a paused Fabric capacity | Resume the capacity in the Fabric portal first |
| "Dataset not found" | Model was renamed or moved | Re-run workspace discovery |
| Read-only error | Insufficient permissions | Request at least Viewer role on the workspace |

### 3.5 Connection Lifecycle

- Connections **persist for the duration** of your Copilot CLI session
- If you restart Copilot CLI or VS Code, you need to **reconnect**
- You can have **multiple connections** open (useful when comparing models)
- The **last-used connection** is remembered — subsequent commands use it automatically

---

## 4. Phase 3 — Extract Metadata

### 4.1 What to Extract

| Artifact | MCP Tool | Why You Need It |
|---|---|---|
| Table list | `table_operations → List` | Understand the model's structure — fact tables, dimensions, calculated tables |
| Relationships | `relationship_operations → List` | Map joins between tables — cardinality, cross-filter direction, active/inactive |
| Measures | `measure_operations → List` | Catalog all DAX calculations — these encode business rules |
| Measure expressions | `measure_operations → Get` | Get the actual DAX code for each measure |
| TMDL export | `table_operations → ExportTMDL` | Full TMDL definition including columns, partitions, format strings |
| Partition source queries | `partition_operations → List` | **Critical** — the M (Power Query) or SQL that defines how each table is populated |
| Column details | `column_operations → List` | Data types, format strings, sort-by-column, descriptions |

### 4.2 Listing Tables

```
Copilot prompt: "List all tables in this semantic model"
```

Behind the scenes: `table_operations` with `operation: "List"`

**How to interpret results:**
- **Filter out** auto-generated `LocalDateTable_*` and `DateTableTemplate_*` tables — these are not reverse-engineering targets
- Identify **sourced tables** (have M query/SQL source) vs. **calculated tables** (have DAX expression)
- Categorize: fact tables, dimension tables, bridge tables, reference/merge tables

### 4.3 Listing Relationships

```
Copilot prompt: "List all relationships in the model"
```

Behind the scenes: `relationship_operations` with `operation: "List"`

**What to capture:**
- `fromTable.fromColumn` → `toTable.toColumn` (the join columns)
- **Cardinality:** `Many-to-One`, `One-to-One`, `Many-to-Many`
- **Cross-filter direction:** `Single`, `Both`
- **`isActive`:** Inactive relationships are used with `USERELATIONSHIP()` in DAX

> Document these — they tell you how the semantic model joins tables, which directly informs your SQL view JOINs.

### 4.4 Extracting Measures

```
Copilot prompt: "List all measures with their DAX expressions"
```

Behind the scenes:
- `measure_operations` with `operation: "List"` (returns names, table assignments, display folders)
- `measure_operations` with `operation: "Get"` and `references` (returns full DAX expression)

**What to look for in DAX:**
- `CALCULATE` with filters — often encodes business rules
- `DISTINCTCOUNT` vs `COUNT` — tells you about grain expectations
- `DIVIDE`, `SWITCH`, `IF` — conditional logic that may need SQL CASE statements
- `USERELATIONSHIP` — signals inactive relationship usage

### 4.5 Exporting TMDL

```
Copilot prompt: "Export the TMDL for the 'Orders' table"
```

Behind the scenes: `table_operations` with `operation: "ExportTMDL"`, `references: [{ name: "Orders" }]`

TMDL (Tabular Model Definition Language) is a YAML-like format that captures column definitions with data types, partition definitions with source expressions, format strings, and annotations.

### 4.6 Extracting Partition Source Queries ⭐

> **This is the single most important extraction step.**

```
Copilot prompt: "Show me the partition source queries for the 'Orders' table"
```

Behind the scenes: `partition_operations` with `operation: "List"`, `filter: { tableName: "Orders" }`

Partitions contain the source expressions — either **Power Query M** code or **native SQL** — that define how each table's data is loaded.

#### Example M Expression:
```m
let
    Source = Sql.Database("server.database.windows.net", "mydb"),
    dbo_orders = Source{[Schema="dbo", Item="orders"]}[Data],
    #"Filtered Rows" = Table.SelectRows(dbo_orders, each [status] <> "DELETED"),
    #"Renamed Columns" = Table.RenameColumns(#"Filtered Rows",
        {{"order_id", "Order ID"}, {"cust_id", "Customer ID"}}),
    #"Added Custom" = Table.AddColumn(#"Renamed Columns", "Order Key",
        each [order_id] & "_" & [order_type])
in
    #"Added Custom"
```

From this you can extract:
1. **Source table:** `dbo.orders`
2. **Filters:** `status <> 'DELETED'`
3. **Column renames:** `order_id` → `Order ID`, `cust_id` → `Customer ID`
4. **Computed columns:** `Order Key` = `order_id + '_' + order_type`

#### Example Native SQL Source:
```m
let
    Source = Sql.Database("server", "db"),
    result = Value.NativeQuery(Source,
        "SELECT * FROM dbo.orders WHERE status <> 'DELETED'",
        null, [EnableFolding=true])
in
    result
```

Here the actual SQL is embedded — you can lift it almost directly.

### 4.7 Extraction Checklist

- [ ] All non-date tables listed and categorized (fact, dimension, calculated, reference)
- [ ] All relationships documented (from/to, cardinality, cross-filter, active/inactive)
- [ ] All measures cataloged with full DAX expressions
- [ ] Partition M/SQL expressions extracted for every target table
- [ ] TMDL exported for tables with complex column definitions

---

## 5. Phase 4 — Analyze Transformation Logic

### 5.1 Goal

Transform the extracted metadata into a clear understanding of what each table does, so you can write equivalent SQL views. This is detective work — you're piecing together business logic from M expressions, DAX measures, and relationship patterns.

### 5.2 Deconstructing Power Query M Expressions

Follow this step-by-step approach for each M expression:

1. **Find the source table** — Look for `Sql.Database(...)` or table references
2. **Trace the filter chain** — `Table.SelectRows` calls are `WHERE` clauses
3. **Map column renames** — `Table.RenameColumns` gives you friendly name → source column mapping
4. **Identify computed columns** — `Table.AddColumn` with `each` expressions become SQL expressions
5. **Find joins/merges** — `Table.NestedJoin` = SQL JOINs. Note the join type.
6. **Spot aggregations** — `Table.Group` = `GROUP BY`
7. **Check for deduplication** — `Table.Distinct` or sorted + filtered patterns

### 5.3 M → SQL Quick Reference

| M Function | SQL Equivalent |
|---|---|
| `Table.SelectRows(t, each [col] = "X")` | `WHERE col = 'X'` |
| `Table.RenameColumns(t, {{"old", "new"}})` | `SELECT old AS [new]` |
| `Table.AddColumn(t, "New", each [A] & "_" & [B])` | `CONCAT(A, '_', B) AS [New]` |
| `Table.NestedJoin(..., JoinKind.LeftOuter)` | `LEFT JOIN t2 ON t1.key = t2.key` |
| `Table.Group(t, {"grp"}, {{"cnt", each Table.RowCount(_)}})` | `SELECT grp, COUNT(*) GROUP BY grp` |
| `Table.Distinct(t, {"col"})` | `ROW_NUMBER() OVER (PARTITION BY col ...) = 1` |
| `Table.TransformColumns(t, {{"col", Text.Upper}})` | `UPPER(col)` |
| `Table.ReplaceValue(t, "old", "new", ...)` | `CASE WHEN col = 'old' THEN 'new' ELSE col END` |
| `Table.ExpandTableColumn(t, "merged", {...})` | Columns from the JOINed table in SELECT |

> See **Appendix B** for the complete translation guide.

### 5.4 Categorizing DAX Measures

Not all DAX measures need to be replicated in SQL views:

| Category | Action | Example |
|---|---|---|
| **Simple aggregation** | Leave in semantic model | `Total Revenue := SUM(Orders[Revenue])` |
| **Filtered aggregation** | May need a SQL column to support the filter | `Active Orders := CALCULATE(COUNT(...), Status = "Active")` |
| **Calculated status/flag** | Consider adding as a SQL computed column | `Is Late := IF(Ship > Due, "Yes", "No")` |
| **Cross-table calculation** | Understand the relationship traversal | `Customer Orders := COUNTROWS(RELATEDTABLE(...))` |

### 5.5 Identifying Deduplication Patterns

A very common pattern: the source has multiple rows per entity, but the model keeps only one (usually the latest).

**SQL approach — ROW_NUMBER:**
```sql
ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY record_id DESC) = 1
```

**SQL approach — MAX + GROUP BY:**
```sql
WITH latest AS (
    SELECT MAX(record_id) AS max_id, parent_id, COUNT(*) AS records_per_parent
    FROM source GROUP BY parent_id
)
SELECT t.* FROM source t INNER JOIN latest ON latest.max_id = t.record_id;
```

### 5.6 Recognizing Composite Key Patterns

Semantic models often create composite keys by concatenating columns:
- M: `Table.AddColumn(t, "Key", each [id] & "_" & [type])`
- SQL: `CONCAT(id, '_', type) AS [Key]`

These serve as:
- **Primary keys** (PK ID) — join target for this view
- **Foreign keys** (FK ID) — link to related views

### 5.7 Understanding Reference Tables

In Power Query, a "Reference" table builds on another query without re-fetching data:
- Table A: Base query (reads from source)
- Table B: `= TableA` with additional joins/columns

This maps to: **View A** (base), **View B** (`SELECT * FROM View_A LEFT JOIN ...`).

This creates a deployment dependency — View B must be deployed after View A.

### 5.8 Analysis Checklist

- [ ] Each target table's M expression fully deconstructed
- [ ] Source tables, filters, joins, renames, computed columns documented
- [ ] DAX measures categorized (replicate in SQL vs. leave in semantic model)
- [ ] Deduplication logic identified and SQL equivalent planned
- [ ] Composite key patterns documented
- [ ] Reference table dependencies mapped (build order determined)

---

## 6. Phase 5 — Map Source Tables

### 6.1 Goal

Confirm that every source table referenced by the semantic model's M queries actually exists in your Fabric Lakehouse, and that the column names match.

### 6.2 Listing Lakehouse Tables and Columns

```
Copilot prompt: "Show me all tables and columns in the 'LH_Silver' lakehouse"
```

Behind the scenes:
- `fabric-notebook-mcp → list_fabric_artifact_contents` with `artifact_type: "lakehouse"`, `search_type: "tables"`
- `fabric_mcp → onelake_list_tables` with `namespace: "dbo"` for schema-level browsing
- `fabric-notebook-mcp → preview_lakehouse_table` to see sample data

### 6.3 Schema Inspection via SQL

When MCP metadata isn't detailed enough, query the SQL Analytics Endpoint directly:

```sql
-- List all tables in a schema
SELECT TABLE_SCHEMA, TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA = 'dbo'
ORDER BY TABLE_NAME;

-- Get column details for a specific table
SELECT COLUMN_NAME, DATA_TYPE, CHARACTER_MAXIMUM_LENGTH, IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dbo' AND TABLE_NAME = 'orders'
ORDER BY ORDINAL_POSITION;
```

### 6.4 Handling Column Name Mismatches

This is a **very common gotcha**. The semantic model's M query may reference column names that don't match the Lakehouse table. Reasons:
- The original source was a different database with different column names
- Columns were renamed during migration to Fabric
- The Lakehouse mirrors from a different schema version

**Resolution process:**
1. Extract the M query's source column references
2. List the actual Lakehouse table columns via `INFORMATION_SCHEMA`
3. Create a mapping table:

| M Query Column | Lakehouse Column | Notes |
|---|---|---|
| `priority` | `causepriority` | Renamed in source |
| `plusgimprreqd` | `impreqd` | Prefix stripped |
| `order_date` | `orderdate` | Underscore removed |

4. Use the **Lakehouse column names** in your SQL view, and apply friendly names via `AS [Friendly Name]`

### 6.5 Cross-Referencing Semantic Models

Sometimes multiple semantic models reference the same source tables:
- If Model A has already been reverse-engineered, Model B can **reuse those views**
- Identify shared source tables to avoid duplicating view logic

### 6.6 Mapping Checklist

- [ ] Every source table referenced in M queries exists in the Lakehouse
- [ ] Column names verified — mismatches documented in a mapping table
- [ ] Sample data reviewed for at least one key table
- [ ] Cross-references to other semantic models documented
- [ ] Missing tables or columns flagged for investigation

---

## 7. Phase 6 — Design SQL Views

### 7.1 Goal

Translate the transformation logic (from Phase 4) and source table mappings (from Phase 5) into well-structured SQL views.

### 7.2 Naming Conventions

| Element | Convention | Example |
|---|---|---|
| **View name** | `VW_` prefix + descriptive name | `VW_Orders`, `VW_Customer_Summary` |
| **File name** | View name + `_Fabric.sql` | `VW_Orders_Fabric.sql` |
| **Schema** | Match the source schema | `dbo`, `sales`, `analytics` |
| **Column names** | `[Friendly Names]` in brackets | `[Order ID]`, `[Customer Name]` |
| **Audit columns** | Standard set at the end | `[Fabric Loaded Date]`, `[Fabric Loaded By]` |

### 7.3 View Template

```sql
CREATE OR ALTER VIEW [schema].[VW_ViewName] AS

WITH deduped AS (
    -- Deduplication: keep latest record per parent
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY parent_id ORDER BY record_id DESC
        ) AS rn
    FROM [schema].[source_table]
    WHERE /* filter conditions */
),
long_desc AS (
    -- Most recent long description per entity
    SELECT ldkey, ldtext,
        ROW_NUMBER() OVER (
            PARTITION BY ldkey ORDER BY descriptionid DESC
        ) AS rn
    FROM [schema].[descriptions]
    WHERE ldownertable = 'TARGET_TABLE'
)

SELECT
    -- Primary Key / Identifiers
    t.record_id                                    AS [Record ID],
    t.record_uid                                   AS [RECORDUID],

    -- Composite Keys
    CONCAT(t.record_id, '_', t.record_type)        AS [Record PK ID],
    CONCAT(t.parent_id, '_', t.parent_type)        AS [Parent FK ID],

    -- Status & Classification
    t.status                                       AS [Status],
    CASE
        WHEN t.category = 'LONGCATEGORYNAME' THEN 'SHORT'
        ELSE t.category
    END                                            AS [Category],

    -- Descriptions
    t.summary                                      AS [Summary],
    ld.description_text                            AS [Long Description],

    -- Lookups (resolved via JOIN)
    p.display_name                                 AS [Owner Name],

    -- Audit
    t.FABRIC_LOADED_DATE                           AS [Fabric Loaded Date],
    t.FABRIC_LOADED_BY                             AS [Fabric Loaded By]

FROM deduped t
LEFT JOIN long_desc ld ON ld.ldkey = t.record_uid AND ld.rn = 1
LEFT JOIN [schema].[persons] p ON p.person_id = t.owner_id
WHERE t.rn = 1;
```

### 7.4 Common CTE Patterns

**Pattern 1 — Deduplication (keep latest):**
```sql
WITH latest AS (
    SELECT *, ROW_NUMBER() OVER (
        PARTITION BY parent_id ORDER BY record_id DESC
    ) AS rn
    FROM [schema].[source_table]
)
SELECT ... FROM latest WHERE rn = 1;
```

**Pattern 2 — Dedup with count:**
```sql
WITH latest_ids AS (
    SELECT MAX(record_id) AS max_id, parent_id,
           COUNT(*) AS records_per_parent
    FROM [schema].[source_table] GROUP BY parent_id
)
SELECT t.*, sub.records_per_parent
FROM [schema].[source_table] t
INNER JOIN latest_ids sub ON sub.max_id = t.record_id;
```

**Pattern 3 — Conditional aggregation (pivot):**
```sql
SELECT t.record_id,
    SUM(CASE WHEN wo.status IN ('CAN','CLOSE','COMP') THEN 1 ELSE 0 END) AS [Closed],
    SUM(CASE WHEN wo.status NOT IN ('CAN','CLOSE','COMP') THEN 1 ELSE 0 END) AS [Open]
FROM [schema].[tickets] t
INNER JOIN [schema].[work_orders] wo ON wo.parent_id = t.record_id
GROUP BY t.record_id;
```

### 7.5 Composite Key Construction

```sql
CONCAT(t.record_id, '_', t.record_class)  AS [Record PK ID]
```

- **PK ID**: identifies the record in this view
- **FK ID**: links to another view
- Use consistent naming: `[TableName PK ID]`, `[ParentTable FK ID]`

### 7.6 String Normalization

Always normalize strings for comparisons:
```sql
WHERE UPPER(LTRIM(RTRIM(t.record_class))) = 'TARGET_CLASS'
```

### 7.7 EAV (Entity-Attribute-Value) Pivots

Pivot row-based attributes into columns:
```sql
SELECT e.entity_id,
    MAX(CASE WHEN s.attr_name = 'COLOR' THEN s.attr_value END) AS [Color],
    MAX(CASE WHEN s.attr_name = 'SIZE' THEN s.attr_value END)  AS [Size]
FROM [schema].[events] e
LEFT JOIN [schema].[event_specs] s ON s.event_id = e.event_id
GROUP BY e.entity_id;
```

### 7.8 Fabric SQL Endpoint Limitations

| Limitation | Workaround |
|---|---|
| No recursive CTEs | Flatten hierarchies upstream or use iterative approaches |
| No `NVARCHAR(MAX)` in some contexts | Use `VARCHAR(MAX)` instead |
| No `CREATE FUNCTION` or `CREATE PROCEDURE` | All logic must be in views or inline CTEs |
| No cross-database queries | All source tables must be in the same Lakehouse |
| `CREATE OR ALTER VIEW` syntax required | Cannot use `DROP VIEW IF EXISTS` + `CREATE VIEW` |
| Limited temp table support | Use CTEs instead of temp tables |

### 7.9 Leveraging Copilot for View Design

Ask Copilot to draft views based on your analysis:

```
Copilot prompt: "Based on this M expression [paste M code], create a SQL view
that reads from [schema].[source_table] in Fabric Lakehouse.
Use [Friendly Names] for columns. Include a deduplication CTE
that keeps only the latest record per parent_id."
```

Review the draft against: (1) M expression logic, (2) source table schema, (3) naming conventions.

### 7.10 Design Checklist

- [ ] View naming convention applied
- [ ] Composite keys defined for PK and FK columns
- [ ] Deduplication CTE implemented (if needed)
- [ ] String normalization applied to all WHERE clauses
- [ ] Column renames match the semantic model's friendly names
- [ ] Audit columns included
- [ ] Fabric SQL limitations accounted for
- [ ] View dependency order documented

---

## 8. Phase 7 — Build, Deploy & Iterate

### 8.1 Deployment Method

1. Write the `CREATE OR ALTER VIEW` DDL in a `.sql` file in your project folder
2. Open the Fabric **SQL Analytics Endpoint** for your Lakehouse in the browser
3. Paste the DDL into the SQL query editor
4. Execute the statement
5. Verify the view appears in the schema browser

> ⚠️ You must connect to the **SQL Analytics Endpoint**, not the Lakehouse endpoint. They look similar but only the SQL endpoint supports DDL.

### 8.2 Deployment Order

When views depend on other views, deploy in dependency order:

```
Step 1: VW_Detail_A        (reads from raw tables only)
Step 2: VW_Detail_B        (reads from raw tables only)
Step 3: VW_Aggregated_C    (reads from raw tables only)
Step 4: VW_Reference       (depends on VW_Detail_A, VW_Detail_B, VW_Aggregated_C)
```

### 8.3 Common Deployment Errors

| Error | Cause | Fix |
|---|---|---|
| `Invalid column name 'xyz'` | Column name mismatch | Query `INFORMATION_SCHEMA.COLUMNS` for actual names |
| `Invalid object name 'schema.table'` | Table doesn't exist or wrong schema | Verify with `INFORMATION_SCHEMA.TABLES` |
| `The multi-part identifier could not be bound` | Wrong table alias or column reference | Check alias usage in JOINs and CTEs |
| `Ambiguous column name` | Two joined tables have the same column name | Prefix all columns with table alias |
| View creates but returns 0 rows | Filter too restrictive or join is wrong | Test inner query (CTEs, JOINs) separately |

### 8.4 Iterating with Copilot

When deployment fails:

```
Copilot prompt: "I got this error deploying my view: 'Invalid column name priority'.
The view reads from [schema].[my_table]. Check what columns actually exist
and suggest the correct column name."
```

Copilot can query `INFORMATION_SCHEMA`, compare column references, and suggest corrections.

### 8.5 Verifying Deployed Views

```sql
SELECT COUNT(*) FROM [schema].[VW_MyView];         -- Row count
SELECT TOP 10 * FROM [schema].[VW_MyView];         -- Sample data
```

### 8.6 Build Checklist

- [ ] All views deployed in correct dependency order
- [ ] Each view returns rows (non-zero row count)
- [ ] Column names and data types verified
- [ ] No deployment errors remaining

---

## 9. Phase 8 — Validation

### 9.1 Why Validate

Your SQL views must produce the same results as the semantic model's Power Query logic. Validation ensures:
- Correct **grain** (no unintended duplicates)
- Correct **row counts** (all expected records present)
- Correct **transformations** (filters, renames, computed columns)
- Correct **joins** (cross-view relationships work)

### 9.2 Validation Script Structure

Organize tests into a single `.sql` file with clear sections and numbering:

```sql
-- ═══════════════════════════════════════════════════════════════════
-- Validation Test Cases — [View Names]
-- ═══════════════════════════════════════════════════════════════════
-- Target:   [Lakehouse] SQL Analytics Endpoint
-- Usage:    Run each test individually.
--           "0 rows" = PASS.  "informational" = review data.
-- ═══════════════════════════════════════════════════════════════════
```

### 9.3 Test Pattern Catalog

#### Pattern 1 — Grain check (no duplicates):
```sql
SELECT [Primary Key], COUNT(*) AS cnt
FROM [schema].[VW_MyView]
GROUP BY [Primary Key]
HAVING COUNT(*) > 1;
-- Expected: 0 rows
```

#### Pattern 2 — Row count reconciliation:
```sql
SELECT
    (SELECT COUNT(*) FROM [schema].[VW_MyView]) AS view_rows,
    (SELECT COUNT(*) FROM [schema].[source_table] WHERE type = 'X') AS source_rows;
-- Expected: Both equal
```

#### Pattern 3 — Filter validation:
```sql
SELECT [ID], [Type] FROM [schema].[VW_MyView]
WHERE UPPER([Type]) <> 'EXPECTED_TYPE';
-- Expected: 0 rows
```

#### Pattern 4 — Composite key format:
```sql
SELECT [Record PK ID] FROM [schema].[VW_MyView]
WHERE [Record PK ID] NOT LIKE '%[_]EXPECTED_SUFFIX';
-- Expected: 0 rows
```

#### Pattern 5 — Referential integrity (cross-view):
```sql
SELECT child.[ID], child.[Parent ID]
FROM [schema].[VW_Child] child
WHERE NOT EXISTS (
    SELECT 1 FROM [schema].[VW_Parent] parent
    WHERE parent.[ID] = child.[Parent ID]
);
-- Expected: 0 rows (no orphans)
```

#### Pattern 6 — Value transformation:
```sql
SELECT [ID], [Category] FROM [schema].[VW_MyView]
WHERE [Category] LIKE '%LONGORIGINALVALUE%';
-- Expected: 0 rows (replacement worked)
```

#### Pattern 7 — Status distribution (informational):
```sql
SELECT [Status], COUNT(*) AS cnt
FROM [schema].[VW_MyView]
GROUP BY [Status]
ORDER BY cnt DESC;
-- Expected: Known statuses with plausible counts
```

> See **Appendix C** for a complete copy-paste validation template.

### 9.4 Running Tests

- Open the **SQL Analytics Endpoint** in the Fabric portal
- Paste **one test at a time** and execute
- Tests expecting "0 rows" pass when the result set is empty
- Record results: test ID, pass/fail, actual values, notes

> ⚠️ Running the entire validation script at once may time out in Fabric. Run tests individually.

### 9.5 Cross-View Validation

When views are related (parent-child), add cross-view tests:
- Every child references a valid parent (no orphans)
- Counts match bidirectionally
- Shared attributes (e.g., site, organization) are consistent

### 9.6 Validation Checklist

- [ ] Grain check passes for every view (no duplicates)
- [ ] Row counts match source table expectations
- [ ] All filters validated
- [ ] Composite keys follow expected format
- [ ] Cross-view joins produce 0 orphans
- [ ] Informational tests show plausible distributions
- [ ] All results documented in a validation report

---

## 10. Phase 9 — Documentation

### 10.1 Why Document

Your SQL views are a translation of complex Power Query M and DAX logic. Without documentation, the next engineer won't understand why the views are structured the way they are.

### 10.2 Technical View Documentation

For each view, document:

| Property | What to Include |
|---|---|
| **View name** | Full qualified name (schema.view) |
| **Grain** | What one row represents |
| **Filter** | Source table filters applied |
| **File** | Path to the `.sql` script |
| **Replaces** | What this view replaces in the semantic model |
| **Dependencies** | Other views this view depends on |
| **CTEs** | Name and purpose of each CTE |
| **JOINs** | Target table, join type, join key, notes |
| **Column dictionary** | Every column: name, source expression, description |

### 10.3 Column Dictionary Format

```markdown
| Column | Source | Description |
|--------|--------|-------------|
| [Record ID] | `t.record_id` | Primary key |
| [Status] | `t.status` | Current workflow status |
| [Category] | `CASE WHEN...` | Shortened category |
| [Owner Name] | `p.display_name` | Resolved via PERSON join |
| [Fabric Loaded Date] | `t.FABRIC_LOADED_DATE` | ETL load timestamp |
```

### 10.4 Validation Report Format

```markdown
# [View Name] — Validation Report
> **Date:** YYYY-MM-DD
> **Result:** ✅ N/N PASS

## Summary
| Section | Tests | Pass | Fail |
|---------|-------|------|------|
| A: View 1 | 4 | 4 | 0 |
| B: View 2 | 6 | 6 | 0 |
| **Total** | **10** | **10** | **0** |
```

### 10.5 View Index

Maintain a central index of all views:

```markdown
| # | View | Description |
|---|------|-------------|
| 1 | `VW_Orders` | Core orders (1 row per order) |
| 2 | `VW_Order_Details` | Line items per order |
| 3 | `VW_Order_Summary` | Aggregated metrics |
```

### 10.6 Relationship Diagram

```
VW_Parent
    │  join on [Parent ID] = [Record ID]
    ▼
VW_Child                          (1 row per child record)
    │
    ├──→ VW_Details               (1:many — detail records)
    │      join on [Child ID]
    │
    └──→ VW_Reference             (pre-joined denormalized)
           combines all above
```

### 10.7 Documentation Checklist

- [ ] Technical documentation for every view
- [ ] Column dictionaries complete
- [ ] Validation report created
- [ ] View index updated
- [ ] Relationship diagram documented
- [ ] Deployment order documented

---

## Appendix A — MCP Command Cheat Sheet

### Discovery Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `fabric-notebook-mcp` | `list_artifacts` | `workspace`, `artifact_type` | List reports, semantic models, or lakehouses |
| `fabric-notebook-mcp` | `list_fabric_artifact_contents` | `artifact_type`, `artifact`, `workspace` | Browse lakehouse tables/files with schema |
| `fabric-notebook-mcp` | `preview_lakehouse_table` | `workspace`, `lakehouse_id`, `table_name` | Preview sample rows |
| `fabric_mcp` | `onelake_list_workspaces` | — | List all accessible workspaces |
| `fabric_mcp` | `onelake_list_items` | `workspace` | List items in a workspace |

### Connection Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `powerbi-modeling-mcp` | `connection_operations → ConnectFabric` | `workspaceName`, `semanticModelName` | Connect to a semantic model |
| `powerbi-modeling-mcp` | `connection_operations → ListConnections` | — | List active connections |
| `powerbi-modeling-mcp` | `connection_operations → Disconnect` | `connectionName` | Disconnect |

### Extraction Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `powerbi-modeling-mcp` | `table_operations → List` | — | List all tables |
| `powerbi-modeling-mcp` | `table_operations → ExportTMDL` | `references: [{ name }]` | Export TMDL for a table |
| `powerbi-modeling-mcp` | `relationship_operations → List` | — | List all relationships |
| `powerbi-modeling-mcp` | `measure_operations → List` | — | List all measures |
| `powerbi-modeling-mcp` | `measure_operations → Get` | `references: [{ name }]` | Get DAX expression |
| `powerbi-modeling-mcp` | `partition_operations → List` | `filter: { tableName }` | Get M/SQL source queries |
| `powerbi-modeling-mcp` | `column_operations → List` | `filter: { tableNames }` | List columns with types |

### Validation Phase

| MCP Server | Operation | Key Parameters | Description |
|---|---|---|---|
| `powerbi-modeling-mcp` | `dax_query_operations → Execute` | `query` | Run a DAX query |
| `powerbi-modeling-mcp` | `model_operations → GetStats` | — | Get model statistics |

---

## Appendix B — Power Query M → SQL Translation Guide

### Data Source Access

| M Pattern | SQL Equivalent |
|---|---|
| `Sql.Database("server", "db")` | `FROM [schema].[table]` |
| `Source{[Schema="dbo", Item="orders"]}[Data]` | `FROM dbo.orders` |
| `Value.NativeQuery(Source, "SELECT ...", null)` | Use the embedded SQL directly |

### Row Filtering

| M Pattern | SQL Equivalent |
|---|---|
| `Table.SelectRows(t, each [status] = "Active")` | `WHERE status = 'Active'` |
| `Table.SelectRows(t, each [status] <> "Deleted" and [type] = "Order")` | `WHERE status <> 'Deleted' AND type = 'Order'` |
| `Table.SelectRows(t, each [value] <> null)` | `WHERE value IS NOT NULL` |

### Column Operations

| M Pattern | SQL Equivalent |
|---|---|
| `Table.RenameColumns(t, {{"old", "new"}})` | `old AS [new]` |
| `Table.SelectColumns(t, {"col1", "col2"})` | `SELECT col1, col2` |
| `Table.RemoveColumns(t, {"unwanted"})` | Omit from SELECT |

### Computed Columns

| M Pattern | SQL Equivalent |
|---|---|
| `each [First] & " " & [Last]` | `CONCAT(First, ' ', Last)` |
| `each [id] & "_" & [type]` | `CONCAT(id, '_', type)` |
| `each if [x] > 0 then "Yes" else "No"` | `CASE WHEN x > 0 THEN 'Yes' ELSE 'No' END` |
| `each Date.Year([date])` | `YEAR(date)` |
| `each Text.Upper([name])` | `UPPER(name)` |
| `each Text.Trim([val])` | `LTRIM(RTRIM(val))` |

### Joins

| M Pattern | SQL Equivalent |
|---|---|
| `Table.NestedJoin(..., JoinKind.LeftOuter)` | `LEFT JOIN` |
| `Table.NestedJoin(..., JoinKind.Inner)` | `INNER JOIN` |
| `Table.NestedJoin(..., JoinKind.FullOuter)` | `FULL OUTER JOIN` |
| `Table.ExpandTableColumn(t, "merged", {"col1"})` | Include `t2.col1` in SELECT |

### Aggregation

| M Pattern | SQL Equivalent |
|---|---|
| `each Table.RowCount(_)` | `COUNT(*)` |
| `each List.Sum([amount])` | `SUM(amount)` |
| `each List.Average([val])` | `AVG(val)` |
| `each List.Max([val])` | `MAX(val)` |

### Deduplication

| M Pattern | SQL Equivalent |
|---|---|
| `Table.Distinct(t)` | `SELECT DISTINCT *` |
| `Table.Distinct(t, {"key"})` | `ROW_NUMBER() OVER (PARTITION BY key ...) = 1` |

### String Functions

| M Pattern | SQL Equivalent |
|---|---|
| `Text.Upper(x)` | `UPPER(x)` |
| `Text.Lower(x)` | `LOWER(x)` |
| `Text.Trim(x)` | `LTRIM(RTRIM(x))` |
| `Text.Start(x, n)` | `LEFT(x, n)` |
| `Text.End(x, n)` | `RIGHT(x, n)` |
| `Text.Length(x)` | `LEN(x)` |
| `Text.Replace(x, "old", "new")` | `REPLACE(x, 'old', 'new')` |
| `Text.Contains(x, "sub")` | `x LIKE '%sub%'` |

---

## Appendix C — Validation Test Template

Copy-paste this template and customize the bracketed placeholders:

```sql
-- ═══════════════════════════════════════════════════════════════════
-- Validation Test Cases — [VIEW_NAMES]
-- ═══════════════════════════════════════════════════════════════════
-- Target:   [Lakehouse] SQL Analytics Endpoint
-- Usage:    Run each test individually in Fabric SQL query editor.
--           Tests expecting "0 rows" pass when the result set is empty.
--           Tests marked "informational" return data for review.
-- ═══════════════════════════════════════════════════════════════════


-- SECTION A: [VW_Name_1]

-- TEST A1: Grain — no duplicate primary keys
-- Expected: 0 rows
SELECT [Primary Key], COUNT(*) AS cnt
FROM [schema].[VW_Name_1]
GROUP BY [Primary Key]
HAVING COUNT(*) > 1;


-- TEST A2: Row count matches source
-- Expected: Both counts equal
SELECT
    (SELECT COUNT(*) FROM [schema].[VW_Name_1]) AS vw_rows,
    (SELECT COUNT(*) FROM [schema].[source_table] WHERE [filter]) AS source_rows;


-- TEST A3: Filter validation
-- Expected: 0 rows
SELECT [Primary Key], [Type]
FROM [schema].[VW_Name_1]
WHERE UPPER([Type]) <> 'EXPECTED_VALUE';


-- TEST A4: Composite key format
-- Expected: 0 rows
SELECT [Composite Key]
FROM [schema].[VW_Name_1]
WHERE [Composite Key] NOT LIKE '%[_]EXPECTED_SUFFIX';


-- TEST A5: Value transformation
-- Expected: 0 rows
SELECT [Primary Key], [Transformed Column]
FROM [schema].[VW_Name_1]
WHERE [Transformed Column] LIKE '%ORIGINAL_VALUE%';


-- TEST A6: Sample data (informational)
SELECT TOP 10 * FROM [schema].[VW_Name_1] ORDER BY [Primary Key];


-- SECTION B: CROSS-VIEW

-- TEST B1: Referential integrity — child → parent
-- Expected: 0 rows
SELECT child.[ID], child.[Parent FK]
FROM [schema].[VW_Child] child
WHERE NOT EXISTS (
    SELECT 1 FROM [schema].[VW_Parent] parent
    WHERE parent.[ID] = child.[Parent FK]
);


-- TEST B2: Bidirectional count
-- Expected: Both counts equal
SELECT
    (SELECT COUNT(DISTINCT [Parent FK]) FROM [schema].[VW_Child]) AS from_child,
    (SELECT COUNT(DISTINCT p.[ID])
     FROM [schema].[VW_Parent] p
     WHERE EXISTS (
         SELECT 1 FROM [schema].[VW_Child] c WHERE c.[Parent FK] = p.[ID]
     )) AS from_parent;


-- SECTION C: SUMMARY

-- TEST C1: Row counts (informational)
SELECT 'VW_Name_1' AS [View], COUNT(*) AS [Rows] FROM [schema].[VW_Name_1]
UNION ALL
SELECT 'VW_Name_2', COUNT(*) FROM [schema].[VW_Name_2];


-- END OF VALIDATION
```

---

## Appendix D — Copilot CLI Prompt Templates

### Phase 1 — Discovery
```
"List all reports and datasets in the '[WORKSPACE_NAME]' workspace"
```
```
"List all lakehouses in the '[WORKSPACE_NAME]' workspace and show me their tables"
```

### Phase 2 — Connection
```
"Connect to the '[MODEL_NAME]' semantic model in the '[WORKSPACE_NAME]' workspace"
```
```
"Show me the current connection details"
```

### Phase 3 — Extraction
```
"List all tables in this semantic model, filtering out auto-generated date tables"
```
```
"List all relationships — show from/to tables, columns, cardinality, active/inactive"
```
```
"List all measures with their DAX expressions"
```
```
"Show me the partition source queries (M expressions) for the '[TABLE_NAME]' table"
```
```
"Export the TMDL definition for the '[TABLE_NAME]' table"
```

### Phase 4 — Analysis
```
"Analyze this M expression and tell me:
1. What source table(s) it reads from
2. What filters it applies
3. What columns it renames
4. What computed columns it creates
5. What joins it performs

[PASTE M EXPRESSION]"
```

### Phase 5 — Source Mapping
```
"Show me the columns in [SCHEMA].[TABLE] in the '[LAKEHOUSE]' lakehouse.
Compare them to these semantic model column names: [LIST]"
```

### Phase 6 — View Design
```
"Based on this M expression, create a Fabric SQL view called [SCHEMA].[VW_NAME].
Use [Friendly Names] for columns. Include composite keys using CONCAT(id, '_', type).
Add audit columns. Use UPPER(LTRIM(RTRIM(...))) for string comparisons.

[PASTE M EXPRESSION]"
```

### Phase 7 — Troubleshooting
```
"I got this error deploying my view: '[ERROR]'.
The view reads from [SCHEMA].[TABLE]. Check the actual column names
and suggest corrections."
```

### Phase 8 — Validation
```
"Create a validation script for [SCHEMA].[VW_NAME] with tests for:
grain check, row count vs source, filter validation, composite key format,
cross-view referential integrity against [SCHEMA].[VW_PARENT]"
```

### Phase 9 — Documentation
```
"Generate technical documentation for [SCHEMA].[VW_NAME] including:
grain, source table, filter, CTEs, JOINs, and full column dictionary"
```

---

*Generated: 2026-05-21 | Playbook version: 1.0*
